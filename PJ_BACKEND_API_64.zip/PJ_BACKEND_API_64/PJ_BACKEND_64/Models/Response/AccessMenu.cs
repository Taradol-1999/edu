﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _63_API_EOFFICE.Models.Response
{
    public class AccessMenu
    {
        public IEnumerable<DetailAccessMenu> Menu { get; set; }
    }

    public class DetailAccessMenu
    {
        public int MenuCode { get; set; }
        public int Role { get; set; }
    }
}
