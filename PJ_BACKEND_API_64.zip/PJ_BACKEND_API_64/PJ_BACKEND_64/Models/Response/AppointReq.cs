﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PJ_BACKEND_64.Models.Response
{
    public class AppointReq
    {
        public List<AppointArray> AppointArray { get; set; }
    }

    public partial class AppointArray
    {
        public string AppointId { get; set; }
        public string InstructorProfession { get; set; }
        public string InstructorMajor { get; set; }
        public string RegisId { get; set; }
    }

    public partial class AppointUp
    {
        public string InstructorProfession { get; set; }
        public string InstructorMajor { get; set; }
    }

}
