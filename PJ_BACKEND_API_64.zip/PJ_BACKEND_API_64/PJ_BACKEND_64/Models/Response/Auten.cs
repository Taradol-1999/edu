﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PJ_BACKEND_64.Models.Response
{
    public class Auten
    {
        [Display(Name = "UserName")]
        public string UserName { get; set; }

        [Display(Name = "PassWord")]
        public string PassWord { get; set; }
    }
}
