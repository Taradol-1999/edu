﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PJ_BACKEND_64.Models.Response
{
    public class LoginReq
    {
        public string EmpId { get; set; }
        public string PassWord { get; set; }
    }
}
