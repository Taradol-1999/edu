﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PJ_BACKEND_64.Models.Response
{
    public class ActivityReq
    {
        public string ActivityTitle { get; set; }
        public string ActivityDetail { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string PublishStatus { get; set; }
        public DateTime? PublishDate { get; set; }
        public string ActivityType { get; set; }
        public string[] RemoveDocName { get; set; }
        public string[] RemoveDoc { get; set; }
        public IFormFile[] Documents { get; set; }
        public string[] RemoveImg { get; set; }
        public IFormFile[] Image { get; set; }
    }
}
