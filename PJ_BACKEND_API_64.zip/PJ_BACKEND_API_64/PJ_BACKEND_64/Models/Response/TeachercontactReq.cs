﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PJ_BACKEND_64.Models.Response
{
    public class TeachercontactReq
    {
        
        public int? TitleId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Phone { get; set; }
        public int? GroupId { get; set; }
        public List<AddMentor> AddMentor { get; set; }

    }
    public class AddMentor
    {
        public int SchoolId { get; set; }
    }
}
