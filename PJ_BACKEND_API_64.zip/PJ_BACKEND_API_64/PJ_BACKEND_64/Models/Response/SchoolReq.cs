﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PJ_BACKEND_64.Models.Response
{
    public class SchoolReq
    {
        public IFormFile Logo { get; set; }
        public string SchoolName { get; set; }
        public string Address { get; set; }
        public string ElementarySchool { get; set; }
        public string StatusElementary { get; set; }
        public string ElementaryLevel { get; set; }
        public string StatusHighSchool { get; set; }
        public string Distance { get; set; }
        public string Phone { get; set; }
    }
}
