﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PJ_BACKEND_64.Models.Response
{
    public class UserReq
    {

        public string UserId { get; set; }
        public int? PreFix { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Phone { get; set; }
        public int? MajorId { get; set; }
        public string UserName { get; set; }
        public string PassWord { get; set; }
        public string Role { get; set; }
    }

    public class MajorReq
    {
        public string MajorName { get; set; }
        public int? FacultyID { get; set; }
    }
    public class PreFixReq
    {
        public string PreFix { get; set; }
    }
}
