﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PJ_BACKEND_64.Models.Response
{
    public class RegisterReq
    {
        public string StudId { get; set; }
        public string SchoolId { get; set; }
        public string Semester { get; set; }
        public string Year { get; set; }
        public DateTime? StartTraining { get; set; }
        public DateTime? EndTraining { get; set; }
        public int? GroupLearning { get; set; }
    }
}
