﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PJ_BACKEND_64.Models.Response
{
    public class CheckActivityReq
    { 
        public string RegisId { get; set; }
        public string AcId { get; set; }
    }
}
