﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PJ_BACKEND_64.Models.Data;

namespace PJ_BACKEND_64.Models.Dropdown
{
    public class MajorsDropdown
    {
        private readonly InternshipSystemContext _InternshipContext = new InternshipSystemContext();

        public async Task<IEnumerable<object>> GetMajors()
        {
            return await _InternshipContext.Majors.Include(e=>e.Faculty).Select(a => new { a.MajorId, a.MajorName,a.FacultyId ,a.Faculty.FacultyName }).ToListAsync();
        }
    }
}
