﻿using Microsoft.EntityFrameworkCore;
using PJ_BACKEND_64.Models.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PJ_BACKEND_64.Models.Dropdown
{
    public class InstructorDropdown
    {
        private readonly InternshipSystemContext _InternshipContext = new InternshipSystemContext();

        public async Task<IEnumerable<object>> GetInstructor()
        {
            return await _InternshipContext.Users.Where(a => a.Role == "2").Select(a => new { a.UserId, a.PreFix, fullName = a.FirstName +" " + a.LastName }).ToListAsync();
        }
    }
}
