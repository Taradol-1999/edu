﻿using Microsoft.EntityFrameworkCore;
using PJ_BACKEND_64.Models.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PJ_BACKEND_64.Models.Dropdown
{
    public class RegisterDropdown
    {
        private readonly InternshipSystemContext _InternshipContext = new InternshipSystemContext();

        public async Task<IEnumerable<object>> GetRegister()
        {
            return await _InternshipContext.Registers.Include(e => e.Stud).ThenInclude(e => e.PreFix).Select(a => new
            {
                a.RegisId,
                a.Year,
                a.Semester,
                //Name = a.Stud.PreFix.TitleName + " " + a.Stud.FirstName + " " + a.Stud.LastName
            }).OrderByDescending(a => a.Year).ThenByDescending(a => a.Semester).ToListAsync();
        }
    }
}
