﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PJ_BACKEND_64.Models.Data;

namespace PJ_BACKEND_64.Models.Dropdown
{
    public class SchoolDropdown
    {
        private readonly InternshipSystemContext _InternshipContext = new();

        public async Task<object> GetSchool(string url)
        {
            return await _InternshipContext.Schools.Select(a => new { a.SchoolId, a.SchoolName, LogoUrl = !string.IsNullOrEmpty(a.Logo) ? url + "/LogoSchool/" + a.Logo : "", }).OrderBy(a => a.SchoolName).ToListAsync();
        }

        public async Task<object> GetSchoolByYear(string url = "", string Year = "", string Semester = "")
        {
            var data = await _InternshipContext.Registers.Select(x => new
            {
                x.SchoolId,
                x.School.SchoolName,
                LogoUrl = !string.IsNullOrEmpty(x.School.Logo) ? url + "/LogoSchool/" + x.School.Logo : "",
                x.Year,
                x.Semester

            }).ToListAsync();

            if (!string.IsNullOrEmpty(Year))
            {
                data = data.Where(x => x.Year == Year).ToList();
            }
            if (!string.IsNullOrEmpty(Semester))
            {
                data = data.Where(x => x.Semester == Semester).ToList();
            }

            data = data.GroupBy(i => i.SchoolId).Select(g => g.First()).ToList();

            return data;
        }
    }
}
