﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PJ_BACKEND_64.Models.Data;

namespace PJ_BACKEND_64.Models.Dropdown
{
    public class RequestDropdown
    {
        private readonly InternshipSystemContext _InternshipContext = new InternshipSystemContext();

        public async Task<IEnumerable<object>> GetRequest()
        {
            return await _InternshipContext.Registers.Select(a => new {  a.Semester,a.Year }).ToListAsync();
        }
    }
}
