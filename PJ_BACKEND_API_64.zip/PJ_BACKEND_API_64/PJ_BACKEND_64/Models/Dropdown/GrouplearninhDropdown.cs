﻿using PJ_BACKEND_64.Models.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace PJ_BACKEND_64.Models.Dropdown
{
    public class GrouplearninhDropdown
    {
        private readonly InternshipSystemContext _InternshipContext = new InternshipSystemContext();

        public async Task<IEnumerable<object>> GetGrouplearninhs()
        {
            return await _InternshipContext.Grouplearninhs.Select(a => new { a.GroupId, a.GroupName }).ToListAsync();
        }
    }
}
