﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PJ_BACKEND_64.Models.Data;

namespace PJ_BACKEND_64.Models.Dropdown
{
    public class TitleDropdown
    {
        private readonly InternshipSystemContext _InternshipContext = new InternshipSystemContext();

        public async Task<IEnumerable<object>> GetTitle()
        {
            return await _InternshipContext.Titles.Select(a => new { a.TitleId, a.TitleName }).ToListAsync();
        }
    }
}
