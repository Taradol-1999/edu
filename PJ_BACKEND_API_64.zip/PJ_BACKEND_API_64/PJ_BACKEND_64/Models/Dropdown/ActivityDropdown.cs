﻿using Microsoft.EntityFrameworkCore;
using PJ_BACKEND_64.Models.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PJ_BACKEND_64.Models.Dropdown
{
    public class ActivityDropdown
    {
        private readonly InternshipSystemContext _InternshipContext = new InternshipSystemContext();

        public async Task<IEnumerable<object>> GetActivity()
        {
            return await _InternshipContext.Activities.Where(a => a.ActivityTitle == "1").Select(a => new { a.ActivityId, a.ActivityTitle, a.ActivityType }).ToListAsync();
        }
    }
}
