﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PJ_BACKEND_64.Models.Data;

namespace PJ_BACKEND_64.Models.Dropdown
{
    public class FacultyDropdown
    {
        private readonly InternshipSystemContext _InternshipContext = new InternshipSystemContext();

        public async Task<IEnumerable<object>> GetFaculty()
        {
            return await _InternshipContext.Faculties.Select(a => new { a.FacultyId, a.FacultyName }).ToListAsync();
        }
    }
}
