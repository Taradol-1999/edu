﻿using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using PJ_BACKEND_64.Models.Data;
using PJ_BACKEND_64.Models.Response;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace PJ_BACKEND_64.Models.Querise
{
    public class AccessTokenQ
    {
        private readonly InternshipSystemContext _InternshipContext = new();

        public string GenerateAccessToken(string Code, string userType, int minute = 60)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("EDUHelpSecretKey"));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            List<Claim> claims = new List<Claim>();
            claims.Add(new(JwtRegisteredClaimNames.Sub, Code));
            claims.Add(new(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()));
            claims.Add(new(ClaimTypes.Role, userType));

            var token = new JwtSecurityToken(
                  "https://localhost:44354",
                  "https://localhost:44354",
                  notBefore: DateTime.Now,
                  expires: DateTime.Now.AddMinutes(minute),
                  claims: claims,
                  signingCredentials: credentials
              );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
        public async Task<object> Login(Auten login)
        {
            var user = await _InternshipContext.Users.Where(b => b.UserName == login.UserName && b.PassWord == login.PassWord).Select(a => new
            {
                a.UserId,
                a.Phone,
                a.Role,
                a.FirstName,
                a.LastName,
            }).FirstOrDefaultAsync();

            if (user != null)
            {
                var role = user.Role == "3" ? "student" : user.Role == "2" ? "teacher" : "admin";
                return new { StatusCode = 1, TaskStatus = true, Users = user, AccessToken = GenerateAccessToken(user.UserId, role, 1440) };
            }
            else
            {
                return new { StatusCode = 1, TaskStatus = false, Message = "ชื่อผู้ใช้ หรือรหัสผ่านไม่ถูกต้อง" };
            }
        }
    }
}
