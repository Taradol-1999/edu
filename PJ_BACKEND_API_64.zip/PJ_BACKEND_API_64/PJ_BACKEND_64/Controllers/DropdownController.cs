﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using _63_API_EOFFICE.Models.Response;
using Microsoft.EntityFrameworkCore;
using PJ_BACKEND_64.Models.Data;
using PJ_BACKEND_64.Models.Dropdown;

namespace PJ_BACKEND_64.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class DropdownController : ControllerBase
    {
        private readonly InternshipSystemContext _InternshipContext = new InternshipSystemContext();

        private MajorsDropdown _Majors = new();
        private FacultyDropdown _Faculty = new();
        private RequestDropdown _Request = new();
        private SchoolDropdown _School = new();
        private RegisterDropdown _Register = new();
        private TitleDropdown _Title = new();
        private GrouplearninhDropdown _GrouplearninhDropdown = new();
        private ActivityDropdown _Activity = new();
        private readonly InstructorDropdown instructor = new();

        [HttpGet]
        public async Task<IActionResult> GetData()
        {
            try
            {
                var url = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}";
                var dataSchool = await _School.GetSchool(url);
                var dataInstructor = await instructor.GetInstructor();


                return Ok(new
                {
                    //Register = await _Register.GetRegister(),
                    // Activity = await _Activity.GetActivity(),
                    Majors = await _Majors.GetMajors(),
                    Faculty = await _Faculty.GetFaculty(),
                    Request = await _Request.GetRequest(),
                    Title = await _Title.GetTitle(),
                    School = dataSchool,
                    Instructor = dataInstructor,
                    Grouplearninh = await _GrouplearninhDropdown.GetGrouplearninhs()

                });
            }
            catch (Exception e)
            {
                return BadRequest(new Messages() { StatusCode = 0, Message = e.Message });
            }
        }

        [HttpGet("GetSchoolByYear")]
        public async Task<IActionResult> GetSchoolByYear(string Year = "", string Semester = "")
        {
            try
            {
                var url = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}";
                return Ok(await _School.GetSchoolByYear(url, Year, Semester));
            }
            catch (Exception e)
            {
                return BadRequest(new Messages() { StatusCode = 0, Message = e.Message });
            }
        }
    }
}
