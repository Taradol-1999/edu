﻿using _63_API_EOFFICE.Models.Response;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using PJ_BACKEND_64.Models.Data;
using PJ_BACKEND_64.Models.Response;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace PJ_BACKEND_64.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class ActivityController : ControllerBase
    {
        private readonly InternshipSystemContext _InternshipContext = new();
        private readonly IWebHostEnvironment _environment;
        public ActivityController(IWebHostEnvironment environment)
        {
            _environment = environment;
        }

        private static object ImageUrl(string img, string url)
        {
            string[] items = img.Split(',');
            var array = items.Select(a => url + "/FileActivtiy/" + a);
            return array;
        }

        private static object DocumentUrl(string Doc, string url)
        {
            string[] items = Doc.Split(',');
            var array = items.Select(a => new { DocUrl = url + "/DocumetsActivity/" + a, NameDoc = a });
            return array;
        }

        private static object DocOriginalUrl(string Doc)
        {
            string[] items = Doc.Split(',');
            var array = items.Select(a => new { nameOri = a });
            return array;
        }

        [HttpGet("LoadNews")]
        public ActionResult LoadNews(string search = "")
        {
            try
            {
                var url = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}";
                var data = _InternshipContext.Activities.Where(a => a.PublishStatus == "1").Select(data => new
                {
                    data.ActivityId,
                    data.ActivityTitle,
                    data.ActivityDetail,
                    data.StartDate,
                    data.EndDate,
                    data.PublishDate,
                    DocumentUrl = data.Documents != null ? ImageUrl(data.Documents, url) : "",
                    ImageUrl = data.Image != null ? ImageUrl(data.Image, url) : "",
                    PublishMonth = Convert.ToDateTime(data.PublishDate).ToString("MMM", new CultureInfo("th-TH")),
                    PublishDay = Convert.ToDateTime(data.PublishDate).ToString("dd", new CultureInfo("th-TH")),
                    PublishDateTH = Convert.ToDateTime(data.PublishDate).ToString("dd/MMM/yyyy", new CultureInfo("th-TH")),
                    data.ActivityType,
                    data.PublishStatus

                }).OrderByDescending(a => a.ActivityId).ToList();
                if (!string.IsNullOrEmpty(search))
                {
                    data = data.Where(a =>
                    a.ActivityTitle.Contains(search.TrimStart())).ToList();
                }

                DateTime dt = DateTime.Now;
                DateTime lastMonth = new DateTime(dt.Year, dt.AddMonths(-1).Month, dt.Day);
                var date = Convert.ToDateTime(lastMonth.ToString("yyyy-MM-dd", new CultureInfo("en-US")));
                data = data.Where(x => Convert.ToDateTime(x.PublishDate.Value.ToString("yyyy-MM-dd", new CultureInfo("en-US"))) >= date).ToList();

                return Ok(new { data });
            }
            catch (Exception)
            {
                return CreatedAtAction(nameof(LoadNews), new Messages() { StatusCode = 0, Message = "เกิดข้อผิดพลาด !" });
            }
        }

        [HttpGet("LoadDetailNews")]
        public ActionResult LoadDetailNews(int id)
        {
            try
            {
                var url = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}";

                var data = _InternshipContext.Activities.Where(a => a.PublishStatus == "1").Select(data => new
                {
                    data.ActivityId,
                    data.ActivityTitle,
                    data.ActivityDetail,
                    data.StartDate,
                    data.EndDate,
                    EndDateTH = data.EndDate != null ? Convert.ToDateTime(data.EndDate).ToString("dd/MMM/yyyy", new CultureInfo("th-TH")) : "",
                    StartDateTH = data.StartDate != null ? Convert.ToDateTime(data.StartDate).ToString("dd/MMM/yyyy", new CultureInfo("th-TH")) : "",
                    data.PublishDate,
                    DocumentUrl = data.Documents != null ? DocumentUrl(data.Documents, url) : "",
                    ImageUrl = data.Image != null ? ImageUrl(data.Image, url) : "",
                    PublishMonth = Convert.ToDateTime(data.PublishDate).ToString("MMM", new CultureInfo("th-TH")),
                    PublishDay = Convert.ToDateTime(data.PublishDate).ToString("dd", new CultureInfo("th-TH")),
                    PublishDateTH = Convert.ToDateTime(data.PublishDate).ToString("dd/MMM/yyyy", new CultureInfo("th-TH")),
                    data.ActivityType,
                    data.PublishStatus

                }).FirstOrDefault(a => a.ActivityId == id);

                return Ok(new { data });
            }
            catch (Exception)
            {
                return CreatedAtAction(nameof(LoadDetailNews), new Messages() { StatusCode = 0, Message = "เกิดข้อผิดพลาด !" });
            }
        }

        [HttpGet("LoadActivity")]
        public ActionResult LoadActivity(string search = "", int pageSize = 10, int currentPage = 1, string publishStatus = "", string activityType = "", string since = "", string to = "")
        {
            try
            {
                int RowCount = 0;
                var query = _InternshipContext.Activities.Select(data => new
                {
                    data.ActivityId,
                    data.ActivityTitle,
                    data.ActivityDetail,
                    data.StartDate,
                    data.EndDate,
                    data.PublishDate,
                    PublishDateTH = Convert.ToDateTime(data.PublishDate).ToString("dd/MMM/yyyy", new CultureInfo("th-TH")),
                    data.ActivityType,
                    data.PublishStatus

                }).ToList();

                if (!string.IsNullOrEmpty(search))
                {
                    query = query.Where(a =>
                    a.ActivityTitle.Contains(search.TrimStart())).ToList();
                }
                if (!string.IsNullOrEmpty(publishStatus))
                {
                    query = query.Where(a => a.PublishStatus == publishStatus).ToList();
                }
                if (!string.IsNullOrEmpty(activityType))
                {
                    query = query.Where(a => a.ActivityType == activityType).ToList();
                }

                if (!string.IsNullOrEmpty(since) && !string.IsNullOrEmpty(to))
                {
                    var sinces = Convert.ToDateTime(since);
                    var tos = Convert.ToDateTime(to);
                    query = query.Where(x => Convert.ToDateTime(x.PublishDate.Value.ToString("yyyy-MM-dd", new CultureInfo("en-US"))) >= sinces && Convert.ToDateTime(x.PublishDate.Value.ToString("yyyy-MM-dd", new CultureInfo("en-US"))) <= tos).ToList();
                }
                if (!string.IsNullOrEmpty(since))
                {
                    var sinces = Convert.ToDateTime(since);
                    query = query.Where(x => Convert.ToDateTime(x.PublishDate.Value.ToString("yyyy-MM-dd", new CultureInfo("en-US"))) >= sinces).ToList();

                }
                if (!string.IsNullOrEmpty(to))
                {
                    var tos = Convert.ToDateTime(to);

                    query = query.Where(x => Convert.ToDateTime(x.PublishDate.Value.ToString("yyyy-MM-dd", new CultureInfo("en-US"))) <= tos).ToList();

                }


                RowCount = query.Count;
                var pageCount = (double)RowCount / pageSize;
                pageCount = (int)Math.Ceiling(pageCount);
                query = query.OrderByDescending(a => a.ActivityId).Skip((currentPage - 1) * pageSize).Take(pageSize).ToList();

                return Ok(new { DATA = query, paging = new { currentPage, RowCount, pageSize, pageCount } });
            }
            catch (Exception)
            {
                return CreatedAtAction(nameof(LoadActivity), new Messages() { StatusCode = 0, Message = "เกิดข้อผิดพลาด !" });
            }
        }

        [HttpPost("CreateActivity")]
        public async Task<IActionResult> CreateActivity([FromForm] ActivityReq data)
        {
            try
            {

                var nameImg = "";
                string nameImage = string.Empty;
                int num = 0;
                if (data.Image != null)
                {
                    foreach (var item in data.Image)
                    {
                        var WebRootPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot\\FileActivtiy");
                        var uploads = Path.Combine(WebRootPath);
                        if (!Directory.Exists(uploads)) Directory.CreateDirectory(uploads);
                        nameImg = Guid.NewGuid() + "." + item.ContentType.Split("/")[1];
                        var fileStream = new FileStream(Path.Combine(uploads, nameImg), FileMode.Create);
                        await item.CopyToAsync(fileStream);

                        if (num == 0)
                        {
                            nameImage = nameImg;
                        }
                        else
                        {
                            nameImage += "," + nameImg;
                        }
                        num++;
                    }
                }

                var nameDoc = "";
                string nameDocuments = string.Empty;
                int numDoc = 0;

                var nameDocOriginal = "";
                string nameOriginal = string.Empty;
                int numDocOriginal = 0;

                if (data.Documents != null)
                {
                    foreach (var item in data.Documents)
                    {

                        var WebRootPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot\\DocumetsActivity");
                        var uploads = Path.Combine(WebRootPath);
                        if (!Directory.Exists(uploads)) Directory.CreateDirectory(uploads);
                        nameDoc = Guid.NewGuid() + Path.GetExtension(item.FileName);
                        nameDocOriginal = item.FileName;
                        var fileStream = new FileStream(Path.Combine(uploads, nameDoc), FileMode.Create);
                        await item.CopyToAsync(fileStream);
                        if (numDoc == 0)
                        {
                            nameDocuments = nameDoc;
                        }
                        else
                        {
                            nameDocuments += "," + nameDoc;
                        }
                        numDoc++;

                        if (numDocOriginal == 0)
                        {
                            nameOriginal = nameDocOriginal;
                        }
                        else
                        {
                            nameOriginal += "," + nameDocOriginal;
                        }
                        numDocOriginal++;

                    }
                }

                _InternshipContext.Add(new Activity()
                {
                    ActivityTitle = data.ActivityTitle,
                    ActivityDetail = data.ActivityDetail,
                    StartDate = data.StartDate,
                    EndDate = data.EndDate,
                    ActivityType = data.ActivityType,
                    PublishStatus = data.PublishStatus,
                    PublishDate = data.PublishDate,
                    DocNameOriginal = !string.IsNullOrEmpty(nameOriginal) ? nameOriginal : null,
                    Documents = !string.IsNullOrEmpty(nameDocuments) ? nameDocuments : null,
                    Image = !string.IsNullOrEmpty(nameImage) ? nameImage : null,
                    CreationDate = DateTime.Now,
                });

                await _InternshipContext.SaveChangesAsync();
                return CreatedAtAction(nameof(CreateActivity), new Messages() { StatusCode = 1, Message = "สำเร็จ" });
            }
            catch (Exception)
            {
                return CreatedAtAction(nameof(CreateActivity), new Messages() { StatusCode = 0, Message = "ลงทะเบียนล้มเหลว!" });
            }
        }

        [HttpPost("UpFileCKEditor")]
        public async Task<IActionResult> UpFileCKEditor([FromForm] IFormFile upload)
        {
            try
            {
                string url = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}/CKEditorImage/";
                var WebRootPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot");
                var uploads = Path.Combine(WebRootPath, "CKEditorImage");
                if (!Directory.Exists(uploads)) Directory.CreateDirectory(uploads);

                if (upload != null)
                {
                    var name = Guid.NewGuid() + "." + upload.ContentType.Split("/")[1];
                    var fileStream = new FileStream(Path.Combine(uploads, name), FileMode.Create);
                    await upload.CopyToAsync(fileStream);
                    return Ok(new { uploaded = true, url = url + name });
                }

                return Ok(new { error = new { message = "The image upload failed because the image was too big" } });
            }
            catch (Exception)
            {
                return Ok(JsonConvert.SerializeObject(new
                {
                    error = new
                    {
                        message = "The image upload failed because the image was too big"
                    }
                }));
            }
        }

        [HttpGet("DetailActivity")]
        public ActionResult DetailActivity(int id)
        {
            try
            {
                var url = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}";

                var data = _InternshipContext.Activities.Select(data => new
                {
                    data.ActivityId,
                    data.ActivityTitle,
                    data.ActivityDetail,
                    data.StartDate,
                    data.EndDate,
                    data.PublishDate,
                    DocOriginal = data.Documents != null ? DocOriginalUrl(data.DocNameOriginal) : "",
                    DocumentUrl = data.Documents != null ? DocumentUrl(data.Documents, url) : "",
                    ImageUrl = data.Image != null ? ImageUrl(data.Image, url) : "",
                    data.ActivityType,
                    data.PublishStatus,
                    EndDateTH = data.EndDate != null ? Convert.ToDateTime(data.EndDate).ToString("dd/MMM/yyyy", new CultureInfo("th-TH")) : "",
                    StartDateTH = data.StartDate != null ? Convert.ToDateTime(data.StartDate).ToString("dd/MMM/yyyy", new CultureInfo("th-TH")) : "",
                    PublishMonth = Convert.ToDateTime(data.PublishDate).ToString("MMM", new CultureInfo("th-TH")),
                    PublishDay = Convert.ToDateTime(data.PublishDate).ToString("dd", new CultureInfo("th-TH")),
                    PublishDateTH = Convert.ToDateTime(data.PublishDate).ToString("dd/MMM/yyyy", new CultureInfo("th-TH")),

                }).FirstOrDefault(a => a.ActivityId == id);

                return Ok(new { data });
            }
            catch (Exception)
            {
                return CreatedAtAction(nameof(DetailActivity), new Messages() { StatusCode = 0, Message = "เกิดข้อผิดพลาด !" });
            }
        }

        [HttpPut("UpDateActivity/{id}")]
        public async Task<IActionResult> UpDateActivity([FromForm] ActivityReq data, int id)
        {
            try
            {
                string urlImg = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}/FileActivtiy/";
                string urlDoc = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}/DocumetsActivity/";

                var ac = await _InternshipContext.Activities.AsNoTracking().FirstOrDefaultAsync(a => a.ActivityId == id);
                if (ac != null)
                {

                    var acc = ac.Image == null ? "" : ac.Image;
                    List<string> tmp = acc.Split(",").ToList();
                    if (data.RemoveImg != null)
                    {
                        foreach (var img in data.RemoveImg)
                        {
                            string removeURL = img.Replace(urlImg, "");
                            var re = removeURL.Split(",").ToList();
                            foreach (var item in re)
                            {
                                tmp.Remove(item);
                                var WebRootPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot\\FileActivtiy\\");
                                var uppath = WebRootPath + item;
                                if (System.IO.File.Exists(uppath)) System.IO.File.Delete(uppath);
                            }
                        }
                    }
                    if (data.Image != null)
                    {
                        foreach (var item in data.Image)
                        {
                            var WebRootPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot\\FileActivtiy\\");
                            var uploads = Path.Combine(WebRootPath);
                            if (!Directory.Exists(uploads)) Directory.CreateDirectory(uploads);
                            string nameImg = Guid.NewGuid() + "." + item.ContentType.Split("/")[1];
                            var fileStream = new FileStream(Path.Combine(uploads, nameImg), FileMode.Create);
                            await item.CopyToAsync(fileStream);
                            tmp.Add(nameImg);
                        }
                    }

                    var docc = ac.Documents == null ? "" : ac.Documents;
                    List<string> doc = docc.Split(",").ToList();

                    var docOri = ac.DocNameOriginal == null ? "" : ac.DocNameOriginal;
                    List<string> docName = docOri.Split(",").ToList();

                    if (data.RemoveDoc != null)
                    {
                        foreach (var Doc in data.RemoveDoc)
                        {
                            string removeURL = Doc.Replace(urlDoc, "");
                            var re = removeURL.Split(",").ToList();

                            foreach (var item in re)
                            {
                                doc.Remove(item);
                                var WebRootPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot\\DocumetsActivity\\");
                                var uppath = WebRootPath + item;
                                if (System.IO.File.Exists(uppath)) System.IO.File.Delete(uppath);
                            }
                        }
                    }
                    if (data.RemoveDocName != null)
                    {
                        foreach (var Doc in data.RemoveDocName)
                        {
                            var re = Doc.Split(",").ToList();
                            foreach (var item in re)
                            {
                                docName.Remove(item);
                            }
                        }
                    }
                    if (data.Documents != null)
                    {
                        foreach (var item in data.Documents)
                        {
                            var WebRootPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot\\DocumetsActivity\\");
                            var uploads = Path.Combine(WebRootPath);
                            if (!Directory.Exists(uploads)) Directory.CreateDirectory(uploads);
                            string nameDocOriginal = item.FileName;
                            string nameDoc = Guid.NewGuid() + Path.GetExtension(item.FileName);
                            var fileStream = new FileStream(Path.Combine(uploads, nameDoc), FileMode.Create);
                            await item.CopyToAsync(fileStream);
                            doc.Add(nameDoc);
                            docName.Add(nameDocOriginal);
                        }
                    }

                    var Stringimg = tmp.Where(a => a != "").ToList();
                    var Stringdoc = doc.Where(a => a != "").ToList();
                    var StringdocName = docName.Where(a => a != "").ToList();

                    ac.Image = Stringimg.Count > 0 ? String.Join(",", Stringimg) : null;
                    ac.DocNameOriginal = StringdocName.Count > 0 ? String.Join(",", StringdocName) : null;
                    ac.Documents = Stringdoc.Count > 0 ? String.Join(",", Stringdoc) : null;
                    ac.ActivityTitle = data.ActivityTitle;
                    ac.ActivityDetail = data.ActivityDetail;
                    ac.StartDate = data.StartDate;
                    ac.EndDate = data.EndDate;
                    ac.ActivityType = data.ActivityType;
                    ac.PublishStatus = data.PublishStatus;
                    ac.PublishDate = data.PublishDate;

                    _InternshipContext.Entry(ac).State = EntityState.Modified;
                    await _InternshipContext.SaveChangesAsync();

                    return Ok(new { StatusCode = 1, Message = "แก้ไขสำเร็จ" });
                }
                return Ok(new { StatusCode = 0, Message = "แก้ไขไม่สำเร็จ" });

            }
            catch (Exception e)
            {
                return BadRequest(new Messages() { StatusCode = 0, Message = e.Message });
            }
        }

        [HttpDelete("DelActivity")]
        public async Task<ActionResult<Activity>> DelActivity(int id)
        {
            var result = await _InternshipContext.Activities.FindAsync(id);
            if (result == null) return CreatedAtAction(nameof(DelActivity), new Messages() { StatusCode = 0, Message = "ไม่พบข้อมูล!" });

            try
            {
                if (result.Image != null)
                {
                    string[] img = result.Image.Split(',');
                    foreach (var item in img)
                    {
                        var WebRootPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot\\FileActivtiy\\");
                        var uppath = WebRootPath + item;
                        if (System.IO.File.Exists(uppath)) System.IO.File.Delete(uppath);
                    }
                }
                if (result.Documents != null)
                {
                    string[] doc = result.Documents.Split(',');
                    foreach (var item in doc)
                    {
                        var WebRootPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot\\DocumetsActivity\\");
                        var uppath = WebRootPath + item;
                        if (System.IO.File.Exists(uppath)) System.IO.File.Delete(uppath);
                    }
                }


                _InternshipContext.Activities.Remove(result);
                await _InternshipContext.SaveChangesAsync();

                return CreatedAtAction(nameof(DelActivity), new Messages() { StatusCode = 1, Message = "ลบสำเร็จ" });
            }
            catch (Exception e)
            {
                return CreatedAtAction(nameof(DelActivity), new Messages() { StatusCode = 0, Message = e.Message });
            }
        }
    }
}
