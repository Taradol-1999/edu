﻿using _63_API_EOFFICE.Models.Response;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PJ_BACKEND_64.Models.Data;
using PJ_BACKEND_64.Models.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PJ_BACKEND_64.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class CheckActivityController : ControllerBase
    {
        private readonly InternshipSystemContext _InternshipContext = new InternshipSystemContext();

        //[HttpGet("LoadActivity")]
        //public ActionResult LoadActivity()
        //{  
        //    try
        //    {
        //        var result = _InternshipContext.Activities.Where(a => a.OpenCheck == "1").ToList();
        //        var query = result.Select(values => new
        //        {
        //            values.AcId,
        //            values.Name,
        //            values.PubDetail,
        //            values.StartDate,
        //            values.EndDate,
        //            values.PublishDate,
        //            values.Force,
        //            values.OpenCheck
        //        });
        //        var resultCount = query.Count();
        //        return Ok(new { DATA = query });
        //    }
        //    catch (Exception)
        //    {
        //        return CreatedAtAction(nameof(LoadActivity), new Messages() { StatusCode = 0, Message = "เกิดข้อผิดพลาด !" });
        //    }
        //}

        //[HttpGet("GetRegis")]
        //public async Task<ActionResult<Activity>> GetRegis()
        //{
        //    try
        //    {
        //        var query = await _InternshipContext.Registers.OrderByDescending(a => a.Year).ThenByDescending(a => a.Semester).Select(values => new
        //        {
        //            values.RegisId,
        //            values.StudId,
        //            values.Semester,
        //            values.Year
        //        }).ToListAsync();

        //        return Ok(new { DATA = query });
        //    }
        //    catch (Exception)
        //    {
        //        return CreatedAtAction(nameof(GetRegis), new Messages() { StatusCode = 0, Message = "ไม่พบข้อมูล !" });
        //    }
        //}

        //[HttpGet("DataCheckActivity")]
        //public ActionResult DataCheckActivity(string search = "", int pageSize = 10, int currentPage = 1)
        //{
        //    System.Globalization.CultureInfo _cultureTHInfo = new System.Globalization.CultureInfo("th-TH");
        //    System.Globalization.CultureInfo _cultureEngInfo = new System.Globalization.CultureInfo("en-US");
        //    try
        //    {
        //        int RowCount = 0;
        //        var result = _InternshipContext.Checkactivities.Include(e => e.Ac).Include(r => r.Regis).ToList();

        //        if (search != null)
        //        {
        //            result = result.Where(a =>
        //            a.Ac.Name.Contains(search)).ToList();
        //        }


        //        RowCount = result.Count;
        //        var pageCount = (double)RowCount / pageSize;
        //        pageCount = (int)Math.Ceiling(pageCount);

        //        result = result.OrderByDescending(a => a.AcId).Skip((currentPage - 1) * pageSize).Take(pageSize).ToList();

        //        var query = result.Select(values => new
        //        {
        //            values.CheckId,
        //            values.RegisId,
        //            values.Ac,
        //            values.Status,
        //            values.AcId,
        //            values.Ac.Name,
        //            values.Ac.PubDetail,
        //            StartDate = Convert.ToDateTime(values.Ac.StartDate).ToString("dd MMMM yyyy", _cultureTHInfo),
        //            EndDate = Convert.ToDateTime(values.Ac.EndDate).ToString("dd MMMM yyyy", _cultureTHInfo),
        //            PublishDate = Convert.ToDateTime(values.Ac.PublishDate).ToString("dd MMMM yyyy", _cultureTHInfo),
        //            values.Ac.Force,
        //            values.Regis.Year,
        //            values.Regis.Semester,
        //        });

        //        var resultCount = query.Count();


        //        return Ok(new { DATA = query, paging = new { currentPage, RowCount, pageSize, pageCount, resultCount } });
        //    }
        //    catch (Exception)
        //    {
        //        return CreatedAtAction(nameof(DataCheckActivity), new Messages() { StatusCode = 0, Message = "เกิดข้อผิดพลาด !" });
        //    }
        //}

        //[HttpGet("GetCheck")]
        //public async Task<ActionResult<Activity>> GetCheck()
        //{
        //    try
        //    {
        //        var query = await _InternshipContext.Checkactivities.Select(x => new
        //        {
        //            x.CheckId,
        //            x.AcId,
        //            x.RegisId,
        //            x.Status

        //        }).ToListAsync();

        //        return Ok(new { DATA = query });
        //    }
        //    catch (Exception)
        //    {
        //        return CreatedAtAction(nameof(GetCheck), new Messages() { StatusCode = 0, Message = "ไม่พบข้อมูล !" });
        //    }
        //}

        //private string AutoCheck()
        //{
        //    string Data = "";

        //    DateTime Year = DateTime.Today;
        //    string lastYear = Year.ToString("yy");

        //    var Auto = _InternshipContext.Checkactivities.OrderByDescending(z => z.CheckId).FirstOrDefault();
        //    if (Auto == null)
        //    {
        //        return Data = "Ch" + lastYear + "001";
        //    }
        //    else
        //    {
        //        var g = Auto.CheckId.Length;
        //        var length = g - 4;
        //        var lastz = Auto.CheckId.Substring(4, length);
        //        return Data = "Ch" + lastYear + (Convert.ToInt32(lastz) + 1).ToString("D3");
        //    }
        //}

        //[HttpPost("CheckActivity")]
        //public async Task<IActionResult> CheckActivity([FromForm] CheckActivityReq data)
        //{
        //    try
        //    {
        //        _InternshipContext.Add(new Checkactivity()
        //        {
        //            CheckId = AutoCheck(),
        //            RegisId = data.RegisId,
        //            AcId = data.AcId,
        //            Status = "1"
        //        });

        //        var result = await _InternshipContext.Checkactivities.FirstOrDefaultAsync(p => p.RegisId.Equals(data.RegisId) && p.AcId.Equals(data.AcId));
        //        if (result != null) return CreatedAtAction(nameof(CheckActivity), new { StatusCode = 0, Message = "ลงทะเบียนแล้ว!" });

        //        await _InternshipContext.SaveChangesAsync();
        //        return CreatedAtAction(nameof(CheckActivity), new Messages() { StatusCode = 1, Message = "ลงทะเบียนสำเร็จ" });
        //    }
        //    catch (Exception)
        //    {
        //        return CreatedAtAction(nameof(CheckActivity), new Messages() { StatusCode = 0, Message = "ลงทะเบียนล้มเหลว !" });
        //    }
        //}

        //[HttpPut("UpdateCheckActivity")]
        //public async Task<IActionResult> UpdateCheckActivity([FromForm] CheckActivityReq data, string id)
        //{
        //    try
        //    {
        //        var check = await _InternshipContext.Checkactivities.AsNoTracking().FirstOrDefaultAsync(a => a.CheckId == id);
        //        if (check != null)
        //        {
        //            var values = new Checkactivity()
        //            {
        //                CheckId = id,
        //                RegisId = data.RegisId,
        //                AcId = data.AcId,
        //                Status = "2"
        //            };

        //            _InternshipContext.Entry(values).State = EntityState.Modified;
        //            await _InternshipContext.SaveChangesAsync();

        //            return CreatedAtAction(nameof(UpdateCheckActivity), new Messages() { StatusCode = 1, Message = "แก้ไขสำเร็จ" });
        //        }

        //        return CreatedAtAction(nameof(UpdateCheckActivity), new Messages() { StatusCode = 0, Message = "ไม่พบข้อมูล!" });
        //    }
        //    catch (Exception)
        //    {
        //        return CreatedAtAction(nameof(UpdateCheckActivity), new Messages() { StatusCode = 0, Message = "ผิดพลาด!" });
        //    }
        //}

    }
}
