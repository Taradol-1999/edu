﻿using _63_API_EOFFICE.Models.Response;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PJ_BACKEND_64.Models.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PJ_BACKEND_64.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class HomeController : ControllerBase
    {
        private readonly InternshipSystemContext _InternshipContext = new InternshipSystemContext();

       
       
      

        [HttpGet("LoadSchool")]
        public ActionResult LoadSchool(string search = "")
        {
            try
            {
                var result = _InternshipContext.Schools.ToList();
                var query = result.Select(values => new
                {
                    values.SchoolId,
                    values.SchoolName,
                    values.StatusElementary,
                    values.StatusHighSchool,
                    values.ElementaryLevel,
                    values.ElementarySchool,
                    values.Logo,
                    values.Phone,
                    values.Distance,
                    values.Address,

                });
                if (search != null)
                {
                    query = query.Where(a =>
                    a.SchoolName.Contains(search)).ToList();
                }
                return Ok(new { DATA = query });
            }
            catch (Exception)
            {
                return CreatedAtAction(nameof(LoadSchool), new Messages() { StatusCode = 0, Message = "เกิดข้อผิดพลาด !" });
            }
        }

        [HttpGet("LoadSchoolData")]
        public ActionResult LoadSchoolData()
        {
            try
            {
                var result = _InternshipContext.Schools.ToList();
                var query = result.Select(values => new
                {
                    values.SchoolId,
                    values.SchoolName,
                    values.StatusElementary,
                    values.StatusHighSchool,
                    values.ElementaryLevel,
                    values.ElementarySchool,
                    values.Logo,
                    values.Phone,
                    values.Distance,
                    values.Address,
                });
          
                return Ok(new { DATA = query });
            }
            catch (Exception)
            {
                return CreatedAtAction(nameof(LoadSchoolData), new Messages() { StatusCode = 0, Message = "เกิดข้อผิดพลาด !" });
            }
        }

    }
}
