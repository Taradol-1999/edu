﻿using _63_API_EOFFICE.Models.Response;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PJ_BACKEND_64.Models.Data;
using PJ_BACKEND_64.Models.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PJ_BACKEND_64.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly InternshipSystemContext _Context = new();

        private string GenerateUserId()
        {
            int ID = 1;
            int count = _Context.Users.Where(a => a.Role != "3").Count();
            if (count >= 1)
            {
                var data = _Context.Users.Where(a => a.Role != "3").OrderByDescending(a => a.UserId).FirstOrDefault();
                var id = data.UserId.Substring(3, 4);
                var gen = (DateTime.Now.ToString("yy") + "U" + (Convert.ToInt32(id) + 1).ToString("D4")).ToString();
                return gen;
            }
            return DateTime.Now.ToString("yy") + "U" + ID.ToString("D4");
        }

        [HttpGet("LoadData")]
        public ActionResult LoadData(string search = "", int pageSize = 10, int currentPage = 1, string role = "", int MaId = 0, int FacId = 0)
        {
            try
            {
                int RowCount = 0;
                var result = _Context.Users.Include(e => e.Major).ThenInclude(f => f.Faculty).Select(values => new
                {
                    values.UserId,
                    FullName = values.FirstName + " " + values.LastName,
                    values.PreFix,
                    values.FirstName,
                    values.LastName,
                    values.Phone,
                    values.UserName,
                    values.PassWord,
                    FacultyName = values.Major.Faculty.FacultyName ?? null,
                    FacultyId = values.Major.Faculty.FacultyId == null ? (int?)null : values.Major.Faculty.FacultyId,
                    MajorName = values.Major.MajorName ?? null,
                    values.MajorId,
                    values.Role,

                }).ToList();

                var query = result.Select(values => new
                {
                    values.UserId,
                    values.FullName,
                    values.PreFix,
                    values.FirstName,
                    values.LastName,
                    values.Phone,
                    values.UserName,
                    values.PassWord,
                    values.FacultyName,
                    values.FacultyId,
                    values.MajorName,
                    values.MajorId,
                    values.Role,
                });

                if (search != null)
                {
                    query = query.Where(a =>
                    a.FullName.Contains(search.TrimStart()) ||
                    a.FirstName.Contains(search.TrimStart()) ||
                    a.Phone.Contains(search.TrimStart()) ||
                    a.UserName.Contains(search.TrimStart()) ||
                    a.LastName.Contains(search.TrimStart()));
                }
                if (!string.IsNullOrEmpty(role))
                {
                    query = query.Where(a => a.Role.Equals(role));
                }
                if (MaId != 0)
                {
                    query = query.Where(a => a.MajorId == MaId);
                }
                if (FacId != 0)
                {
                    query = query.Where(a => a.FacultyId == FacId);
                }

                RowCount = query.Count();
                var pageCount = (double)RowCount / pageSize;
                pageCount = (int)Math.Ceiling(pageCount);
                query = query.OrderBy(a => a.UserId).Skip((currentPage - 1) * pageSize).Take(pageSize).ToList();

                return Ok(new { DATA = query, pagin = new { currentPage, RowCount, pageSize, pageCount } });
            }
            catch (Exception)
            {
                return CreatedAtAction(nameof(LoadData), new Messages() { StatusCode = 0, Message = "เกิดข้อผิดพลาด !" });
            }
        }

        [HttpPost("Register")]
        public async Task<IActionResult> Register([FromBody] UserReq data)
        {
            try
            {
                var result = await _Context.Users.FirstOrDefaultAsync(p => p.UserName.Equals(data.UserName) || p.UserId.Equals(data.UserId));

                if (result != null) return CreatedAtAction(nameof(Register), new { StatusCode = 0, Message = "ชื่อผู้ใช้นี้ลงทะเบียนแล้ว" });

                string userid = data.Role != "3" ? String.IsNullOrEmpty(data.UserId) ? GenerateUserId() : data.UserId : data.UserName;

                _Context.Users.Add(new User
                {
                    UserId = userid,
                    PreFix = data.PreFix,
                    FirstName = data.FirstName,
                    LastName = data.LastName,
                    UserName = data.UserName,
                    PassWord = data.PassWord,
                    Phone = data.Phone,
                    MajorId = data.MajorId,
                    Role = data.Role,
                });
                await _Context.SaveChangesAsync();

                return CreatedAtAction(nameof(Register), new Messages() { StatusCode = 1, Message = "ลงทะเบียนสำเร็จ" });
            }
            catch (Exception e)
            {
                return CreatedAtAction(nameof(Register), new Messages() { StatusCode = 0, Message = e.Message });
            }
        }

        [HttpGet("GetUserId/{id}")]
        public async Task<ActionResult<User>> GetUserId(string id)
        {
            try
            {
                var query = await _Context.Users.Where(a => a.UserId.Equals(id)).Include(e => e.Major).ThenInclude(f => f.Faculty).Select(values => new
                {
                    values.UserId,
                    values.PreFix,
                    values.FirstName,
                    values.LastName,
                    values.Phone,
                    values.UserName,
                    values.PassWord,
                    values.MajorId,
                    values.Major.FacultyId,
                    values.Role,

                }).FirstOrDefaultAsync();

                return Ok(new { DATA = query });
            }
            catch (Exception)
            {
                return CreatedAtAction(nameof(GetUserId), new Messages() { StatusCode = 0, Message = "ไม่พบข้อมูล !" });
            }
        }

        [HttpPut("UpdateUser/{id}")]
        public async Task<IActionResult> UpdateUser([FromBody] UserReq data, string id)
        {
            try
            {
                var school = await _Context.Users.AsNoTracking().FirstOrDefaultAsync(a => a.UserId.Equals(id));
                if (school != null)
                {
                    var result = new User()
                    {
                        UserId = id,
                        PreFix = data.PreFix,
                        FirstName = data.FirstName,
                        LastName = data.LastName,
                        UserName = data.UserName,
                        PassWord = data.PassWord,
                        Phone = data.Phone,
                        MajorId = data.MajorId,
                        Role = data.Role,
                    };
                    _Context.Entry(result).State = EntityState.Modified;
                    await _Context.SaveChangesAsync();
                    return CreatedAtAction(nameof(UpdateUser), new Messages() { StatusCode = 1, Message = "แก้ไขสำเร็จ" });
                }

                return CreatedAtAction(nameof(UpdateUser), new Messages() { StatusCode = 0, Message = "ไม่พบข้อมูล!" });
            }
            catch (Exception e)
            {
                return CreatedAtAction(nameof(UpdateUser), new Messages() { StatusCode = 0, Message = e.Message });
            }
        }

        [HttpDelete("Delete")]
        public async Task<ActionResult<User>> Delete(string id)
        {
            var result = await _Context.Users.FindAsync(id);
            if (result == null) return CreatedAtAction(nameof(Delete), new Messages() { StatusCode = 0, Message = "ไม่พบข้อมูล !" });

            try
            {
                _Context.Users.Remove(result);
                await _Context.SaveChangesAsync();
                return CreatedAtAction(nameof(Delete), new Messages() { StatusCode = 1, Message = "ลบสำเร็จ" });
            }
            catch (Exception)
            {
                return CreatedAtAction(nameof(Delete), new Messages() { StatusCode = 0, Message = "ผิดพลาด !" });
            }
        }

        [HttpPost("CreateMajor")]
        public async Task<IActionResult> CreateMajor([FromBody] MajorReq data)
        {
            try
            {
                var result = await _Context.Majors.FirstOrDefaultAsync(p => p.MajorName.Equals(data.MajorName) && p.FacultyId == data.FacultyID);

                if (result != null) return CreatedAtAction(nameof(CreateMajor), new { StatusCode = 0, Message = "มีสาขานี้มีอยุ่แล้ว" });

                _Context.Majors.Add(new Major
                {
                    MajorName = data.MajorName,
                    FacultyId = data.FacultyID,
                });
                await _Context.SaveChangesAsync();

                return CreatedAtAction(nameof(CreateMajor), new Messages() { StatusCode = 1, Message = "เพิ่มสาขาสำเร็จ" });
            }
            catch (Exception e)
            {
                return CreatedAtAction(nameof(CreateMajor), new Messages() { StatusCode = 0, Message = e.Message });
            }
        }

        [HttpPost("CreatePreFix")]
        public async Task<IActionResult> CreatePreFix([FromBody] PreFixReq data)
        {
            try
            {
                var result = await _Context.Titles.FirstOrDefaultAsync(p => p.TitleName.Equals(data.PreFix));

                if (result != null) return CreatedAtAction(nameof(CreatePreFix), new { StatusCode = 0, Message = "มีคำนำหน้านี้มีอยุ่แล้ว" });

                _Context.Titles.Add(new Title
                {
                    TitleName = data.PreFix,
                });
                await _Context.SaveChangesAsync();

                return CreatedAtAction(nameof(CreatePreFix), new Messages() { StatusCode = 1, Message = "เพิ่มสำเร็จ" });
            }
            catch (Exception e)
            {
                return CreatedAtAction(nameof(CreatePreFix), new Messages() { StatusCode = 0, Message = e.Message });
            }
        }

    }
}
