﻿using _63_API_EOFFICE.Models.Response;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PJ_BACKEND_64.Models.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PJ_BACKEND_64.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class DashboardController : ControllerBase
    {
        private readonly InternshipSystemContext _Context = new();



        [HttpGet("DataDashboard")]
        public ActionResult DataDashboard(string Year = "", string Semester = "",string BackYears ="")
        {
            try
            {
          
                var Major = _Context.Majors.OrderBy(a => a.FacultyId).Select(a => new { a.MajorName, a.MajorId }).ToList();
                var School = _Context.Schools.ToList();
                var Student = _Context.Users.Where(a => a.Role == "3").ToList();
                var Instructor = _Context.Users.Where(a => a.Role == "2").Select(a => new
                {
                    a.Major.MajorName,
                    a.Major.Faculty.FacultyId,
                    a.Major.Faculty.FacultyName,
                }).ToList();

                var Regis = _Context.Registers.Select(a => new
                {
                    a.RegisId,
                    a.Semester,
                    a.Year,
                    a.Stud.Major.Faculty.FacultyId,
                    a.Stud.Major.MajorId,

                }).ToList();
                if (!string.IsNullOrEmpty(Year))
                {
                    Regis = Regis.Where(a => a.Year == Year).ToList();
                }
                if (!string.IsNullOrEmpty(Semester))
                {
                    Regis = Regis.Where(a => a.Semester == Semester).ToList();
                }



                var addArray = "";
                string CountRegisterByMajor = string.Empty;
                int CountKey = 0;
                if (Regis != null)
                {
                    foreach (var item in Major)
                    {
                        addArray = Regis.Where(a => a.MajorId == item.MajorId).Count().ToString();

                        if (CountKey == 0)
                        {
                            CountRegisterByMajor = addArray;
                        }
                        else
                        {
                            CountRegisterByMajor += "," + addArray;
                        }
                        CountKey++;
                    }
                }

                var BackYearsArray = "";
                string Back5Years = string.Empty;
                int BackYearsKey = 0;
                if (BackYears != "")
                {
                    var data = BackYears.Split(',').ToList();

                    foreach (var item in data)
                    {
                        BackYearsArray = _Context.Registers.Where(a => a.Year == item.ToString()).Count().ToString();

                        if (BackYearsKey == 0)
                        {
                            Back5Years = BackYearsArray;
                        }
                        else
                        {
                            Back5Years += "," + BackYearsArray;
                        }
                        BackYearsKey++;
                    }
                }


                return Ok(new { Major, Regis, Student, School, Instructor, CountRegisterByMajor ,Back5Years});
            }
            catch (Exception e)
            {
                return CreatedAtAction(nameof(DataDashboard), new Messages() { StatusCode = 0, Message = e.Message });
            }
        }

    }
}
