﻿using _63_API_EOFFICE.Models.Response;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PJ_BACKEND_64.Models.Data;
using PJ_BACKEND_64.Models.Response;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PJ_BACKEND_64.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class AppointController : ControllerBase
    {
        private readonly InternshipSystemContext _InternshipContext = new InternshipSystemContext();

        [HttpGet("SearchRegister")]
        public ActionResult SearchRegister(string Year = "", string Semester = "", string School = "")
        {
            try
            {
                var dataApp = _InternshipContext.Appoints.Select(a => new
                {
                    a.AppointId,
                    a.Regis.Semester,
                    a.Regis.Year,
                    a.Regis.Stud.UserId,
                    a.Regis.School.SchoolId

                }).ToList();

                var result = _InternshipContext.Registers.Select(values => new
                {
                    values.RegisId,
                    values.Semester,
                    values.Year,
                    //นักเรียน
                    values.StudId,
                    FullName = values.Stud.PreFixNavigation.TitleName + " " + values.Stud.FirstName + " " + values.Stud.LastName,
                    values.Stud.Major.MajorId,
                    values.Stud.Major.MajorName,
                    values.Stud.Major.Faculty.FacultyName,
                    values.Stud.Major.Faculty.FacultyId,
                    //โรงเรียน
                    values.SchoolId,
                    values.School.SchoolName,
                    //อาจารย์
                    instructorMajor = "",
                    instructorProfession = ""

                }).ToList();

                var query = result.Where(i => dataApp.FirstOrDefault(a => a.UserId == i.StudId) == null).ToList();

                if (!string.IsNullOrEmpty(School))
                {
                    query = query.Where(x => x.SchoolId == School).ToList();
                }
                if (!string.IsNullOrEmpty(Year))
                {
                    query = query.Where(x => x.Year == Year).ToList();
                }
                if (!string.IsNullOrEmpty(Semester))
                {
                    query = query.Where(x => x.Semester == Semester).ToList();
                }

                return Ok(new { data = query });
            }
            catch (Exception)
            {
                return CreatedAtAction(nameof(SearchRegister), new Messages() { StatusCode = 0, Message = "เกิดข้อผิดพลาด !" });
            }
        }

        [HttpPost("RegisAppiont")]
        public async Task<IActionResult> RegisAppiont(AppointReq data)
        {
            try
            {
                var item = new List<Appoint>(data.AppointArray.Select(value => new Appoint
                {
                    InstructorProfession = value.InstructorProfession,
                    InstructorMajor = value.InstructorMajor,
                    RegisId = value.RegisId,
                    AppointmentDate = DateTime.Now

                }));
                await _InternshipContext.AddRangeAsync(item);
                await _InternshipContext.SaveChangesAsync();

                return CreatedAtAction(nameof(RegisAppiont), new Messages() { StatusCode = 1, Message = "ลงทะเบียนสำเร็จ" });
            }
            catch (Exception e)
            {
                return CreatedAtAction(nameof(RegisAppiont), new Messages() { StatusCode = 0, Message = e.Message });
            }
        }

        [HttpGet("LoadAppoint")]
        public ActionResult LoadAppoint(string search = "", int pageSize = 10, int currentPage = 1, string Year = "", string Semester = "", int MaId = 0, int FacId = 0)
        {
            try
            {
                int RowCount = 0;
                var query = _InternshipContext.Appoints.Select(data => new
                {
                    data.AppointId,
                    data.Regis.School.SchoolName,
                    StudId = data.Regis.Stud.UserId,
                    data.Regis.Stud.Major.MajorId,
                    data.Regis.Stud.Major.MajorName,
                    data.Regis.Stud.Major.Faculty.FacultyId,
                    data.Regis.Stud.Major.Faculty.FacultyName,
                    FullNameStud = data.Regis.Stud.PreFixNavigation.TitleName + " " + data.Regis.Stud.FirstName + " " + data.Regis.Stud.LastName,
                    FullNameInstructorMajor = data.InstructorMajorNavigation.PreFixNavigation.TitleName + " " + data.InstructorMajorNavigation.FirstName + " " + data.InstructorMajorNavigation.LastName,
                    FullNameInstructorProfession = data.InstructorProfessionNavigation.PreFixNavigation.TitleName + " " + data.InstructorProfessionNavigation.FirstName + " " + data.InstructorProfessionNavigation.LastName,
                    data.Regis.Semester,
                    data.Regis.Year
                }).ToList();

                if (!string.IsNullOrEmpty(search))
                {
                    query = query.Where(a =>
                    a.FullNameStud.Contains(search.TrimStart()) ||
                    a.StudId.Contains(search.TrimStart()) ||
                    a.SchoolName.Contains(search.TrimStart()) ||
                    a.FullNameInstructorProfession.Contains(search.TrimStart()) ||
                    a.FullNameInstructorMajor.Contains(search.TrimStart())).ToList();
                }
                if (!string.IsNullOrEmpty(Year))
                {
                    query = query.Where(a => a.Year == Year).ToList();
                }
                if (!string.IsNullOrEmpty(Semester))
                {
                    query = query.Where(a => a.Semester == Semester).ToList();
                }
                if (MaId != 0)
                {
                    query = query.Where(a => a.MajorId == MaId).ToList();
                }
                if (FacId != 0)
                {
                    query = query.Where(a => a.FacultyId == FacId).ToList();
                }

                RowCount = query.Count;
                var pageCount = (double)RowCount / pageSize;
                pageCount = (int)Math.Ceiling(pageCount);
                query = query.OrderByDescending(a => a.AppointId).Skip((currentPage - 1) * pageSize).Take(pageSize).ToList();
              

                return Ok(new { data = query.OrderByDescending(a => a.Year).ThenByDescending(a => a.Semester), paging = new { currentPage, RowCount, pageSize, pageCount } });
            }
            catch (Exception)
            {
                return CreatedAtAction(nameof(LoadAppoint), new Messages() { StatusCode = 0, Message = "เกิดข้อผิดพลาด !" });
            }
        }

        [HttpGet("LoadDetail")]
        public async Task<ActionResult<Appoint>> LoadDetail(int id)
        {
            try
            {
                var query = await _InternshipContext.Appoints.Where(a => a.AppointId == id).Select(data => new
                {
                    data.AppointId,
                    data.Regis.School.SchoolId,
                    FullNameStud = data.Regis.Stud.PreFixNavigation.TitleName + " " + data.Regis.Stud.FirstName + " " + data.Regis.Stud.LastName,
                    data.Regis.Stud.Major.MajorName,
                    data.Regis.Stud.Major.Faculty.FacultyName,
                    data.Regis.School.SchoolName,
                    StudentId = data.Regis.Stud.UserId,
                    data.Regis.Semester,
                    data.Regis.Year,
                    data.InstructorMajor,
                    data.InstructorProfession,

                }).FirstOrDefaultAsync();

                return Ok(new { data = query });
            }
            catch (Exception)
            {
                return CreatedAtAction(nameof(LoadDetail), new Messages() { StatusCode = 0, Message = "ไม่พบข้อมูล !" });
            }
        }

        [HttpPut("UpdateAppiont")]
        public async Task<IActionResult> UpdateAppiont(AppointUp data, int id)
        {
            try
            {
                var result = await _InternshipContext.Appoints.AsNoTracking().FirstOrDefaultAsync(p => p.AppointId == id);
                if (result == null) return CreatedAtAction(nameof(UpdateAppiont), new Messages() { StatusCode = 0, Message = "แก้ไขไม่สำเร็จ!" });

                result.InstructorMajor = data.InstructorMajor;
                result.InstructorProfession = data.InstructorProfession;

                _InternshipContext.Entry(result).State = EntityState.Modified;
                await _InternshipContext.SaveChangesAsync();

                return CreatedAtAction(nameof(UpdateAppiont), new Messages() { StatusCode = 1, Message = "แก้ไขสำเร็จ" });
            }
            catch (Exception)
            {
                return CreatedAtAction(nameof(UpdateAppiont), new Messages() { StatusCode = 0, Message = "ล้มเหลว !" });
            }
        }

        [HttpDelete("DelAppoint")]
        public async Task<ActionResult<Appoint>> DelAppoint(int id)
        {
            var result = await _InternshipContext.Appoints.FindAsync(id);
            if (result == null) return CreatedAtAction(nameof(DelAppoint), new Messages() { StatusCode = 0, Message = "ไม่พบข้อมูล!" });

            try
            {
                _InternshipContext.Appoints.Remove(result);
                await _InternshipContext.SaveChangesAsync();
                return CreatedAtAction(nameof(DelAppoint), new Messages() { StatusCode = 1, Message = "ลบสำเร็จ" });
            }
            catch (Exception)
            {

                return CreatedAtAction(nameof(DelAppoint), new Messages() { StatusCode = 0, Message = "ผิดพลาด!" });
            }
        }
    }
}
