﻿using _63_API_EOFFICE.Models.Response;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using PJ_BACKEND_64.Models.Data;
using PJ_BACKEND_64.Models.Querise;
using PJ_BACKEND_64.Models.Response;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace PJ_BACKEND_64.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class AuthenController : ControllerBase
    {

        private readonly AccessTokenQ _authenticationQ = new();

        [HttpPost("Login")]
        public async Task<IActionResult> Login([FromBody] Auten login)
        {
            try
            {
                var result = await _authenticationQ.Login(login);
                return StatusCode(200, result);
                //return Ok(new { result });
            }
            catch (Exception e)
            {
                return BadRequest(new Messages() { StatusCode = 0, Message = e.Message });
            }
        }
    }
}
