﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using _63_API_EOFFICE.Models.Response;
using Microsoft.EntityFrameworkCore;
using PJ_BACKEND_64.Models.Data;
using PJ_BACKEND_64.Models.Querise;
using PJ_BACKEND_64.Models.Response;
using System.Globalization;

namespace PJ_BACKEND_64.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class RegisterController : ControllerBase
    {
        private readonly InternshipSystemContext _InternshipContext = new();

        private string AutoReId()
        {
            string Data = "";

            DateTime Year = DateTime.Today;
            string lastYear = Year.ToString("yy");

            var AutoReId = _InternshipContext.Registers.OrderByDescending(z => z.RegisId).FirstOrDefault();
            if (AutoReId == null)
            {
                return Data = "R" + lastYear + "00001";
            }
            else
            {
                var g = AutoReId.RegisId.Length;
                var length = g - 3;
                var lastz = AutoReId.RegisId.Substring(3, length);
                return Data = "R" + lastYear + (Convert.ToInt32(lastz) + 1).ToString("D5");
            }
        }

        [HttpPost("Registers")]
        public async Task<IActionResult> Registers([FromBody] RegisterReq data)
        {
            var resultUser = await _InternshipContext.Users.Where(a => a.Role == "3").FirstOrDefaultAsync(p => p.UserId == data.StudId);

            if (resultUser == null) return CreatedAtAction(nameof(Registers), new { StatusCode = 0, Message = "ไม่พบรหัสนักศึกษา" });

            var resultRegis = await _InternshipContext.Registers.FirstOrDefaultAsync(p => p.StudId.Equals(data.StudId) && p.Semester.Equals(data.Semester) && p.Year.Equals(data.Year));

            if (resultRegis != null) return CreatedAtAction(nameof(Registers), new { StatusCode = 0, Message = "รหัสนักศึกษานี้ได้ทำการลงทะเบียนในปีการศึกษานี้และเทอมนี้แล้ว" });

            try
            {
                _InternshipContext.Add(new Register()
                {
                    RegisId = AutoReId(),
                    StudId = data.StudId,
                    SchoolId = data.SchoolId,
                    Semester = data.Semester,
                    Year = data.Year,
                    StartTraining = data.StartTraining,
                    EndTraining = data.EndTraining,
                    GroupLearning = data.GroupLearning
                });

                await _InternshipContext.SaveChangesAsync();
                return CreatedAtAction(nameof(Registers), new Messages() { StatusCode = 1, Message = "ลงทะเบียนสำเร็จ " });
            }
            catch (Exception e)
            {
                return CreatedAtAction(nameof(Registers), new Messages() { StatusCode = 0, Message = e.Message });
            }
        }

        [HttpPut("UpdateRegisters/{id}")]
        public async Task<IActionResult> UpdateRegisters(RegisterReq data, string id)
        {
            try
            {
                var result = await _InternshipContext.Registers.AsNoTracking().FirstOrDefaultAsync(a => a.RegisId.Equals(id));
                if (result == null) return CreatedAtAction(nameof(UpdateRegisters), new Messages() { StatusCode = 0, Message = "ไม่พบข้อมูล !" });

                result.StudId = data.StudId;
                result.SchoolId = data.SchoolId;
                result.Semester = data.Semester;
                result.Year = data.Year;
                result.StartTraining = data.StartTraining;
                result.EndTraining = data.EndTraining;
                result.GroupLearning = data.GroupLearning;

                _InternshipContext.Entry(result).State = EntityState.Modified;
                await _InternshipContext.SaveChangesAsync();

                return CreatedAtAction(nameof(UpdateRegisters), new Messages() { StatusCode = 1, Message = "แก้ไขสำเร็จ" });

            }
            catch (Exception)
            {
                return CreatedAtAction(nameof(UpdateRegisters), new Messages() { StatusCode = 0, Message = "ล้มเหลว!" });
            }
        }

        [HttpGet("LoadRegister")]
        public ActionResult GetRegister(string search = "", int pageSize = 10, int currentPage = 1, int MaId = 0, int FacId = 0, string Year = "", string Term = "", string UserId = "")
        {
            try
            {
                int RowCount = 0;
                var query = _InternshipContext.Registers.Select(values => new
                {
                    values.RegisId,
                    values.Semester,
                    values.Year,
                    //นักเรียน
                    values.StudId,
                    FullName = values.Stud.PreFixNavigation.TitleName + " " + values.Stud.FirstName + " " + values.Stud.LastName,
                    values.Stud.Major.MajorId,
                    values.Stud.Major.MajorName,
                    values.Stud.Major.Faculty.FacultyName,
                    values.Stud.Major.Faculty.FacultyId,
                    //โรงเรียน
                    values.SchoolId,
                    values.School.SchoolName,
                }).ToList();

                if (!string.IsNullOrEmpty(UserId))
                {
                    query = query.Where(a => a.StudId == UserId).ToList();
                }
                if (!string.IsNullOrEmpty(search))
                {
                    query = query.Where(a =>
                    a.StudId.Contains(search.TrimStart()) ||
                    a.FullName.Contains(search.TrimStart()) ||
                    a.SchoolName.Contains(search.TrimStart())).ToList();
                }
                if (MaId != 0)
                {
                    query = query.Where(a => a.MajorId == MaId).ToList();
                }
                if (FacId != 0)
                {
                    query = query.Where(a => a.FacultyId == FacId).ToList();
                }
                if (!string.IsNullOrEmpty(Year))
                {
                    query = query.Where(a => a.Year == Year).ToList();
                }
                if (!string.IsNullOrEmpty(Term))
                {
                    query = query.Where(a => a.Semester == Term).ToList();
                }

                RowCount = query.Count;
                var pageCount = (double)RowCount / pageSize;
                pageCount = (int)Math.Ceiling(pageCount);
                query = query.OrderByDescending(a => a.RegisId).Skip((currentPage - 1) * pageSize).Take(pageSize).ToList();

                return Ok(new { DATA = query, paging = new { currentPage, RowCount, pageSize, pageCount } });
            }
            catch (Exception)
            {
                return CreatedAtAction(nameof(GetRegister), new Messages() { StatusCode = 0, Message = "เกิดข้อผิดพลาด !" });
            }
        }

        [HttpDelete("DeleteRegis")]
        public async Task<ActionResult<Register>> DeleteRegis(string id)
        {
            var result = await _InternshipContext.Registers.FindAsync(id);
            if (result == null) return CreatedAtAction(nameof(DeleteRegis), new Messages() { StatusCode = 0, Message = "ไม่พบข้อมูล !" });
            try
            {
                _InternshipContext.Registers.Remove(result);
                await _InternshipContext.SaveChangesAsync();
                return CreatedAtAction(nameof(DeleteRegis), new Messages() { StatusCode = 1, Message = "ลบสำเร็จ" });
            }
            catch (Exception)
            {
                return CreatedAtAction(nameof(DeleteRegis), new Messages() { StatusCode = 0, Message = "ผิดพลาด !" });
            }
        }

        [HttpGet("GetRegisterId/{id}")]
        public async Task<ActionResult<Register>> GetRegisterId(string id)
        {
            try
            {
                var query = await _InternshipContext.Registers.Where(a => a.RegisId.Equals(id)).Select(values => new
                {
                    values.RegisId,
                    values.SchoolId,
                    values.Semester,
                    values.Year,
                    values.StudId,
                    StartTraining = Convert.ToDateTime(values.StartTraining).ToString("yyyy-MM-dd", new CultureInfo("en-US")),
                    EndTraining = Convert.ToDateTime(values.EndTraining).ToString("yyyy-MM-dd", new CultureInfo("en-US")),
                    values.GroupLearning,

                }).FirstOrDefaultAsync();

                return Ok(query);
            }
            catch (Exception)
            {
                return CreatedAtAction(nameof(GetRegisterId), new Messages() { StatusCode = 0, Message = "ไม่พบข้อมูล !" });
            }
        }
    }
}
