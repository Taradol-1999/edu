﻿using _63_API_EOFFICE.Models.Response;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PJ_BACKEND_64.Models.Data;
using PJ_BACKEND_64.Models.Response;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace PJ_BACKEND_64.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class SchoolController : ControllerBase
    {
        private readonly InternshipSystemContext _InternshipContext = new();
        private readonly IWebHostEnvironment _environment;
        public SchoolController(IWebHostEnvironment environment)
        {
            _environment = environment;

        }
        private string AutoSchool()
        {
            string Data = "";
            DateTime Year = DateTime.Today;
            string lastYear = Year.ToString("yy");

            var Auto = _InternshipContext.Schools.OrderByDescending(z => z.SchoolId).FirstOrDefault();

            if (Auto == null)
            {
                return Data = "SC" + lastYear + "0001";
            }
            else
            {
                var g = Auto.SchoolId.Length;
                var length = g - 4;
                var lastz = Auto.SchoolId.Substring(4, length);
                return Data = "SC" + lastYear + (Convert.ToInt32(lastz) + 1).ToString("D4");
            }
        }

        [HttpGet("LoadSchool")]
        public ActionResult LoadSchool(string search = "", int pageSize = 10, int currentPage = 1)
        {
            try
            {
                int RowCount = 0;
                var result = _InternshipContext.Schools.ToList();
                var url = this.HttpContext.Request.Host.Value;
                var query = result.Select(values => new
                {
                    values.SchoolId,
                    values.SchoolName,
                    values.StatusElementary,
                    values.StatusHighSchool,
                    values.ElementaryLevel,
                    values.ElementarySchool,
                    LogoSchool = values.Logo != null ? "https://" + url + "/LogoSchool/" + values.Logo.ToString() : "",
                    values.Phone,
                    values.Distance,
                    values.Address,
                });

                if (search != null)
                {
                    query = query.Where(a =>
                    a.SchoolName.Contains(search.TrimStart()) ||
                    a.Phone.Contains(search.TrimStart())).ToList();
                }

                RowCount = query.Count();
                var pageCount = (double)RowCount / pageSize;
                pageCount = (int)Math.Ceiling(pageCount);
                query = query.OrderBy(a => a.SchoolName).Skip((currentPage - 1) * pageSize).Take(pageSize).ToList();

                return Ok(new { DATA = query, pagin = new { currentPage, RowCount, pageSize, pageCount } });
            }
            catch (Exception)
            {
                return CreatedAtAction(nameof(LoadSchool), new Messages() { StatusCode = 0, Message = "เกิดข้อผิดพลาด !" });
            }
        }

        [HttpPost("RegisSchool")]
        public async Task<IActionResult> RegisSchool([FromForm] SchoolReq values)
        {
            try
            {
                string images = "";
                if (values.Logo != null)
                {
                    string WebRootPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot\\LogoSchool\\");
                    string uploads = Path.Combine(WebRootPath);
                    if (!Directory.Exists(uploads)) Directory.CreateDirectory(uploads);
                    images = Guid.NewGuid() + "." + values.Logo.ContentType.Split("/")[1];
                    var fileStream = new FileStream(Path.Combine(uploads, images), FileMode.Create);
                    await values.Logo.CopyToAsync(fileStream);
                }

                string SchoolId = AutoSchool();
                _InternshipContext.Add(new School()
                {
                    SchoolId = SchoolId,
                    SchoolName = values.SchoolName,
                    Address = values.Address,
                    ElementarySchool = values.StatusElementary == "1" ? "ปฐมวัย" : "-",
                    StatusElementary = values.StatusElementary,
                    ElementaryLevel = values.ElementaryLevel,
                    StatusHighSchool = values.StatusHighSchool,
                    Distance = values.Distance,
                    Phone = values.Phone,
                    Logo = images == "" ? null : images,
                });

                await _InternshipContext.SaveChangesAsync();
                return CreatedAtAction(nameof(RegisSchool), new Messages() { StatusCode = 1, Message = "ลงทะเบียนสำเร็จ" });
            }
            catch (Exception e)
            {
                return CreatedAtAction(nameof(RegisSchool), new Messages() { StatusCode = 0, Message = e.Message });
            }
        }

        [HttpGet("GetID")]
        public async Task<ActionResult<School>> GetID(string id)
        {
            try
            {
                var url = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}";
                var query = await _InternshipContext.Schools.Where(a => a.SchoolId == id).Select(values => new
                {
                    values.SchoolId,
                    values.SchoolName,
                    values.StatusElementary,
                    values.StatusHighSchool,
                    values.ElementaryLevel,
                    values.ElementarySchool,
                    values.Logo,
                    LogoUrl = !string.IsNullOrEmpty(values.Logo) ? url + "/LogoSchool/" + values.Logo : "",
                    values.Phone,
                    values.Distance,
                    values.Address,

                }).FirstOrDefaultAsync();

                return Ok(new { DATA = query });
            }
            catch (Exception)
            {
                return CreatedAtAction(nameof(GetID), new Messages() { StatusCode = 0, Message = "ไม่พบข้อมูล !" });
            }
        }

        [HttpPut("UpdateSchool/{id}")]
        public async Task<IActionResult> UpdateSchool([FromForm] SchoolReq values, string id)
        {
            try
            {
                var school = await _InternshipContext.Schools.AsNoTracking().FirstOrDefaultAsync(a => a.SchoolId == id);
                if (school != null)
                {
                    var img = "";
                    if (values.Logo != null)
                    {
                        string WebRootPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot\\LogoSchool\\" + school.Logo);
                        if (System.IO.File.Exists(WebRootPath)) System.IO.File.Delete(WebRootPath);
                        if (values.Logo.Length > 0)
                        {
                            img = id + "LOGO" + DateTime.Now.Date.ToString("ddMMyyyy") + "." + values.Logo.ContentType.Split("/")[1];
                            using FileStream filestream = System.IO.File.Create(_environment.WebRootPath + "\\LogoSchool\\" + img);
                            values.Logo.CopyTo(filestream);
                            filestream.Flush();
                        }
                    }

                    var data = new School()
                    {
                        SchoolId = id,
                        SchoolName = values.SchoolName,
                        Address = values.Address,
                        ElementarySchool = values.StatusElementary == "1" ? "ปฐมวัย" : "-",
                        StatusElementary = values.StatusElementary,
                        ElementaryLevel = values.ElementaryLevel,
                        StatusHighSchool = values.StatusHighSchool,
                        Distance = values.Distance,
                        Phone = values.Phone,
                        Logo = values.Logo != null ? img : _InternshipContext.Schools.AsNoTracking().First(a => a.SchoolId == id).Logo,
                    };

                    _InternshipContext.Entry(data).State = EntityState.Modified;
                    await _InternshipContext.SaveChangesAsync();

                    return CreatedAtAction(nameof(UpdateSchool), new Messages() { StatusCode = 1, Message = "แก้ไขสำเร็จ" });
                }

                return CreatedAtAction(nameof(UpdateSchool), new Messages() { StatusCode = 0, Message = "ไม่พบข้อมูล!" });
            }
            catch (Exception e)
            {
                return CreatedAtAction(nameof(UpdateSchool), new Messages() { StatusCode = 0, Message = e.Message });
            }
        }

        [HttpDelete("DelSchool")]
        public async Task<ActionResult<School>> DelSchool(string id)
        {
            var result = await _InternshipContext.Schools.FindAsync(id);
            if (result == null) return CreatedAtAction(nameof(DelSchool), new Messages() { StatusCode = 0, Message = "ไม่พบข้อมูล!" });
            try
            {
                var WebRootPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot\\LogoSchool\\");
                var uppath = WebRootPath + result.Logo;
                if (System.IO.File.Exists(uppath)) System.IO.File.Delete(uppath);

                _InternshipContext.Schools.Remove(result);
                await _InternshipContext.SaveChangesAsync();
                return CreatedAtAction(nameof(DelSchool), new Messages() { StatusCode = 1, Message = "ลบสำเร็จ" });
            }
            catch (Exception e)
            {
                return CreatedAtAction(nameof(DelSchool), new Messages() { StatusCode = 0, Message = e.Message });
            }
        }

        [HttpGet("PrintDataSchool")]
        public ActionResult PrintDataSchool()
        {
            try
            {
                var result = _InternshipContext.Schools.ToList();
                var url = this.HttpContext.Request.Host.Value;
                var query = result.Select(values => new
                {
                    values.SchoolId,
                    values.SchoolName,
                    values.StatusElementary,
                    values.StatusHighSchool,
                    values.ElementaryLevel,
                    values.ElementarySchool,
                    LogoSchool = values.Logo != null ? "https://" + url + "/LogoSchool/" + values.Logo.ToString() : "",
                    values.Phone,
                    values.Distance,
                    values.Address,
                }).OrderBy(x => x.SchoolName).ThenBy(x => x.Distance);

                return Ok(new { DATA = query });
            }
            catch (Exception)
            {
                return CreatedAtAction(nameof(LoadSchool), new Messages() { StatusCode = 0, Message = "เกิดข้อผิดพลาด !" });
            }
        }

    }
}
