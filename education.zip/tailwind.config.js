module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    fontFamily: {
      "THSarabun-Psk": ["THSarabun-Psk"],
    },
    extend: {
      transitionDelay: {
        0: "0ms",
        2000: "2000ms",
      },
      spacing: {
        128: "30rem",
      },
      transitionDuration: {
        0: "0ms",
        2000: "2000ms",
      },
      fontFamily: {
        THSarabun: ["THSarabun"],
      },
      dropShadow: {
        black: "1px 1px #000000",
        "black-2": "5px 5px 10px  #000000 ",
      },
      keyframes: {
        shimmer: {
          "100%": {
            transform: "translateX(100%)",
          },
        },
      },
    },
  },
  plugins: [require("@tailwindcss/line-clamp")],
};
