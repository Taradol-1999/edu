// หน้าเเว็บ
import PublicLayout from "../layouts/public/PublicLayout";
import HomePage from "../views/public/HomePage";
// ภายในเว็บ
import PrivateLayout from "../layouts/private/PrivateLayout";
import MainPage from "../views/private/mainPage/MainPage";
import MainUsers from "../views/private/setting/users/MainUsers";
import Mainschools from "../views/private/setting/schools/Mainschools";
import MainActivity from "../views/private/activity/MainActivity";
import MainRegister from "../views/private/register/MainRegister";
import MainAppoint from "../views/private/appoint/MainAppoint";
import FromUser from "../views/private/setting/users/FromUser";
import FromSchool from "../views/private/setting/schools/FromSchool";
import FormRegister from "../views/private/register/FormRegister";
import DetailNews from "../views/public/news/DetailNews";
import FormAppoint from "../views/private/appoint/FormAppoint";
import FormActivity from "../views/private/activity/FormActivity";
import AboutUs from "../views/public/aboutus/AboutUs";
import DetailSchool from "../views/private/setting/schools/DetailSchool";
import MainSetting from "../views/private/setting/setting-register/MainSetting";

import NotFound from "../views/NotFound";
// ! นักศึกษา
import FormPasswordRequest from "../views/home/PassRequest/FormPasswordRequest";
import Detail from "../views/private/activity/Detail";
import MainOpenRegistration from "../views/private/setting/open-registration/MainOpenRegistration";
import FormSetting from "../views/private/setting/setting-register/FormSetting";
import MainReport from "../views/private/report/MainReport";

const Routes = [
  {
    path: "/",
    name: "หน้าหลัก",
    component: HomePage,
    layout: PublicLayout,
    role: 0,
  },
  {
    path: "/DetailNews",
    name: "รายละเอียดข่าว",
    component: DetailNews,
    layout: PublicLayout,
    role: 0,
  },
  {
    path: "/AboutUs",
    name: "เกี่ยวกับเรา",
    component: AboutUs,
    layout: PublicLayout,
    role: 0,
  },
  {
    path: "/FormPasswordRequest",
    name: "ขอรับรหัสผ่าน",
    component: FormPasswordRequest,
    layout: PublicLayout,
    role: 0,
  },
  ////////////////////////// ? role = 3//////////////////////////////
  {
    path: "/MainRegister",
    name: "ข้อมูลการลงทะเบียน",
    component: MainRegister,
    layout: PublicLayout,
    role: 3,
  },
  {
    path: "/MainRegister/FormRegister",
    name: "ข้อมูลการลงทะเบียน/ลงทะเบียน",
    component: FormRegister,
    layout: PublicLayout,
    role: 3,
  },
  {
    path: "/MainUsers/FromUser",
    name: "ข้อมูลผู้ใช้งาน/เพิ่มผู้ใช้งาน",
    component: FromUser,
    layout: PublicLayout,
    role: 3,
  },
  {
    path: "*",
    name: "/ไม่พบหน้าที่คุณต้องการ",
    component: NotFound,
    layout: PublicLayout,
    role: 0,
  },
  {
    path: "*",
    name: "/ไม่พบหน้าที่คุณต้องการ",
    component: NotFound,
    layout: PublicLayout,
    role: 3,
  },
  ////////////////////////// ? role = 2//////////////////////////////
  {
    path: "/MainRegister",
    name: "ข้อมูลการลงทะเบียน",
    component: MainRegister,
    layout: PublicLayout,
    role: 2,
  },
  {
    path: "/MainRegister/FormRegister",
    name: "ข้อมูลการลงทะเบียน/ลงทะเบียน",
    component: FormRegister,
    layout: PublicLayout,
    role: 2,
  },
  {
    path: "/MainUsers/FromUser",
    name: "ข้อมูลผู้ใช้งาน/เพิ่มผู้ใช้งาน",
    component: FromUser,
    layout: PublicLayout,
    role: 2,
  },
  {
    path: "*",
    name: "/ไม่พบหน้าที่คุณต้องการ",
    component: NotFound,
    layout: PublicLayout,
    role: 0,
  },
  {
    path: "*",
    name: "/ไม่พบหน้าที่คุณต้องการ",
    component: NotFound,
    layout: PublicLayout,
    role: 2,
  },
  //////////////////////////////////////////////////////////// !!! PrivateLayout !!!////////////////////////////////////////////////////////////
  ////////////////////////// ? role = 1//////////////////////////////

  {
    path: "/",
    name: "หน้าแรก",
    component: MainPage,
    layout: PrivateLayout,
    role: 1,
  },
  {
    path: "/MainAppoint",
    name: "ข้อมูลการแต่งตั้ง",
    component: MainAppoint,
    layout: PrivateLayout,
    role: 1,
  },
  {
    path: "/MainAppoint/FormAppoint",
    name: "ข้อมูลการแต่งตั้ง/แต่งตั้งอาจารย์",
    component: FormAppoint,
    layout: PrivateLayout,
    role: 1,
  },
  {
    path: "/MainRegister",
    name: "ข้อมูลการลงทะเบียน",
    component: MainRegister,
    layout: PrivateLayout,
    role: 1,
  },
  {
    path: "/MainRegister/FormRegister",
    name: "ข้อมูลการลงทะเบียน/ลงทะเบียน",
    component: FormRegister,
    layout: PrivateLayout,
    role: 1,
  },
  {
    path: "/MainActivity",
    name: "ข้อมูลประชาสัมพันธ์",
    component: MainActivity,
    layout: PrivateLayout,
    role: 1,
  },
  {
    path: "/MainActivity/FormActivity",
    name: "ข้อมูลประชาสัมพันธ์/เพิ่มข้อมูลประชาสัมพันธ์",
    component: FormActivity,
    layout: PrivateLayout,
    role: 1,
  },
  {
    path: "/MainActivity/DetailActivity",
    name: "รายละเอียดข่าว",
    component: Detail,
    layout: PrivateLayout,
    role: 1,
  },
  {
    path: "/MainUsers",
    name: "ข้อมูลผู้ใช้งาน",
    component: MainUsers,
    layout: PrivateLayout,
    role: 1,
  },
  {
    path: "/MainUsers/FromUser",
    name: "ข้อมูลผู้ใช้งาน/เพิ่มผู้ใช้งาน",
    component: FromUser,
    layout: PrivateLayout,
    role: 1,
  },
  {
    path: "/Mainschools",
    name: "ข้อมูลโรงเรียน",
    component: Mainschools,
    layout: PrivateLayout,
    role: 1,
  },
  {
    path: "/Mainschools/FromSchool",
    name: "ข้อมูลโรงเรียน/เพิ่มโรงเรียน",
    component: FromSchool,
    layout: PrivateLayout,
    role: 1,
  },
  {
    path: "/Mainschools/DetailSchool",
    name: "ข้อมูลโรงเรียน/รายละเอียด",
    component: DetailSchool,
    layout: PrivateLayout,
    role: 1,
  },
  {
    path: "/main-open-registration",
    name: "เปิดการลงทะเบียนแจ้งความประสงค์",
    component: MainOpenRegistration,
    layout: PrivateLayout,
    role: 1,
  },
  {
    path: "/setting-register",
    name: "ตั้งค่าการลงทะเบียน",
    component: MainSetting,
    layout: PrivateLayout,
    role: 1,
  },
  {
    path: "/setting-register/form-setting-register",
    name: "ตั้งค่าการลงทะเบียน/เพิ่มตั้งค่าการลงทะเบียน",
    component: FormSetting,
    layout: PrivateLayout,
    role: 1,
  },
  {
    path: "/setting-register/edit-form-setting-register",
    name: "ตั้งค่าการลงทะเบียน/แก้ไขตั้งค่าการลงทะเบียน",
    component: FormSetting,
    layout: PrivateLayout,
    role: 1,
  },

  {
    path: "/report",
    name: "รายงานผลการฝึกประสบการณ์วิชาชีพครู",
    component: MainReport,
    layout: PrivateLayout,
    role: 1,
  },

  {
    path: "*",
    name: "/ไม่พบหน้าที่คุณต้องการ",
    component: NotFound,
    layout: PrivateLayout,
    role: 1,
  },
];
export default Routes;
