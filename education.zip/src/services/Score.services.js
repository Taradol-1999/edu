import Instance from "../helper/axios";

//CreateScore
export async function CreateScore(values, user) {
  let users = JSON.parse(localStorage.getItem("users"));
  try {
    let formData = new FormData();
    formData.append("Scroes", values.scroe);
    formData.append("FullScore", values.fullScore);
    formData.append("GetScoreBy", user.regisId);
    formData.append("ScroeName", values.scroeName);
    formData.append("AddBy", users.userId);
    formData.append("Note", values.note);
    for (let i = 0; i < values.attachEvidence.length; i++) {
      formData.append("AttachEvidence", values.attachEvidence[i]);
    }
    const response = await Instance.post("Scroe/AddScroe", formData);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}
//CreateScore
export async function EditScroe(values, user) {
  let users = JSON.parse(localStorage.getItem("users"));
  try {
    let formData = new FormData();
    formData.append("ScroeId", values.id);
    formData.append("Scroes", values.scroe);
    formData.append("FullScore", values.fullScore);
    formData.append("GetScoreBy", user.regisId);
    formData.append("ScroeName", values.scroeName);
    formData.append("AddBy", users.userId);
    formData.append("Note", values.note);

    for (let i = 0; i < values.attachEvidence.length; i++) {
      formData.append("AttachEvidence", values.attachEvidence[i]);
    }
    for (let i = 0; i < values.removeDoc.length; i++) {
      formData.append("RemoveDoc", values.removeDoc[i]);
    }

    const response = await Instance.post("Scroe/EditScroe", formData);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

export async function DetailScroe(id) {
  try {
    const response = await Instance.get(`Scroe/DetailScroe?id=${id}`);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}
