import Instance from "../helper/axios";

export async function LoadReport(currentPage, pageSize, search, FacId, MaId, Year, Term) {
  try {
    const response = await Instance.get(`Report/LoadReport?currentPage=${currentPage}&pageSize=${pageSize}&search=${search}&FacId=${FacId}&MaId=${MaId}&Year=${Year}&Term=${Term}`);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

export async function LoadReportPrint(MaId, FacId, Year, Term) {
  try {
    const response = await Instance.get(`Report/LoadReportPrint?MaId=${MaId}&FacId=${FacId}&Year=${Year}&Term=${Term}`);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}
