import Instance from "../helper/axios";

export async function Authen(data) {
  try {
    const response = await Instance.post("Authen/Login", data);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

export async function NewRefreshToken(code) {
  try {
    const response = await Instance.post(`Authen/RefreshToken/${code}`);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

