import Instance from "../helper/axios";

//LoadAppiontMentor
export async function LoadAppiontMentor(currentPage, pageSize, search, Year, Semester, FacId, MaId) {
    try {
      const response = await Instance.get(`Mentor/LoadAppoint?currentPage=${currentPage}&pageSize=${pageSize}&search=${search}&Year=${Year}&Semester=${Semester}&FacId=${FacId}&MaId=${MaId}`);
      return await response.data;
    } catch (error) {
      console.log("error", error);
    }
  }