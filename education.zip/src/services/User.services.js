import Instance from "../helper/axios";

//LoadSchool
export async function LoadUser(currentPage, pageSize, search, role, facId, maId) {
  try {
    const response = await Instance.get(`User/LoadData?currentPage=${currentPage}&pageSize=${pageSize}&search=${search}&role=${role}&FacId=${facId}&MaId=${maId}`);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

//Del
export async function DelUser(id) {
  try {
    const response = await Instance.delete("User/Delete?id=" + id);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

//CreateMajor
export async function CreateMajor(data) {
  try {
    const response = await Instance.post("User/CreateMajor", data);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}
//CreatePreFix
export async function CreatePreFix(data) {
  try {
    const response = await Instance.post("User/CreatePreFix", data);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

//save
export async function SaveUser(data) {
  try {
    const response = await Instance.post("User/Register", data);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

//getId
export async function LoadByUserId(id) {
  try {
    const response = await Instance.get("User/GetUserId/" + id);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}
//update
export async function UpdateUser(data) {
  try {
    const response = await Instance.put("User/UpdateUser/" + data.userId, data);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}
