import Instance from "../helper/axios";

//Registers
export async function Registers(data) {
  try {
    const response = await Instance.post("Register/Registers", data);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

//Registers
export async function CreateRequesttransferschool(data) {
  try {
    const response = await Instance.post("Requesttransferschool/CreateRequesttransferschool", data);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

//Registers
export async function ApproveRequesttransferschool(ReId, status) {
  try {
    const response = await Instance.post(`Requesttransferschool/ApproveRequesttransferschool?ReId=${ReId}&status=${status}`);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}
//update
export async function UpdateRegisters(data) {
  try {
    const response = await Instance.put("Register/UpdateRegisters/" + data.regisId, data);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

export async function LoadRegister(currentPage, pageSize, search, FacId, MaId, Year, Term) {
  const user = JSON.parse(localStorage.getItem("users"));
  try {
    const response = await Instance.get(`Register/LoadRegister?currentPage=${currentPage}&pageSize=${pageSize}&search=${search}&FacId=${FacId}&MaId=${MaId}&Year=${Year}&Term=${Term}&UserId=${user.role === "1" ? "" : user.userId}&role=${user.role}`);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}
//Del
export async function DeleteRegis(id) {
  try {
    const response = await Instance.delete("Register/DeleteRegis?id=" + id);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}
//getId
export async function LoadBytRegisterId(id) {
  try {
    const response = await Instance.get("Register/GetRegisterId/" + id);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}
