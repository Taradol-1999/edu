import Instance from "../helper/axios";

export async function GetSettingregisters(currentPage, pageSize, search) {
  try {
    const response = await Instance.get(`SettingRegister/GetSettingregisters?currentPage=${currentPage}&pageSize=${pageSize}&search=${search}`);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

//LoadSchoolReview
export async function DetailSettingregisters(id) {
  try {
    const response = await Instance.get(`SettingRegister/DetailSettingregisters?id=${id}`);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

//Del
export async function DeteleSettingregister(id) {
  try {
    const response = await Instance.delete("SettingRegister/DeteleSettingregister?id=" + id);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

export async function SettingRegister(data) {
    try {
      const response = await Instance.post("SettingRegister/Settingregister", data);
      return await response.data;
    } catch (error) {
      console.log("error", error);
    }
  }
  export async function UpdateSettingregister(data) {
    try {
      const response = await Instance.put("SettingRegister/UpdateSettingregister", data);
      return await response.data;
    } catch (error) {
      console.log("error", error);
    }
  }
  