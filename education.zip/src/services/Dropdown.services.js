import Instance from "../helper/axios";

export async function GetDropdown() {
  try {
    const response = await Instance.get("Dropdown");
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

export async function GetDropdownSchoolByYear(year, semester) {
  try {
    const response = await Instance.get(`Dropdown/GetSchoolByYear?Year=${year}&Semester=${semester}`);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}
