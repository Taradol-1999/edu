import Instance from "../helper/axios";

export async function LoadDateRequest(id, type) {
  try {
    const response = await Instance.get(`DateRequest/GetRequests?id=${id}&RequestType=${type}`);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}
export async function GetRequestsStatus(id) {
  try {
    const response = await Instance.get(`DateRequest/GetRequestsStatus/${id}`);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

export async function GetRequestsPrivate() {
  try {
    const response = await Instance.get(`DateRequest/GetRequestsPrivate`);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

//update
export async function UpdateRequest(data) {
  try {
    const response = await Instance.put(`DateRequest/AddRequest`, data);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}
