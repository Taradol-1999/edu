import Instance from "../helper/axios";

//GetReviewSchool
export async function GetReviewSchool(schoolId) {
  try {
    const response = await Instance.get(`School/GetReviewSchool?SchoolId=${schoolId}`);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

//ReviewSchool
export async function ReviewSchool(data) {
  try {
    const response = await Instance.post(`School/ReviewSchool`, data);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}
