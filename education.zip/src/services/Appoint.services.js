import Instance from "../helper/axios";

export async function SearchRegister(Year, Semester, School) {
  try {
    const response = await Instance.get(`Appoint/SearchRegister?Year=${Year}&Semester=${Semester}&School=${School}`);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}
export async function PrintAppoint(Year, Semester, School) {
  try {
    const response = await Instance.get(`Appoint/PrintAppoint?Year=${Year}&Semester=${Semester}&School=${School}`);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

//Registers
export async function RegisAppiont(data) {
  try {
    const response = await Instance.post("Appoint/RegisAppiont", data);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}
//LoadAppiont
export async function LoadAppiont(currentPage, pageSize, search, Year, Semester, FacId, MaId) {
  try {
    const response = await Instance.get(`Appoint/LoadAppoint?currentPage=${currentPage}&pageSize=${pageSize}&search=${search}&Year=${Year}&Semester=${Semester}&FacId=${FacId}&MaId=${MaId}`);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

//LoadDetailById
export async function LoadDetailById(id) {
  try {
    const response = await Instance.get("Appoint/LoadDetail?id=" + id);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

//Del
export async function DelAppiont(id) {
  try {
    const response = await Instance.delete("Appoint/DelAppoint?id=" + id);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

//update
export async function UpdateAppiont(data) {
  try {
    const response = await Instance.put("Appoint/UpdateAppiont?id=" + data.appointId, data);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}
