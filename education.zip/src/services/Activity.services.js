import Instance from "../helper/axios";

//LoadActivity
export async function LoadActivity(currentPage, pageSize, search, publishStatus, activityType, since, to) {
  try {
    const response = await Instance.get(
      `Activity/LoadActivity?currentPage=${currentPage}&pageSize=${pageSize}&search=${search}&publishStatus=${publishStatus}&activityType=${activityType}&since=${since}&to=${to}`
    );
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

//LoadNews LoadNews?search=1&showOnSlide=1
export async function LoadNews(search, showOnSlide) {
  try {
    const response = await Instance.get(`Activity/LoadNews?search=${search}&showOnSlide=${showOnSlide}`);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}
//CreateActivity
export async function CreateActivity(values) {
  try {
    let formData = new FormData();
    formData.append("activityTitle", values.activityTitle);
    formData.append("activityDetail", values.activityDetail);
    formData.append("startDate", values.startDate);
    formData.append("endDate", values.endDate);
    formData.append("publishStatus", values.publishStatus);
    formData.append("publishDate", values.publishDate);
    formData.append("activityType", values.activityType);
    formData.append("showOnSlide", values.showOnSlide);
    for (let i = 0; i < values.documents.length; i++) {
      formData.append("documents", values.documents[i]);
    }
    for (let i = 0; i < values.image.length; i++) {
      formData.append("image", values.image[i]);
    }
    const response = await Instance.post("Activity/CreateActivity", formData);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}
//UpDateActivity
export async function UpDateActivity(values) {
  try {
    let formData = new FormData();
    formData.append("activityTitle", values.activityTitle);
    formData.append("activityDetail", values.activityDetail);
    formData.append("startDate", values.startDate);
    formData.append("endDate", values.endDate);
    formData.append("publishStatus", values.publishStatus);
    formData.append("publishDate", values.publishDate);
    formData.append("activityType", values.activityType);
    formData.append("showOnSlide", values.showOnSlide);

    if (values.removeDocName.length !== 0) {
      formData.append("removeDocName", values.removeDocName);
    }
    if (values.removeDoc.length !== 0) {
      formData.append("removeDoc", values.removeDoc);
    }
    for (let i = 0; i < values.documents.length; i++) {
      formData.append("documents", values.documents[i]);
    }
    if (values.removeImg.length !== 0) {
      formData.append("removeImg", values.removeImg);
    }
    for (let i = 0; i < values.image.length; i++) {
      formData.append("image", values.image[i]);
    }
    const response = await Instance.put("Activity/UpDateActivity/" + values.activityId, formData);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}
//LoadDetailNewsById
export async function LoadDetailNewsById(id) {
  try {
    const response = await Instance.get("Activity/LoadDetailNews?id=" + id);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}
//DetailActivity
export async function DetailActivity(id) {
  try {
    const response = await Instance.get("Activity/DetailActivity?id=" + id);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

//Del
export async function DelActivity(id) {
  try {
    const response = await Instance.delete("Activity/DelActivity?id=" + id);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}
