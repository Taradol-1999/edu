import Instance from "../helper/axios";

//Registers
export async function RegisAppiontMentor(data) {
  try {
    const response = await Instance.post("Mentor/RegisMentor", data);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

//UpdateMentor
export async function UpdateMentor(data) {
  try {
    const response = await Instance.put("Mentor/UpdateMentor", data);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

//LoadMentor
export async function LoadMentor(currentPage, pageSize, schoolId, regisId, search, groupId) {
  try {
    const response = await Instance.get(`Mentor/LoadMentor?currentPage=${currentPage}&pageSize=${pageSize}&schoolId=${schoolId}&regisId=${regisId}&search=${search}&groupId=${groupId}`);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

//Registers
export async function AppointMento(data) {
  try {
    const response = await Instance.post("Mentor/AppointMento", data);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

//DeleteMentor
export async function DeleteMentor(mentorId) {
  try {
    const response = await Instance.delete(`Mentor/DeleteMentor?mentorId=${mentorId}`);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

//DeleteAppMentor
export async function DeleteAppMentor(Id) {
  try {
    const response = await Instance.delete(`Mentor/DeleteAppMentor?Id=${Id}`);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}


//LoadMentorById
export async function LoadMentorById(mentorId) {
  try {
    const response = await Instance.get(`Mentor/LoadMentorById?mentorId=${mentorId}`);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

//LoadAppointMentorById
export async function LoadAppointMentorById(id) {
  try {
    const response = await Instance.get(`Mentor/LoadAppointMentorById?regisId=${id}`);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}
