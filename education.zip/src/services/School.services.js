import Instance from "../helper/axios";

//LoadSchool
export async function LoadSchool(currentPage, pageSize, search) {
  try {
    const response = await Instance.get(`School/LoadSchool?currentPage=${currentPage}&pageSize=${pageSize}&search=${search}`);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}
//LoadSchoolReview
export async function LoadSchoolReview(schoolId) {
  try {
    const response = await Instance.get(`School/GetSchoolReview?schoolId=${schoolId}`);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}
//PrintDataSchool
export async function PrintDataSchool() {
  try {
    const response = await Instance.get(`School/PrintDataSchool`);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}
//Del
export async function DelSchool(id) {
  try {
    const response = await Instance.delete("School/DelSchool?id=" + id);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

//Save
export async function SaveSchool(values) {
  try {
    let formdata = new FormData();
    formdata.append("schoolName", values.schoolName);
    formdata.append("address", values.address);
    formdata.append("statusElementary", values.statusElementary);
    formdata.append("elementaryLevel", values.elementaryLevel);
    formdata.append("statusHighSchool", values.statusHighSchool);
    formdata.append("distance", values.distance);
    formdata.append("phone", values.phone);
    formdata.append("logo", values.logo);

    const response = await Instance.post("School/RegisSchool", formdata);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

//UpdateSchool
export async function UpdateSchools(values) {
  try {
    let formdata = new FormData();
    formdata.append("schoolName", values.schoolName);
    formdata.append("address", values.address);
    formdata.append("statusElementary", values.statusElementary);
    formdata.append("elementaryLevel", values.elementaryLevel);
    formdata.append("statusHighSchool", values.statusHighSchool);
    formdata.append("distance", values.distance);
    formdata.append("phone", values.phone);
    formdata.append("logo", values.logo);
    const response = await Instance.put("School/UpdateSchool/" + values.schoolId, formdata);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}
//LoadId
export async function SchoolsDetail(id) {
  try {
    const response = await Instance.get("School/GetID?id=" + id);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}

//TopSchool
export async function TopSchool(amount) {
  try {
    const response = await Instance.get("School/TopSchool?amount=" + amount);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}
