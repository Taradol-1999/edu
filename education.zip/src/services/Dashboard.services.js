import Instance from "../helper/axios";

export async function DataDashboard(Year, Semester, BackYears) {
  try {
    const response = await Instance.get(`/Dashboard/DataDashboard?Year=${Year}&Semester=${Semester}&BackYears=${BackYears}`);
    return await response.data;
  } catch (error) {
    console.log("error", error);
  }
}
