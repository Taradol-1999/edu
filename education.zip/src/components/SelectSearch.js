import React from "react";
import Select from "react-select";
export const SelectSearch = ({ title, placeholder, ...props }) => {
  const customStyles = {
    control: (base) => ({
      ...base,
      height: "45px",
      background: "#f5f5f5",
      borderColor: "transparent",
      boxShadow: "transparent",
      borderRadius: "0.5rem",
      "&:hover": {
        borderColor: "transparent",
      },
    }),
  };
  return (
    <Select
      className="w-full bg-transparent border-blue-400 rounded-lg border-2 hover:border-blue-300 duration-500 hover:shadow-md"
      styles={customStyles}
      {...props}
      noOptionsMessage={() => <p className="text-red-700">ไม่พบข้อมูล !</p>}
      placeholder={
        <p className="truncate" style={{ color: "#6b7280" }}>
          {placeholder}
        </p>
      }
    />
  );
};
