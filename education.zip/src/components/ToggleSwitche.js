import React from "react";

export default function ToggleSwitche({ name, checked, onChange, title = "", titleOn = "เปิด", titleOff = "ปิด", props }) {
  return (
    <div className="flex-none justify-center items-center">
      <span className="mr-3 ">{title}</span>
      <label className="flex items-center relative w-max cursor-pointer select-none mt-1">
        <input
          type="checkbox"
          name={name}
          checked={checked}
          {...props}
          onChange={onChange}
          className="appearance-none transition-colors cursor-pointer w-[80px] h-9 rounded-full focus:outline-none ring-1 ring-offset-2 ring-offset-gray-400 ring-gray-100 bg-red-500"
        />
        <span className="absolute font-medium text-xs uppercase right-[8px] text-white"> {titleOff} </span>
        <span className="absolute font-medium text-xs uppercase right-[55px] text-white"> {titleOn} </span>
        <span className="w-9 h-9 right-[44px] absolute rounded-full transform transition-transform bg-gray-200"></span>
      </label>
    </div>
  );
}
