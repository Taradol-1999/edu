import { nanoid } from "nanoid";
import ERROR from "../assets/img/ERROR.png";
export default function NotData() {
  return (
    <tr key={nanoid()}>
      <td className=" tb-td" colSpan={9}>
        <div className="flex justify-center leading-10 text-center text-red-500 align-middle mt-10">
          <img src={ERROR} alt="ERROR" />
        </div>
      </td>
    </tr>
  );
}

export function NotDataImg() {
  return <img src={ERROR} alt="ERROR" />;
}
