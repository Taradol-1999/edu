import React from "react";
import { ErrorMessage, useField } from "formik";

export const TextFieldArea = ({ title, showLable = true, label, ...props }) => {
  const [field, meta] = useField(props);
  return (
    <div className="px-1 py-1">
      {showLable ? (
        <label className="truncate" htmlFor={field.name}>
          {title}
        </label>
      ) : (
        <></>
      )}
      <textarea className={`field-textarea ${meta.touched && meta.error && "is-invalid"}`} {...field} {...props} />
      <ErrorMessage component="div" name={field.name} className="text-red-400 text-sm" />
    </div>
  );
};
