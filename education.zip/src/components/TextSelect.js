import React from "react";
import { ErrorMessage, useField } from "formik";
import Select from "react-select";
export const TextSelect = ({ title, placeholder, reset, onClickReset, ...props }) => {
  const [field, meta] = useField(props);
  const { isValid } = props;
  const customStylesError = {
    control: (base, state) => ({
      ...base,
      height: "40px",
      minHeight: "40px",
      background: state.isFocused ? "#eff6ff" : "#fef2f2",
      borderColor: state.isFocused ? "" : isValid ? "" : "#f87171",
      "&:hover": {
        borderColor: state.isFocused ? "" : isValid ? "" : "#f87171",
      },
    }),
  };
  const customStyles = {
    control: (base, state) => ({
      ...base,
      height: "40px",
      minHeight: "40px",
      borderColor: "#b2b7c1",
      background: state.isFocused ? "#eff6ff" : "",
    }),
  };
  return (
    <div className="px-1 py-1 ">
      <div className="flex justify-between">
        <p className="text-left">{title}</p>
        <p className={`text-xs text-red-500 mt-3 cursor-pointer hover:underline ${reset === "show" ? "" : "hidden"}`} onClick={onClickReset}>
          ล้างค่า
        </p>
      </div>
      <Select styles={meta.touched && meta.error ? customStylesError : customStyles} {...props} placeholder={<p className="truncate text-gray-400 text-left">{placeholder}</p>} noOptionsMessage={() => <p className="text-tred-700">ไม่พบข้อมูล !</p>} />
      <ErrorMessage component="div" name={field.name} className="text-red-400 text-sm" />
    </div>
  );
};
