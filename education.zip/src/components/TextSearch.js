import React from "react";
import SVGSearch from "../SVGS/SVGSearch";

export const TextSearch = ({ placeholder, ...props }) => {
  return (
    <div className="border-blue-400 rounded-lg border-2 hover:border-blue-300 duration-300 hover:shadow-md">
      <div className="flex bg-gray-100 w-full rounded-lg ">
        <input className="bg-gray-100  outline-none w-full rounded-l-lg px-2 placeholder-gray-500 duration-500" {...props} placeholder={placeholder} />
        <p className="border-l border-gray-300 my-2" />
        <SVGSearch width="28" height="28" color="#9e9eab" strokeWidth="2" className="m-2 mx-2" />
      </div>
    </div>
  );
};
