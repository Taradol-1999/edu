import React from "react";
import { ErrorMessage, useField } from "formik";

export const TextField = ({ title, showLable = true, label, ...props }) => {
  const [field, meta] = useField(props);

  return (
    <div className="px-1 py-1">
      {showLable ? (
        <p className="truncate text-left" htmlFor={field.name}>
          {title}
        </p>
      ) : (
        <></>
      )}
      <input className={`field-input ${meta.touched && meta.error && "is-invalid"}`} {...field} {...props} autoComplete="off" />
      <ErrorMessage component="div" name={field.name} className="text-red-400 text-sm" />
    </div>
  );
};
