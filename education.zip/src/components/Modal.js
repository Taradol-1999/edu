import { Dialog, Transition } from "@headlessui/react";
import React, { Fragment } from "react";

export default function Modal({ isOpen, children, title = "", width = "max-w-4xl", height = "", onClose, subTitle }) {
  return (
    <Fragment>
      <Transition appear show={isOpen} as={Fragment}>
        <Dialog as="div" className="relative z-50" onClose={onClose}>
          <Transition.Child as={Fragment} enter="ease-out duration-300" enterFrom="opacity-0" enterTo="opacity-100" leave="ease-in duration-200" leaveFrom="opacity-100" leaveTo="opacity-0">
            <div className="fixed inset-0 bg-black/60" />
          </Transition.Child>
          <div className="fixed inset-0 overflow-y-auto">
            <div className="flex min-h-full items-center justify-center p-4 text-center">
              <Transition.Child
                as={Fragment}
                enter="transition ease-out duration-300"
                enterFrom="opacity-0 -translate-y-10"
                enterTo="opacity-100 -translate-y-0"
                leave="transition ease-in duration-200"
                leaveFrom="opacity-100 -translate-y-0"
                leaveTo="opacity-0 -translate-y-10"
              >
                <Dialog.Panel className={`${width} ${height}  w-full transform rounded-lg bg-white p-3 text-left align-middle transition-all shadow-md border-y-8 border-blue-600 mt-2`}>
                  {title && (
                    <>
                      <Dialog.Title as="h3" className="leading-6 text-black flex justify-between ">
                        <p className="text-2xl font-semibold">
                          {title} {subTitle && <span className="text-gray-600 text-base ">{subTitle}</span>}
                        </p>

                        <div className="-mt-1 -mr-1">
                          <button type="button" className="min-w-auto w-6 h-6  rounded-full hover:bg-gray-400/10 group duration-300 text-white font-semibold focus:outline-none" onClick={onClose}>
                            <i className="fa-solid fa-xmark text-gray-400 group-hover:text-gray-800" />
                          </button>
                        </div>
                      </Dialog.Title>
                      <div className="border-gray-300 border-b py-1" />
                    </>
                  )}

                  {children}
                </Dialog.Panel>
              </Transition.Child>
            </div>
          </div>
        </Dialog>
      </Transition>
    </Fragment>
  );
}
