import React from "react";

export default function CardLoadingV2({ length = 1 }) {
  return Array.from(Array(length), (v, i) => (
    <div key={i} className="isolate overflow-hidden w-full before:border-t before:border-rose-100/10 rounded-2xl">
      <div className="relative before:absolute before:inset-0 before:-translate-x-full before:animate-[shimmer_2s_infinite] before:bg-gradient-to-r before:from-transparent before:via-blue-100 before:to-transparent">
        <div className="rounded-2xl bg-blue-100/90 p-4 flex w-full">
          <div className="h-[9rem] w-2/6 rounded-lg bg-blue-50" />
          <div className="space-y-3 w-4/6 px-2 grid content-between py-4">
            <div className="h-5 w-full rounded-lg bg-blue-50" />
            <div className="h-5 w-4/5 rounded-lg bg-blue-50" />
            <div className="h-5 w-1/5  mt-2 rounded-lg bg-blue-50 content-end" />
          </div>
        </div>
      </div>
    </div>
  ));
}
