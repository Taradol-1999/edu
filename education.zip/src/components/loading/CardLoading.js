import React from "react";

export default function CardLoading({ length = 1 }) {
  return Array.from(Array(length), (v, i) => (
    <div key={i} className="isolate overflow-hidden w-full before:border-t before:border-rose-100/10 rounded-2xl">
      <div className="relative before:absolute before:inset-0 before:-translate-x-full before:animate-[shimmer_2s_infinite] before:bg-gradient-to-r before:from-transparent before:via-blue-100 before:to-transparent">
        <div className="space-y-5 rounded-2xl bg-blue-100/90 p-4">
          <div className="h-[15rem] rounded-lg bg-blue-50" />
          <div className="space-y-3">
            <div className="h-4 w-3/5 rounded-lg bg-blue-50" />
            <div className="h-4 w-4/5 rounded-lg bg-blue-50" />
            <div className=" flex justify-end">
              <div className="h-4 w-1/5  mt-2 rounded-lg bg-blue-50 content-end" />
            </div>
          </div>
        </div>
      </div>
    </div>
  ));
}
