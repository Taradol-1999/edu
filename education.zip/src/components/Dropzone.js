import React from "react";
import { Fragment } from "react";
import SVGClip from "../SVGS/SVGClip";

const Dropzone = ({ name, id = "file", errors = false, touched = false, value = "", onChange, onDelete, accept, title, titletype }) => {
  return (
    <div
      className={` h-full w-full flex justify-center px-6 py-5 border-2 border-dashed rounded-md ${value.length < 1 ? " cursor-pointer" : ""} 
      ${touched ? (errors ? "border-red-500 bg-red-50" : "border-green-500") : "border-black"}`}
      onClick={() => {
        if (value.length < 1) {
          document.getElementById(id).click();
        }
      }}
    >
      <div className="w-full p-5">
        {value.length > 0 ? (
          <div className="flex flex-wrap justify-center w-full">
            {value.map((img, keyind) => (
              <div key={keyind} className="border border-blue-700 bg-blue-50 rounded-md w-full p-2 mt-1">
                <div className="w-full flex items-center cursor-pointer justify-between">
                  <p className="">
                    {keyind + 1}. {img.fileNameOriginal ? img.fileNameOriginal : img.name}
                  </p>
                  <i
                    onClick={(e) => {
                      e.stopPropagation();
                      onDelete(keyind);
                    }}
                    className="fa fa-close text-[20px] px-2 py-1 bg-red-100 rounded-md text-red-500 "
                  />
                </div>
              </div>
            ))}
            <div
              className="  flex w-full justify-center items-center cursor-pointer group duration-200 bg-white mt-5"
              onClick={() => {
                document.getElementById(id).click();
              }}
            >
              <div>
                <div className="flex justify-center">
                  <SVGClip width="36" height="36" color="#9ca3af" strokeWidth="2" className="mr-2" />
                </div>
                <div className="flex justify-center text-base text-gray-700 font-bold mt-2">
                  <label className="cursor-pointer">{"อัพโหลดไฟล์เพิ่มเติม"}</label>
                </div>
                <p className="text-sm text-center text-gray-500">{titletype ? titletype : "เฉพาะไฟล์ PDF"}</p>
              </div>
            </div>
          </div>
        ) : (
          <Fragment>
            <div className="flex justify-center">
              <SVGClip width="36" height="36" color="#9ca3af" strokeWidth="2" className="mr-2" />
            </div>
            <div className="flex justify-center text-base text-gray-700 mt-2 font-bold  ">
              <label className="cursor-pointer">
                <span>{title ? title : "อัพโหลดไฟล์"}</span>
              </label>
            </div>
            <p className="text-sm text-center text-gray-500">{titletype ? titletype : "เฉพาะไฟล์ PDF"}</p>
          </Fragment>
        )}
      </div>
      <input id={id} type="file" className="hidden" name={name} multiple accept={accept ? accept : "image/png, image/jpeg, image/jpg"} onChange={onChange} />
    </div>
  );
};

export default Dropzone;
