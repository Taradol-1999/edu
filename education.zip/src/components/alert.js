import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Swal from "sweetalert2";
import del_Icon from "../assets/img/del.gif";
import offon from "../assets/img/off&on.gif";

export const LOGINSUCCESS = () => {
  const resolveAfter3Sec = new Promise((resolve) => setTimeout(resolve, 500));
  toast.promise(resolveAfter3Sec, {
    pending: "กำลังเข้าสู่ระบบ...",
    success: "เข้าสู่ระบบสำเร็จ",
  });
};

export function MESSAGESUCCESS(message) {
  Swal.fire({
    position: "center",
    icon: "success",
    title: message,
    showConfirmButton: false,
    timer: 1500,
  });
}
export function MESSAGEERROR(message) {
  toast(message, ERROR);
}

export function STATUSERROR() {
  toast("ลบข้อมูลไม่สำเร็จ !", ERROR);
}

export function STATUSWARNING() {
  toast("ไม่พบข้อมูล !", WARNING);
}

export const SUCCESS = {
  autoClose: 2000,
  type: toast.TYPE.SUCCESS,
  position: toast.POSITION.BOTTOM_RIGHT,
};
export const INFO = {
  autoClose: 2000,
  type: toast.TYPE.INFO,
  position: toast.POSITION.BOTTOM_RIGHT,
};
export const WARNING = {
  autoClose: 2000,
  type: toast.TYPE.WARNING,
  position: toast.POSITION.BOTTOM_RIGHT,
};
export const ERROR = {
  autoClose: 2500,
  type: toast.TYPE.ERROR,
  position: toast.POSITION.BOTTOM_RIGHT,
};
export const DEFAULT = {
  autoClose: 2000,
  type: toast.TYPE.DEFAULT,
  position: toast.POSITION.BOTTOM_RIGHT,
};
export const DElALERT = {
  text: "คุณต้องการลบข้อมูลใช่หรือไม่ ?",
  imageUrl: del_Icon,
  imageWidth: 80,
  imageHeight: 80,
  showCancelButton: true,
  confirmButtonColor: "#3085d6",
  cancelButtonColor: "#d33",
  confirmButtonText: "ตกลง",
  cancelButtonText: "ยกเลิก",
};

export const OFFANDON = {
  text: "คุณต้องการปิดการใช้งานนี้ใช่หรือไม่ ?",
  imageUrl: offon,
  imageWidth: 140,
  imageHeight: 120,
  showCancelButton: true,
  confirmButtonColor: "#3085d6",
  cancelButtonColor: "#d33",
  confirmButtonText: "ตกลง",
  cancelButtonText: "ยกเลิก",
};

export const OFFON = (text) => {
  return {
    text: text,
    imageUrl: offon,
    imageWidth: 140,
    imageHeight: 120,
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "ตกลง",
    cancelButtonText: "ยกเลิก",
  };
};
