import React from "react";
import SVGBack from "../SVGS/SVGBack";

export default function BtnGoBack({ onClick }) {
  return (
    <button type="button" className="buttonBack" onClick={onClick}>
      <SVGBack width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> ย้อนกลับ
    </button>
  );
}
