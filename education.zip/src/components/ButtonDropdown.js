import { Fragment } from "react";
import { Menu, Transition } from "@headlessui/react";
import SVGDots from "../SVGS/SVGDots";
import SVGDelete from "../SVGS/SVGDelete";
import SVGEdit from "../SVGS/SVGEdit";
import SVGInfo from "../SVGS/SVGInfo";
import SVGTeacherV2 from "../SVGS/SVGTeacherV2";
import SVGWriting from "../SVGS/SVGWriting";
function classNames(...classes) {
  return classes.filter(Boolean).join(" ");
}

export default function ButtonDropdown({ edit = true, info = true, del = true, app = false, scroe = false, onClickScroe, onClickEdit, onClickInfo, onClickDelete, onClickApp }) {
  return (
    <Menu as="div" className="inline-block text-left ">
      <div>
        <Menu.Button className="inline-flex items-center justify-center  border border-transparent rounded-full w-10 h-10 text-white bg-gray-100 hover:bg-gray-200 focus:outline-none">
          <SVGDots width="28" height="28" color="#000000" strokeWidth="1.5" />
        </Menu.Button>
      </div>
      <Transition
        as={Fragment}
        enter="transition ease-out duration-100"
        enterFrom="transform opacity-0 scale-95"
        enterTo="transform opacity-100 scale-100"
        leave="transition ease-in duration-75"
        leaveFrom="transform opacity-100 scale-100"
        leaveTo="transform opacity-0 scale-95"
      >
        <Menu.Items className="origin-top-right absolute -ml-28  min-w-[10rem] rounded-md shadow-lg bg-blue-700 ring-1 ring-black ring-opacity-5 focus:outline-none">
          <div className="py-1">
            <div className={app ? "" : "hidden"}>
              <Menu.Item>
                {({ active }) => (
                  <button
                    onClick={onClickApp}
                    className={classNames(active ? "bg-green-100 text-gray-900" : "text-gray-700 bg-gray-100", "inline-flex px-4 py-2 text-base w-full items-center focus:outline-none")}
                  >
                    <SVGTeacherV2 width="28" height="28" color="#22c55e" strokeWidth="1.5" className="mr-2" /> แต่งตั้งครูพี่เลี้ยง
                  </button>
                )}
              </Menu.Item>
            </div>
            <div className={scroe ? "" : "hidden"}>
              <Menu.Item>
                {({ active }) => (
                  <button
                    onClick={onClickScroe}
                    className={classNames(active ? "bg-blue-100 text-gray-900" : "text-gray-700 bg-gray-100", "inline-flex px-4 py-2 text-base w-full items-center focus:outline-none")}
                  >
                    <SVGWriting width="28" height="28" color="#1d4ed8" strokeWidth="1.5" className="mr-2" /> ให้คะแนน
                  </button>
                )}
              </Menu.Item>
            </div>
            <div className={edit ? "" : "hidden"}>
              <Menu.Item>
                {({ active }) => (
                  <button
                    onClick={onClickEdit}
                    className={classNames(active ? "bg-orange-100 text-gray-900" : "text-gray-700 bg-gray-100", "inline-flex px-4 py-2 text-base w-full items-center focus:outline-none")}
                  >
                    <SVGEdit width="28" height="28" color="orange" strokeWidth="1.5" className="mr-2" /> แก้ไข
                  </button>
                )}
              </Menu.Item>
            </div>
            <div className={info ? "" : "hidden"}>
              <Menu.Item>
                {({ active }) => (
                  <button
                    onClick={onClickInfo}
                    className={classNames(active ? "bg-blue-100 text-gray-900" : "text-gray-700 bg-gray-100", "inline-flex px-4 py-2 text-base w-full items-center focus:outline-none")}
                  >
                    <SVGInfo width="28" height="28" color="blue" strokeWidth="1.5" className="mr-2" /> รายละเอียด
                  </button>
                )}
              </Menu.Item>
            </div>
            <div className={del ? "" : "hidden"}>
              <Menu.Item>
                {({ active }) => (
                  <button
                    onClick={onClickDelete}
                    className={classNames(active ? "bg-red-100 text-gray-900" : "text-gray-700 bg-gray-100", "inline-flex px-4 py-2 text-base w-full items-center focus:outline-none")}
                  >
                    <SVGDelete width="28" height="28" color="red" strokeWidth="1.5" className="mr-2" /> ลบ
                  </button>
                )}
              </Menu.Item>
            </div>
          </div>
        </Menu.Items>
      </Transition>
    </Menu>
  );
}
