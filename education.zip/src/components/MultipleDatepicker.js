import React from "react";

export const MultipleDatepicker = ({ placeholderStart, placeholderEnd, valueStart, valueEnd, onChangeStart, onChangeEnd, nameEnd, nameStart }) => {
  return (
    <div className="flex bg-gray-100 w-full rounded-lg h-full border-blue-400 border-2 hover:border-blue-300 duration-300 hover:shadow-md">
      <input type="date" placeholder={placeholderStart} value={valueStart} onChange={onChangeStart} name={nameStart} className="placeholder-gray-500 bg-gray-100 outline-none w-full rounded-l-lg px-2" />
      <div className="inline bg-blue-200 py-2 px-4 text-gray-800 border-r bro">ถึง</div>
      <input type="date" placeholder={placeholderEnd} value={valueEnd} onChange={onChangeEnd} name={nameEnd} className="bg-gray-100 outline-none w-full rounded-r-lg px-2 placeholder-gray-400" />
    </div>
  );
};
