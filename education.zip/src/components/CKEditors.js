import React, { Fragment } from "react";
import { useField, ErrorMessage } from "formik";
import { CKEditor } from "@ckeditor/ckeditor5-react";
import Editor from "ckeditor5-custom-build/build/ckeditor";
const CKEditors = ({ editor, toolbar = ["heading", "|", "bold", "italic", "underline"], upimage, ...props }) => {
  const [field, meta] = useField(props);

  const uploadAdapter = (loader) => {
    return {
      upload: () => {
        return new Promise((resolve, reject) => {
          const body = new FormData();
          loader.file.then((file) => {
            body.append("Image", file);
            fetch(`${URL}UpFileCKEditor/UpFileCKEditor`, {
              method: "post",
              body: body,
              headers: {
                Authorization: "Bearer " + localStorage.getItem("accessToken"),
              },
            })
              .then((res) => res.json())
              .then((res) => {
                if (res) {
                  if (res.uploaded) {
                    resolve({
                      default: res.url,
                    });
                  }
                }
              })
              .catch((err) => {
                reject(err);
              });
          });
        });
      },
    };
  };
  function uploadPlugin(editor) {
    editor.plugins.get("FileRepository").createUploadAdapter = (loader) => {
      return uploadAdapter(loader);
    };
  }
  return (
    <Fragment>
      <div className={meta.touched ? (meta.error ? "border-ckeditor-is-invalid" : "border-ckeditor-is-valid") : "border-ckeditor-normal"}>
        <CKEditor
          editor={editor ? editor : Editor}
          config={{
            toolbar: toolbar,
            mediaEmbed: {
              previewsInData: true,
            },
            extraPlugins: uploadPlugin ? [uploadPlugin] : "",
            heading: {
              options: [
                {
                  model: "paragraph",
                  title: "Paragraph",
                  class: "",
                },
                {
                  model: "heading1",
                  view: "h1",
                  title: "หัวข้อ1",
                  class: "text-[28px] sm:text-[44px] md:text-[64px]",
                },
                {
                  model: "heading2",
                  view: "h2",
                  title: "หัวข้อ2",
                  class: "text-[18px] sm:text-[24px] md:text-[32px]",
                },
              ],
            },
            numberedList: {
              model: "paragraph",
              title: "Paragraph",
              class: "",
            },
          }}
          {...props}
        />
      </div>

      <ErrorMessage component="div" name={field.name} className="mt-1 invalid-feedback text-sm text-red-500" />
    </Fragment>
  );
};

export default CKEditors;
