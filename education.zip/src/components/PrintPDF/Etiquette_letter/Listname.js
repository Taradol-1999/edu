import React from "react";
import Image from "@material-tailwind/react/Image";
import LOGOKRU from "../../PrintPDF/img/LOGO-KRU-BLACK.png";
import { Box, Button } from "@material-ui/core";
import "./Listname.css";
function Etiquette_letter() {
  return (
    <>
      <div className="book">
        <div className="page" id="contentPrint">
          <div className="page-frem-list">
            <div className="LOGOKRU">
              <Image src={LOGOKRU} className="LOGOKRU-IMG" />
            </div>
            <div className="list-name">
              <p className="text-16ptBold"> รายชื่อนักศึกษาฝึกปฏิบัติการสอนในสถานศึกษา ๒</p>
              <p className="text-16ptBold"> ภาคเรียนที่ ๒ ปีการศึกษา ๒๕๖๔</p>
              <p className="text-16ptBold">หลักสูตรครุศาสตรบัณฑิต (ค.บ. ) ๕ ปีมหาวิทยาลัยราชภัฏกาญจนบุรี</p>
            </div>

            <div>
              <table className="table-auto">
                <thead>
                  <tr className="border table-color">
                    <th className=" px-5 py-2 border-1 border-black table-w">
                      <p className="text-16pt">โรงเรียน/หน่วยฝึก</p>
                    </th>
                    <th className="px-5 py-2 border-1 border-black">
                      <p className="text-16pt">ชื่อนักศึกษา</p>
                    </th>
                    <th className="px-5 py-2 border-1 border-black">
                      <p className="text-16pt">สาขาวิชา</p>
                    </th>
                    <th className="px-5 py-2 border-1 border-black">
                      <p className="text-16pt">เบอร์โทรศัพท์</p>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="px-3 py-1 border-1 border-black">
                      <p className="text-16pt">ด่านช้างวิทยา</p>
                    </td>
                    <td className="px-3 py-1 border-1 border-black">
                      <p className="text-16pt">นาย ธาราดล สอนหุ่น</p>
                    </td>
                    <td className="px-3 py-1 border-1 border-black">
                      <p className="text-16pt">คณิตศาสตร์</p>
                    </td>
                    <td className="px-3 py-1 border-1 border-black">
                      <p className="text-16pt">๐๖๓-๗๖๐๓๗๓๑</p>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <Box display="flex" justifyContent="center" p={2}>
        <Box mr={3}>
          <Button
            color="primary"
            variant="contained"
            size="large"
            onClick={() => {
              let css = "";
              let lin = "";
              let CssElem = document.getElementsByTagName("style");
              let link = document.getElementsByTagName("link");
              for (let index = 0; index < link.length; index++) {
                lin = lin + link[index].outerHTML;
              }
              for (let index = 0; index < CssElem.length; index++) {
                css = css + CssElem[index].outerHTML;
              }
              var divToPrint = document.getElementById("contentPrint"); // เลือก div id ที่เราต้องการพิมพ์
              var html =
                "<html>" +
                "<head>" +
                lin +
                css +
                "</head>" +
                '<body onload="window.print(); window.close();">' +
                divToPrint.innerHTML +
                "</body>" +
                "</html>";

              var popupWin = window.open();
              popupWin.document.open();
              popupWin.document.write(html);
              popupWin.document.close();
            }}
          >
            ปริ้น
          </Button>
        </Box>
      </Box>
    </>
  );
}

export default Etiquette_letter;
