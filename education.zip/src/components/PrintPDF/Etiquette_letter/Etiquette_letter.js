import React, { useState, useEffect } from "react";
import Image from "@material-tailwind/react/Image";
import KRUT from "../../PrintPDF/img/3CM.PNG";
import { Box, Button } from "@material-ui/core";
import LOGOKRU from "../../PrintPDF/img/LOGO-KRU-BLACK.png";
import "./Etiquette_letter.css";
import { GetRegisterData } from "services/Register.services";
import { LoadSchoolsData } from "services/Home.services";
import { term, academy } from "../../../Helper/json/term.json";
import moment from "moment";
function Etiquette_letter() {
  const [regis, setRegister] = useState([]);
  const [school, setSchool] = useState([]);
  const [SchoolId, setSchoolId] = useState([]);
  const [year, setYear] = useState(0);
  const [semester, setSemester] = useState(0);
  const [academys, setAcademy] = useState(0);
  const [numbers, setNumber] = useState(1);
  const [dateinput, setDateinput] = useState("");

  let today = new Date();
  useEffect(() => {
    fetchData();
  }, []);

  async function fetchData() {
    const resultSchool = await LoadSchoolsData();
    setSchool(resultSchool.data);
    const result = await GetRegisterData();
    setRegister(result.data);
  }
  const findregis = regis.filter(
    (x) => x.schoolId === SchoolId && x.year === year && x.semester === semester
  );

  console.log("regis", findregis);

  function thaiNumber(num) {
    var array = { 1: "๑", 2: "๒", 3: "๓", 4: "๔", 5: "๕", 6: "๖", 7: "๗", 8: "๘", 9: "๙", 0: "๐" };
    var str = num.toString();
    for (var val in array) {
      str = str.split(val).join(array[val]);
    }
    return str;
  }
  console.log(moment(dateinput).add(543, "year").format("DD-MMMM-YYYY"));
  return (
    <>
      <div className="grid grid-cols-12 gap-4 mt-4 mx-8">
        <div className="col-span-3">
          <label htmlFor="country" className="block text-sm font-medium text-gray-700">
            เลือกโรงเรียน
          </label>
          <select
            className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            value={SchoolId}
            onChange={(e) => setSchoolId(e.target.value)}
          >
            <option value="">เลือก</option>
            {school.map((x) => (
              <option value={x.schoolId} key={x.schoolId}>
                {x.schoolName}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="country" className="block text-sm font-medium text-gray-700">
            ปีการศึกษา
          </label>
          <select
            onChange={(e) => setYear(e.target.value)}
            value={year}
            className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          >
            <option value="">เลือก</option>
            <option value={today.getFullYear() + 543}>{today.getFullYear() + 543}</option>
            {Array.from(Array(today.getFullYear() + 543 - 2563), (e, i) => (
              <option key={today.getFullYear() - (i + 1)} value={today.getFullYear() - (i + 1) + 543}>
                {today.getFullYear() + 543 - (i + 1)}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="country" className="block text-sm font-medium text-gray-700">
            เทอม
          </label>
          <select
            value={semester}
            onChange={(e) => setSemester(e.target.value)}
            className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          >
            <option value="">เลือก</option>
            {term.map((x) => (
              <option key={x.id} alue={x.id}>
                {x.term}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="country" className="block text-sm font-medium text-gray-700">
            สถานศึกษา
          </label>
          <select
            value={academys}
            onChange={(e) => setAcademy(e.target.value)}
            className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          >
            <option value="">เลือก</option>
            {academy.map((x) => (
              <option key={x.id} value={x.id}>
                {x.academyName}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="country" className="block text-sm font-medium text-gray-700">
            จำนวนฉบับ
          </label>
          <input
            value={numbers}
            type="number"
            onChange={(e) => setNumber(e.target.value)}
            className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          />
        </div>
        <div className="col-span-2">
          <label htmlFor="country" className="block text-sm font-medium text-gray-700">
            วันที่
          </label>
          <input
            value={dateinput}
            type="date"
            onChange={(e) => setDateinput(e.target.value)}
            className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          />
        </div>
      </div>
      <div id="contentPrint">
        <div className="page">
          <div className="page-frem">
            <Image src={KRUT} className="KRUT-IMG" />
            <div className="text-header">
              <p className="text-16ptE ">ที่ อว ๐๖๓๒.๓ / ว. ๐๐๕๒</p>
            </div>
            <div className="text-address">
              <p className="text-16ptE">
                คณะครุศาสตร์
                <br />
                มหาวิทยาลัยราชภัฏกาญจนบุรี <br />
                อ.เมือง จ.กาญจนบุรี ๗๑๑๙๐
              </p>
            </div>
            <div className="text-date">
              <p className="text-16ptE">๖ มีนาคม ๒๕๖๔</p>
            </div>
            <div>
              <p className="text-16ptE">
                เรื่อง &nbsp;&nbsp;&nbsp;ขอความอนุเคราะห์สถานศึกษาฝึกปฏิบัติการสอนในสถานศึกษา&nbsp;
                {thaiNumber(academys)}
              </p>
            </div>
            <div>
              <p className="text-16ptE">เรียน &nbsp;&nbsp;&nbsp;ผู้อำนวยการโรงเรียนร่มเกล้ากาญจนบุรี</p>
            </div>
            <div>
              <p className="text-16ptE">สิ่งที่ส่งมาด้วย &nbsp;&nbsp;&nbsp;รายชื่อนักศึกษา</p>
              <div className="text-document">
                <p className="text-16ptE">จำนวน {thaiNumber(numbers)} ฉบับด้วย</p>
              </div>
            </div>

            <p className="text-16ptE page-paragraph lspacing-035px">
              ด้วยหลักสูตรครุศาสตรบัณฑิต (ค.บ.) ๕ ปีกำหนดให้นักศึกษาต้องฝึกปฏิบัติการวิชาชีพครู
              <br />
            </p>
            <p className="text-16ptE lspacing-024px">
              ในสถานศึกษา เป็นเวลา ๑ ปี คณะครุศาสตร์ มหาวิทยาลัยราชภัฏกาญจนบุรี จึงกำหนดให้นักศึกษาออกฝึก
            </p>
            <p className="text-16ptE">ปฏิบัติการสอนในสถานศึกษา ในภาคเรียนที่ ๑/๒๕๖๔ และ ๒/๒๕๖๔</p>
            <p className="text-16ptE lspacing-108px page-paragraph">
              คณะครุศาสตร์ &nbsp;&nbsp;&nbsp; จึงขอความอนุเคราะห์สถานศึกษาของท่านเป็นโรงเรียนร่วมฝึก
            </p>
            <p className="text-16ptE lspacing-013px">
              ปฏิบัติการสอนในสถานศึกษา {thaiNumber(academys)} และเพื่อให้นักศึกษาได้มีการเตรียมตัวล่วงหน้า
              จึงขอให้สถานศึกษาจัดภาระ
            </p>
            <p className="text-16ptE lspacing-005px">
              งานสอนที่ตรงสาขาวิชาของนักศึกษา ซึ่งนักศึกษาต้องปฏิบัติการสอนอย่างน้อยสัปดาห์ละ ๘ ชั่วโมง
              แต่ไม่เกิน
            </p>
            <p className="text-16ptE lspacing--005px">
              ๑๒ ชั่วโมง และจัดครูพี่เลี้ยงที่ตรงกับสาขาวิชาของนักศึกษา หรือมีประสบการณ์สอนในสาขาวิชานั้น
              อย่างน้อย
              <p className="text-16ptE lspacing-002px">
                ๓ ปี และมอบหมายงานอื่น ๆ ให้กับนักศึกษาทำในระหว่างฝึกปฏิบัติการวิชาชีพครู
                ซึ่งนักศึกษาจะเข้าไปติดต่อ
              </p>
              <p className="text-16ptE lspacing-002px">ขอรับมอบงานตามที่โรงเรียนนัดหมาย</p>
            </p>

            <div>
              <p className="text-16ptE page-paragraph ">
                จึงเรียนมาเพื่อโปรดพิจารณาและขอขอบพระคุณมา ณ โอกาสนี้
              </p>
            </div>
            <div>
              <p className="text-16ptE page-paragraph-center">ขอแสดงความนับถือ</p>
            </div>
            <div className="text-name">
              <p className="text-16ptE page-paragraph-name">(ผู้ช่วยศาสตราจารย์ ดร. ภูชิตภูชำนิ)</p>
              <p className="text-16ptE page-paragraph-name-position">คณบดีคณะครุศาสตร์</p>
              <p className="text-16ptE page-paragraph-name-university">มหาวิทยาลัยราชภัฏกาญจนบุรี</p>
            </div>
            <div className="foot-e">
              <p className="text-16ptE ">
                ฝ่ายฝึกประสบการณ์วิชาชีพครู
                <br />
                โทรศัพท์ 0 ๓๔๕๓ ๔๐๗๑ <br />
                โทรสาร 0 ๓๔๕๓ ๕๐๗๑
              </p>
            </div>
          </div>
        </div>
        <div className="page">
          <div className="page-frem-list">
            <div className="LOGOKRU">
              <Image src={LOGOKRU} className="LOGOKRU-IMG" />
            </div>
            <div className="list-name">
              <p className="text-16ptBold"> รายชื่อนักศึกษาฝึกปฏิบัติการสอนในสถานศึกษา ๒</p>
              <p className="text-16ptBold">
                ภาคเรียนที่ {thaiNumber(semester)} ปีการศึกษา {thaiNumber(year)}
              </p>
              <p className="text-16ptBold">หลักสูตรครุศาสตรบัณฑิต (ค.บ. ) ๕ ปีมหาวิทยาลัยราชภัฏกาญจนบุรี</p>
            </div>

            <div>
              <table className="table-auto">
                <thead>
                  <tr className="border table-color">
                    <th className=" px-5 py-2 border-1 border-black table-w">
                      <p className="text-16pt">โรงเรียน/หน่วยฝึก</p>
                    </th>
                    <th className="px-5 py-2 border-1 border-black">
                      <p className="text-16pt">ชื่อนักศึกษา</p>
                    </th>
                    <th className="px-5 py-2 border-1 border-black">
                      <p className="text-16pt">สาขาวิชา</p>
                    </th>
                    <th className="px-5 py-2 border-1 border-black">
                      <p className="text-16pt">เบอร์โทรศัพท์</p>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {findregis.map((item) => (
                    <tr key={item.regisId}>
                      <td className="px-3 py-1 border-1 border-black">
                        <p className="text-16pt">{item.schoolName}</p>
                      </td>
                      <td className="px-3 py-1 border-1 border-black">
                        <p className="text-16pt">{item.fullName}</p>
                      </td>
                      <td className="px-3 py-1 border-1 border-black">
                        <p className="text-16pt">{item.majorName}</p>
                      </td>
                      <td className="px-3 py-1 border-1 border-black">
                        <p className="text-16pt">{thaiNumber(item.phone)}</p>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <Box display="flex" justifyContent="center" p={2}>
        <Box mr={3}>
          <Button
            color="primary"
            variant="contained"
            size="large"
            onClick={() => {
              let css = "";
              let lin = "";
              let CssElem = document.getElementsByTagName("style");
              let link = document.getElementsByTagName("link");
              for (let index = 0; index < link.length; index++) {
                lin = lin + link[index].outerHTML;
              }
              for (let index = 0; index < CssElem.length; index++) {
                css = css + CssElem[index].outerHTML;
              }
              var divToPrint = document.getElementById("contentPrint"); // เลือก div id ที่เราต้องการพิมพ์
              var html =
                "<html>" +
                "<head>" +
                lin +
                css +
                "</head>" +
                '<body onload="window.print(); window.close();">' +
                divToPrint.innerHTML +
                "</body>" +
                "</html>";

              var popupWin = window.open();
              popupWin.document.open();
              popupWin.document.write(html);
              popupWin.document.close();
            }}
          >
            &nbsp;&nbsp;ปริ้น
          </Button>
        </Box>
      </Box>
    </>
  );
}

export default Etiquette_letter;
