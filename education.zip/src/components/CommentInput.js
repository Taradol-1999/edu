import React, { useEffect, useRef } from "react";
import SVGSend from "../SVGS/SVGSend";

export default function CommentInput({ value, onChange, onClose, name, onSubmit, ...etc }) {
  const textareaRef = useRef(null);

  useEffect(() => {
    textareaRef.current.style.height = "0px";
    const scrollHeight = textareaRef.current.scrollHeight;
    textareaRef.current.style.height = scrollHeight + "px";
  }, [value]);

  return (
    <div className="w-full border-t-2 border-gray-300 h-full rounded-b-xl">
      <div className="flex items-end relative w-full rounded-b-xl">
        <textarea
          ref={textareaRef}
          {...etc}
          value={value}
          rows={20}
          name={name}
          placeholder="แสดงความคิดเห็น..."
          type="text"
          className="w-full bg-gray-100 placeholder:font-italitc py-2 px-3 pb-10 pt-2 focus:outline-none h-[10rem] rounded-xl"
          onChange={onChange}
        />
        <span className={`absolute right-0 flex items-center px-3 py-1 ${value ? "cursor-pointer" : ""}`} onClick={onSubmit}>
          <SVGSend width="36" height="36" color={value ? "#6C6C6C" : "#BBBBBB"} strokeWidth="2" className="rotate-45" />
        </span>
      </div>
    </div>
  );
}
