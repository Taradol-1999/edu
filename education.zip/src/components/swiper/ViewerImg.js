import React from "react";
import ImgsViewer from "react-images-viewer";

export default function ViewerImg({ img = [], show, onClose, currImg, setCurrImg, ...porps }) {
  return (
    <div>
      <ImgsViewer currImg={currImg} backdropCloseable={true} showThumbnails={true} imgs={img} isOpen={show} onClose={onClose} preloadNextImg={true} {...porps} />
    </div>
  );
}
