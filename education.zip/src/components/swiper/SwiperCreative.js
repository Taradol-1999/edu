import React, { Fragment } from "react";
import { EffectCreative, Pagination, Autoplay, Keyboard, Navigation } from "swiper";
import { Swiper, SwiperSlide } from "swiper/react";

export default function SwiperCreative({ image = [], className }) {
  return (
    <Fragment>
      <Swiper
        effect={"creative"}
        creativeEffect={{
          prev: {
            shadow: true,
            translate: [0, 0, -400],
          },
          next: {
            translate: ["100%", 0, 0],
          },
        }}
        keyboard={{
          enabled: true,
        }}
        loop={true}
        grabCursor={true}
        autoplay={{
          delay: 2500,
          disableOnInteraction: false,
        }}
        pagination={{
          dynamicBullets: true,
        }}
        navigation={true}
        modules={[Keyboard, EffectCreative, Pagination, Autoplay, Navigation]}
      >
        {image.map((item, idx) => (
          <SwiperSlide key={idx}>
            <img src={item} alt={item} className="w-[100%] h-[600px]" />
          </SwiperSlide>
        ))}
      </Swiper>
    </Fragment>
  );
}
