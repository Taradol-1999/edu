// import React, { Fragment, useEffect, useState } from "react";
// import { Swiper, SwiperSlide } from "swiper/react";
// import { Autoplay, Pagination, Navigation, Scrollbar } from "swiper";
// import { TopSchool } from "../../../services/School.services";

// export default function LoopFillGroupWithBlank() {
//   const [topSchool, setTopSchool] = useState([]);

//   useEffect(() => {
//     loadData();
//   }, []);
//   async function loadData(amount = 10) {
//     let result = await TopSchool(amount);
//     if (result) {
//       setTopSchool(result.data);
//     }
//   }

//   return (
//     <Fragment>
//       <Swiper
//         slidesPerView={3}
//         spaceBetween={0}
//         slidesPerGroup={3}
//         loop={true}
//         loopFillGroupWithBlank={true}
//         pagination={{
//           dynamicBullets: true,
//         }}
//         scrollbar={{
//           hide: true,
//         }}
//         navigation={true}
//         grabCursor={true}
//         autoplay={{
//           delay: 4000,
//           disableOnInteraction: false,
//         }}
//         modules={[Autoplay, Pagination, Navigation, Scrollbar]}
//       >
//         {topSchool.map((item, index) => (
//           <SwiperSlide key={index}>
//             <div className="relative group w-96 h-96 overflow-hidden bg-white m-auto drop-shadow-3xl">
//               <img className="object-contain w-full h-full transform duration-700 backdrop-opacity-100" src={item.image} alt={item.schoolName} />
//               <div className="absolute w-full h-full shadow-2xl opacity-20 transform duration-500 inset-y-full group-hover:-inset-y-0" />
//               <div className="absolute bg-gradient-to-t from-black to-transparent w-full h-full transform duration-500 inset-y-2/4 group-hover:-inset-y-0">
//                 <p className="drop-shadow-black-2 capitalize font-bold text-3xl text-center text-white mt-10 group-hover:underline">อันดับที่ {index + 1}</p>
//                 <div className="absolute w-full flex place-content-center">
//                   <p className="drop-shadow-black-2 capitalize font-bold text-3xl text-center text-white mt-10">{item.schoolName}</p>
//                 </div>
//                 <div className="absolute w-full flex place-content-center mt-[6rem]">
//                   <p className="text-center w-4/5 text-white mt-5">
//                     <span className="font-bold"> ที่อยู่</span>
//                     <br /> {item.address}
//                   </p>
//                 </div>
//                 <div className="flex justify-center">
//                   <button className="absolute bottom-4  text-white font-bold rounded-lg h-10 w-32 bg-blue-600 hover:bg-blue-800">รายละเอียด</button>
//                 </div>
//               </div>
//             </div>
//           </SwiperSlide>
//         ))}
//       </Swiper>
//     </Fragment>
//   );
// }
