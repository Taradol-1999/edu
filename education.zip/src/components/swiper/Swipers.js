import React, { Fragment } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination, Navigation } from "swiper";

const Swipers = ({ image = [] }) => {
  return (
    <Fragment>
      <Swiper
        spaceBetween={30}
        loop={true}
        pagination={{
          clickable: true,
          dynamicBullets: true,
        }}
        autoplay={{
          delay: 3500,
          disableOnInteraction: false,
        }}
        loopFillGroupWithBlank={true}
        navigation={true}
        modules={[Pagination, Navigation, Autoplay]}
        className="mySwiper"
      >
        {image.map((img, inx) => (
          <SwiperSlide className="bg-red-100" key={inx}>
            {/* <img src={img} alt="" className="h-[45rem] w-full" /> */}

            <div
              className="relative h-64 w-full flex items-end justify-start text-left bg-cover bg-center"
              style={{
                backgroundImage: `url(${img})`,
              }}
            >
              <div className="absolute top-0 mt-20 right-0 bottom-0 left-0 bg-gradient-to-b from-transparent to-gray-900" />
              <div className="absolute top-0 right-0 left-0 mx-5 mt-2 flex justify-between items-center">
                <a href="#" className="text-xs bg-indigo-600 text-white px-5 py-2 uppercase hover:bg-white hover:text-indigo-600 transition ease-in-out duration-500">
                  Politics
                </a>
                <div className="text-white font-regular flex flex-col justify-start">
                  <span className="text-3xl leading-0 font-semibold">25</span>
                  <span className="-mt-3">May</span>
                </div>
              </div>
              <main className="p-5 z-10">
                <a href="#" className="text-md tracking-tight font-medium leading-7 font-regular text-white hover:underline">
                  Dr. Abdullah Abdullah's Presidential Election Campaign
                </a>
              </main>
            </div>
          </SwiperSlide>
        ))}
      </Swiper>
    </Fragment>
  );
};

export default Swipers;
