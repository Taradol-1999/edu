import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { nanoid } from "nanoid";
import PropTypes from "prop-types";
import SVGArrowRight from "../SVGS/SVGArrowRight";

function Breadcrumbs({ links, pathNameTH }) {
  const [path, setPath] = useState([]);

  useEffect(() => {
    setBreadcrumbs(links, pathNameTH);
  }, [links, pathNameTH]);

  function setBreadcrumbs(link, pathNames) {
    let paths = [];
    let count = link.split("/").length;
    if (count >= 1) {
      paths = link.split("/").slice(1, count);
    }
    let pathsTH = pathNames.substring(0, pathNames.length).split("/");
    let tmp = [];
    for (let index = 0; index < pathsTH.length; index++) {
      const tmpTH = pathsTH[index];
      if (index >= 1) {
        let curPath = paths.slice(0, index + 1);
        tmp.push({
          name: tmpTH,
          path: "/" + curPath.join("/"),
        });
      } else {
        tmp.push({
          name: tmpTH,
          path: "/" + paths[0],
        });
      }
    }
    setPath(tmp);
  }
  return (
    <nav className="flex text-white bg-transparent rounded-lg" aria-label="Breadcrumb">
      <ol className="flex flex-wrap items-center space-x-1 md:space-x-3">
        <li className="flex flex-wrap items-center">
          {path.length >= 1 ? (
            <Link to={path[0].path === "/" ? "#" : "/"} className={path[0].path === "/" ? "inline-flex font-bold text-sm text-gray-200 md:ml-2" : "inline-flex font-bold  items-center text-sm hover:text-gray-200 "}>
              <svg className="w-5 h-5 mr-2" stroke="#bfdbfe" strokeWidth="1" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z" />
              </svg>
              หน้าแรก
            </Link>
          ) : (
            <></>
          )}
        </li>
        {path.length === 0 || path[0].path === "/" ? (
          <></>
        ) : (
          path.map((value, index) =>
            index === path.length - 1 ? (
              <li aria-current="page" key={nanoid()}>
                <div className="flex items-center">
                  <SVGArrowRight width="24" height="24" color="#FFFFFF" strokeWidth="2" />
                  <span className="ml-1 text-sm font-bold text-gray-300 md:ml-2 dark:text-gray-500">{value.name}</span>
                </div>
              </li>
            ) : (
              <li key={nanoid()}>
                <div className="flex items-center">
                  <SVGArrowRight width="24" height="24" color="#FFFFFF" strokeWidth="2" />
                  <Link to={value.path} className="ml-5 text-sm font-bold text-white hover:text-gray-200 md:ml-2 dark:text-gray-200 dark:hover:text-white">
                    {value.name}
                  </Link>
                </div>
              </li>
            )
          )
        )}
      </ol>
    </nav>
  );
}

Breadcrumbs.defaultProps = {
  links: "",
  pathNameTH: "",
};

Breadcrumbs.propTypes = {
  links: PropTypes.string.isRequired,
  pathNameTH: PropTypes.string.isRequired,
};

export default Breadcrumbs;
