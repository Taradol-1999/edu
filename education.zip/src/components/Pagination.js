import React, { useEffect } from "react";
import { nanoid } from "nanoid";
import PropTypes from "prop-types";
Pagination.propTypes = {
  currentPages: PropTypes.number,
  totalPage: PropTypes.number,
};

Pagination.defaultProps = {
  currentPages: 1,
  totalPage: 1,
  onChange: (page) => {
    return page;
  },
};
export default function Pagination({ onChange, currentPages, totalPage, totalRow, idToTop }) {
  const [currentPage, setCurrentPage] = React.useState(currentPages);

  useEffect(() => {
    setCurrentPage(currentPages);
  }, [currentPages]);

  let maxPages = totalPage;
  let items = [];
  let leftSide = 0;
  let rightSide = 0;

  if (maxPages <= 5) {
    leftSide = 1;
    rightSide = maxPages;
  } else if (currentPage <= 4) {
    leftSide = 1;
    rightSide = 5;
  } else if (currentPage + 2 >= maxPages) {
    leftSide = maxPages - 4;
    rightSide = maxPages;
  } else {
    leftSide = currentPage - 2;
    rightSide = currentPage + 2;
  }

  const scrollTop = () => {
    document.getElementById(idToTop).scrollIntoView({ top: 0, behavior: "smooth" });
  };

  for (let number = leftSide; number <= rightSide; number++) {
    items.push(
      <div
        onClick={() => {
          setCurrentPage(number);
          onChange(number);
          scrollTop();
        }}
        key={number}
        className={
          "inline-flex items-center w-10 h-10 text-sm font-medium cursor-pointer rounded-full justify-center hover:text-gray-300 " +
          (number === currentPage ? "bg-blue-700 text-white  border-blue-800" : "  border-gray-300")
        }
      >
        {number}
      </div>
    );
  }

  const nextPage = () => {
    if (currentPage < maxPages) {
      setCurrentPage(currentPage + 1);
      onChange(currentPage + 1);
    }
  };

  const prevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
      onChange(currentPage - 1);
    }
  };

  return (
    <div id={nanoid()} className={totalRow > 0 ? "items-center justify-between py-1 flex flex-col lg:flex-row" : "hidden"}>
      <div className="flex flex-col lg:flex-row items-center space-x-2 text-sm">
        <p className="text-gray-600 ">
          แสดง {currentPage} จาก {totalPage} หน้า (ทั้งหมด {totalRow} รายการ)
        </p>
      </div>
      <div className="flex justify-start items-center ">
        <button
          type="button"
          onClick={() => {
            if (currentPage > 1) {
              setCurrentPage(1);
              onChange(1);
            }
          }}
          className=" focus:outline-none inline-flex items-center px-1 py-1 text-sm font-medium cursor-pointer hover:text-gray-500"
        >
          <span>หน้าแรก</span>
        </button>
        <button
          type="button"
          onClick={() => {
            prevPage();
          }}
          className="py-2 rounded focus:outline-none hover:text-gray-500 "
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>
        {items}
        <button
          type="button"
          onClick={() => {
            nextPage();
          }}
          className="py-2 rounded focus:outline-none hover:text-gray-500 "
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </button>
        <button
          type="button"
          onClick={() => {
            if (currentPage < maxPages) {
              setCurrentPage(totalPage);
              onChange(totalPage);
            }
          }}
          className="focus:outline-none inline-flex items-center px-1 py-1 text-sm font-medium cursor-pointer hover:text-gray-500"
        >
          <span>หน้าสุดท้าย</span>
        </button>
      </div>
    </div>
  );
}
