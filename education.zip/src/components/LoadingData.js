// import { nanoid } from "nanoid";
import React from "react";
import loading from "../assets/img/loading.gif";

// export default function LoadingData({ count, className, colSpan, classNameDiv }) {
//   return Array.from(Array(count), () => {
//     return (
//       <tr key={nanoid()}>
//         <td className={className} colSpan={colSpan}>
//           <div className={`p-4 bg-red-200 rounded-md animate-pulse ${classNameDiv}`} />
//         </td>
//       </tr>
//     );
//   });
// }

export default function LoadingData() {
  return <img width={70} src={loading} alt="loading" />;
}
