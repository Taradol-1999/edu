import React from "react";
import Select from "react-select";
export const SelectPageSize = ({ title, placeholder, paginPageSize, ...props }) => {
  const customStyles = {
    control: (base) => ({
      ...base,
      height: "45px",
      width: "90px",
      background: "#f5f5f5",
      borderColor: "transparent",
      boxShadow: "transparent",
      borderRadius: "0.5rem",
      "&:hover": {
        borderColor: "#eceaea",
      },
    }),
  };
  return <Select styles={customStyles} {...props} noOptionsMessage={() => <p className="text-red-700">ไม่พบข้อมูล !</p>} placeholder="" />;
};
