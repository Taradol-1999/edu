import React, { Fragment } from "react";
import Button from "@material-tailwind/react/Button";
import SVGClose from "../../SVGS/SVGClose";
import SVGMenu from "../../SVGS/SVGMenu";
import Breadcrumbs from "../../components/Breadcrumbs";

function Header({ showSidebar, setShowSidebar, pathNameTH, links }) {
  return (
    <Fragment>
      <nav className="bg-blue-600 md:ml-[20rem] py-6 px-3">
        <div className="container max-w-full mx-auto flex items-center justify-between md:pr-8 md:pl-10">
          <div className="md:hidden">
            <Button color="transparent" buttonType="link" size="lg" iconOnly rounded ripple="light" onClick={() => setShowSidebar("left-0")}>
              <SVGMenu width="28" height="28" color="#FFFFFF" strokeWidth="2" />
            </Button>
            <div className={`absolute top-2 md:hidden ${showSidebar === "left-0" ? "left-64" : "-left-64"} z-50 transition-all duration-300`}>
              <Button color="transparent" buttonType="link" size="lg" iconOnly rounded ripple="light" onClick={() => setShowSidebar("-left-64")}>
                <SVGClose width="28" height="28" color="#FFFFFF" strokeWidth="2" />
              </Button>
            </div>
          </div>

          <div className="flex justify-between items-center w-full">
            <Breadcrumbs pathNameTH={pathNameTH} links={links} />
          </div>
        </div>
      </nav>
    </Fragment>
  );
}

export default Header;
