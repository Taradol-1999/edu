import React, { Fragment, useEffect, useState } from "react";
import Footer from "./Footer";
import Sidebar from "./Sidebar";
import { ToastContainer } from "react-toastify";

export default function PrivateLayout({ children, pathNameTH, path }) {
  const [showSidebar, setShowSidebar] = useState("-left-[768px]");
  useEffect(() => {
    let element = document.querySelector("body");
    element.classList.add("bg-sky-50");
    return () => {
      element.classList.remove("bg-sky-50");
    };
  }, []);

  return (
    <Fragment>
      <ToastContainer position="bottom-right" autoClose={1000} />
      <Sidebar pathNameTH={pathNameTH} path={path} showSidebar={showSidebar} setShowSidebar={setShowSidebar} />
      <div className="md:ml-[20rem] mt-6  ">
        <div style={{ minHeight: "calc(120vh - 300px)" }} className="px-4 md:px-3 lg:px-8 ">
          <div className="w-full">
            <div className="p-4 break-words bg-white rounded-md shadow-xl" style={{ minHeight: "calc(120vh - 330px)" }}>
              {children}
            </div>
          </div>
        </div>
        <Footer showSidebar={showSidebar} setShowSidebar={setShowSidebar} />
      </div>
    </Fragment>
  );
}
