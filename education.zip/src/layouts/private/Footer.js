import React from "react";

export default function Footer() {
  return (
    <footer className="py-4 px-16 border-t border-gray-200 font-light flex flex-col lg:flex-row  items-center justify-center">
      <p className="text-gray-700  text-center">
        Copyright &copy; {new Date().getFullYear() + 543}
        <a href="https://www.creative-tim.com?ref=mtdk" target="_blank" rel="noreferrer" className="text-light-blue-500 hover:text-light-blue-700">
          &nbsp; Taradol
        </a>
      </p>
    </footer>
  );
}
