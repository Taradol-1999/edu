/* eslint-disable react-hooks/exhaustive-deps */
import React, { Fragment, useState } from "react";
import { NavLink } from "react-router-dom";
import Header from "./Header";
import SVGTeacher from "../../SVGS/SVGTeacher";
import SVGUser from "../../SVGS/SVGUser";
import SVGFlag from "../../SVGS/SVGFlag";
import SVGPublish from "../../SVGS/SVGPublish";
import SVGRegister from "../../SVGS/SVGRegister";
import SVGUserPlus from "../../SVGS/SVGUserPlus";
import SVGHome from "../../SVGS/SVGHome";
import SVGLogout from "../../SVGS/SVGLogout";
import { Disclosure } from "@headlessui/react";
import { MinusSmIcon, PlusSmIcon } from "@heroicons/react/solid";
import SVGSetting from "../../SVGS/SVGSetting";
import { useHistory } from "react-router-dom";
import { connect } from "react-redux";
import { AUTHEN, USERINFO } from "../../actions/Authen";
import SVGPresentation from "../../SVGS/SVGPresentation ";
import SVGOpenRegister from "../../SVGS/SVGOpenRegister";
import jwt_decode from "jwt-decode";
import Clock from "../../components/Date/Clock";
import { useEffect } from "react";
import FromUserModal from "../../views/private/setting/users/FromUserModal";
import SVGWriting from "../../SVGS/SVGWriting";
import SVGReport from "../../SVGS/SVGReport";

function Sidebar(auth) {
  let history = useHistory();
  let accessToken = localStorage.getItem("accessToken");
  const data = JSON.parse(localStorage.getItem("users"));
  const [deadline, seDeadline] = useState(Date.now());
  const [openUser, setOpenUser] = useState(false);
  function signOut() {
    localStorage.removeItem("users");
    localStorage.removeItem("accessToken");
    localStorage.removeItem("role");
    auth.USERINFO();
    history.push("/");
  }

  useEffect(() => {
    onAction(accessToken);
  }, [accessToken]);

  const onAction = async (tokens) => {
    if (tokens) {
      const token = await jwt_decode(tokens);
      const exp = new Date(0);
      exp.setUTCSeconds(token.exp);
      seDeadline(exp);
      if (1 <= 0) {
        signOut();
      }
    }
  };

  return (
    <Fragment>
      <Header showSidebar={auth.showSidebar} setShowSidebar={auth.setShowSidebar} pathNameTH={auth.pathNameTH} links={auth.path} />
      <FromUserModal openUser={openUser} setOpenUser={setOpenUser} />
      <div
        className={`h-screen fixed top-0 md:left-0 ${auth.showSidebar} overflow-y-auto flex-row flex-nowrap overflow-hidden shadow-xl bg-white w-[20rem] z-10 py-2 px-2 transition-all duration-300`}
      >
        <div className="flex-col items-stretch min-h-full flex-nowrap px-0 relative">
          <div className="flex justify-center">
            <p className="flex font-bold items-center text-blue-700 gap-2 text-3xl py-5">
              <SVGTeacher width="50" height="50" color="#111827" strokeWidth="2" />
              EDU
            </p>
          </div>
          <div className="border-b border-l border-r border-gray-400" />
          <ul className="flex-col min-w-full flex list-none mt-2">
            <li className="rounded-lg mb-2">
              <NavLink to="/MainPage" activeClassName="activeSidebar" className={`classNameSidebar ${auth.path === "/" ? "activeSidebar " : ""}`}>
                <SVGHome width="28" height="28" color="#1d4ed8" strokeWidth="1.5" />
                <span className="text-sm font-medium"> หน้าแรก</span>
              </NavLink>
            </li>
            <li className="rounded-lg mb-2">
              <NavLink to="/MainActivity" activeClassName="activeSidebar" className="classNameSidebar">
                <SVGPublish width="28" height="28" color="#2563eb" strokeWidth="1.5" />
                <span className="text-sm font-medium">ประชาสัมพันธ์</span>
              </NavLink>
            </li>
            {/* ระบบการทะเบียน */}
            <div className="rounded-lg mb-2">
              <Disclosure>
                {({ open }) => (
                  <>
                    <Disclosure.Button className="classNameSidebar-header flex justify-between focus:outline-none">
                      <p className="flex items-center ">
                        <SVGUserPlus width="28" height="28" color="#2563eb" strokeWidth="1.5" />
                        <span className="text-sm font-medium ml-3 w-full">ระบบฝึกประสบการณ์วิชาชีพครู</span>
                      </p>
                      <span className="inline-flex items-end justify-end text-sm w-5">
                        {open ? <MinusSmIcon className="h-5 w-5  duration-500" aria-hidden="true" /> : <PlusSmIcon className="h-5 w-5" aria-hidden="true" />}
                      </span>
                    </Disclosure.Button>
                    <Disclosure.Panel className="px-4 pt-4 pb-2 text-sm text-gray-500">
                      <li className="rounded-lg mb-2">
                        <NavLink to="/MainRegister" activeClassName="activeSidebar" className="classNameSidebar">
                          <SVGRegister width="28" height="28" color="#1d4ed8" strokeWidth="1.5" />
                          <span className="text-sm font-medium">ข้อมูลฝึกประสบการณ์วิชาชีพครู</span>
                        </NavLink>
                      </li>
                      <li className="rounded-lg mb-2">
                        <NavLink to="/MainAppoint" activeClassName="activeSidebar" className="classNameSidebar">
                          <SVGPresentation width="28" height="28" color="#2563eb" strokeWidth="1.5" />
                          <span className="text-sm font-medium">แต่งตั้งอาจารย์นิเทศ</span>
                        </NavLink>
                      </li>
                      <li className="rounded-lg mb-2">
                        <NavLink to="/report" activeClassName="activeSidebar" className="classNameSidebar">
                          <SVGReport width="28" height="28" color="#2563eb" strokeWidth="1.5" />
                          <span className="text-sm font-medium">รายงานผลการฝึกประสบการณ์วิชาชีพครู</span>
                        </NavLink>
                      </li>
                    </Disclosure.Panel>
                  </>
                )}
              </Disclosure>
            </div>
            {/* ตั้งค่า */}
            <div className="rounded-lg mb-2">
              <Disclosure>
                {({ open }) => (
                  <>
                    <Disclosure.Button className="classNameSidebar-header focus:outline-none">
                      <p className="flex items-center ">
                        <SVGSetting width="28" height="28" color="#2563eb" strokeWidth="1.5" />
                        <span className="text-sm font-medium ml-3">ตั้งค่า</span>
                      </p>
                      <span className="inline-flex items-end justify-end text-sm ml-20">
                        {open ? <MinusSmIcon className="h-5 w-5" aria-hidden="true" /> : <PlusSmIcon className="h-5 w-5" aria-hidden="true" />}
                      </span>
                    </Disclosure.Button>
                    <Disclosure.Panel className="px-4 pt-4 pb-2 text-sm text-gray-500">
                      <li className="rounded-lg mb-1">
                        <NavLink to="/setting-register" activeClassName="activeSidebar" className="classNameSidebar">
                          <SVGWriting width="28" height="28" color="#2563eb" strokeWidth="1.5" />
                          <span className="text-sm font-medium">ตั้งค่าการลงทะเบียน</span>
                        </NavLink>
                      </li>
                      <li className="rounded-lg mb-1">
                        <NavLink to="/Mainschools" activeClassName="activeSidebar" className="classNameSidebar">
                          <SVGFlag width="28" height="28" color="#2563eb" strokeWidth="1.5" />
                          <span className="text-sm font-medium"> โรงเรียน</span>
                        </NavLink>
                      </li>
                      <li className="rounded-lg mb-1">
                        <NavLink to="/MainUsers" activeClassName="activeSidebar" className="classNameSidebar">
                          <SVGUser width="28" height="28" color="#2563eb" strokeWidth="1.5" />
                          <span className="text-sm font-medium">ผู้ใช้งาน</span>
                        </NavLink>
                      </li>
                      <li className="rounded-lg mb-1">
                        <NavLink to="/main-open-registration" activeClassName="activeSidebar" className="classNameSidebar">
                          <SVGOpenRegister width="28" height="28" color="#2563eb" strokeWidth="1.5" />
                          <span className="text-sm font-medium">เปิดการลงทะเบียนแจ้งความประสงค์</span>
                        </NavLink>
                      </li>
                    </Disclosure.Panel>
                  </>
                )}
              </Disclosure>
            </div>
          </ul>
          <ul className="flex-col min-w-full flex list-none absolute bottom-0">
            {/* <Clock deadline={deadline} /> */}
            <button
              onClick={() => {
                // history.push("/MainUsers/FromUser?id=" + data.userId);
                setOpenUser(data.userId);
              }}
              className="bg-blue-700 px-4 rounded-lg text-gray-100 mb-2 flex flex-row items-center h-12 transform hover:translate-x-2 transition-transform hover:text-white focus:outline-none"
            >
              <SVGUser width="26" height="26" color="#FFFFFF" strokeWidth="1.5" className="h-9 w-9 ml-2 p-1" />
              <span className="text-sm font-medium ml-2">แก้ไขข้อมูลส่วนตัว</span>
            </button>
            <button
              onClick={() => {
                signOut();
              }}
              className="bg-red-700 px-4 rounded-lg text-gray-100 mb-2 flex flex-row items-center h-12 transform hover:translate-x-2 transition-transform hover:text-white focus:outline-none"
            >
              <SVGLogout width="28" height="28" color="#FFFFFF" strokeWidth="1.5" />
              <span className="text-sm font-medium ml-2"> ออกจากระบบ</span>
            </button>
          </ul>
        </div>
      </div>
    </Fragment>
  );
}
const mapStateToProps = (state) => ({
  auth: state.Authentication,
});

const mapDispatchToProps = (dispatch) => {
  return {
    AUTHEN: (users, accessToken, role) => dispatch(AUTHEN(users, accessToken, role)),
    USERINFO: () => dispatch(USERINFO()),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Sidebar);
