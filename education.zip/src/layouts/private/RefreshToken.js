import React, { Fragment, useRef } from "react";
import IdleTimer from "react-idle-timer";

export default function RefreshToken({ signOut }) {
  const IdleTimerRef = useRef(null);

  const onIdle = () => {
    signOut();
  };

  return (
    <Fragment>
      <IdleTimer ref={IdleTimerRef} element={document} timeout={10 * 60 * 1000} debounce={250} onIdle={onIdle} />
    </Fragment>
  );
}
