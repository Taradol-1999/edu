import React, { Fragment } from "react";
import SVGTeacher from "../../SVGS/SVGTeacher";
export default function Footer() {
  return (
    <Fragment>
      <footer className="bg-gradient-to-b from-white via-blue-200 to-blue-400 drop-shadow-md">
        <div className="max-w-screen-xl px-4 py-10 mx-auto sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
            <div>
              <p className="flex items-center">
                <SVGTeacher width="55" height="55" color="#2c3e50" strokeWidth="2" />
                <span className="self-center text-4xl font-semibold">&nbsp;EDU</span>
              </p>
              <p className="max-w-xs mt-4 text-sm text-gray-600">ฝ่ายฝึกประสบการณ์วิชาชีพครู คณะครุศาสตร์ มหาวิทยาลัยราชภัฏกาญจนบุรี</p>
              <div className="flex mt-8 space-x-6 text-gray-600">
                <p className="hover:opacity-90">
                  <span className="sr-only"> Facebook </span>
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path
                      fillRule="evenodd"
                      d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z"
                      clipRule="evenodd"
                    />
                  </svg>
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 gap-8 lg:col-span-2 sm:grid-cols-2 lg:grid-cols-3 ">
              <div>
                <p className="font-medium">ที่อยู่</p>
                <nav className="flex flex-col mt-4 space-y-2 text-sm text-gray-700">
                  <p className="hover:opacity-90">เลขที่ 70 หมู่ 4</p>
                  <p className="hover:opacity-90">ตำบล : หนองบัว</p>
                  <p className="hover:opacity-90">อำเภอ : เมืองกาญจนบุรี</p>
                  <p className="hover:opacity-90">จังหวัด : กาญจนบุรี</p>
                  <p className="hover:opacity-90">รหัสไปรษณีย์ : 71190</p>
                </nav>
              </div>
              <div>
                <p className="font-medium">ติดต่อ</p>
                <nav className="flex flex-col mt-4 space-y-2 text-sm text-gray-700">
                  <p className="hover:opacity-90">โทรศัพท์ : 034-534071</p>
                  <p className="hover:opacity-90">โทรสาร : 034-534071</p>
                  <p className="hover:opacity-90">เว็บไซต์ : http://ed.kru.ac.th</p>
                  <p className="hover:opacity-90 flex">
                    ที่ตั้ง :&nbsp;
                    <a rel="noopener noreferrer" href="https://goo.gl/maps/23daTEFbZvyxAtCU8" title="website" className="flex items-center" target="_blank">
                      มหาวิทยาลัยราชภัฏกาญจนบุรี
                    </a>
                  </p>
                </nav>
              </div>
              <div>
                <p className="font-medium">โซเชียลมีเดีย</p>
                <nav className="flex flex-col mt-4 space-y-2 text-sm text-gray-700">
                  <p className="hover:opacity-90 flex">
                    เฟสบุค :
                    <a rel="noopener noreferrer" href="https://www.facebook.com/kaninternshipedu" title="website" className="flex items-center" target="_blank">
                      ฝ่ายฝึกประสบการณ์วิชาชีพครู
                    </a>
                  </p>
                  <p className="hover:opacity-90 flex">
                    เว็บไซต์ :&nbsp;
                    <a rel="noopener noreferrer" href="https://ed.kru.ac.th/" title="website" className="flex items-center" target="_blank">
                      ed.kru.ac.th
                    </a>
                  </p>
                </nav>
              </div>
            </div>
          </div>
          <p className="mt-8 text-xs text-gray-800">
            © 2020 Tailblocks —
            <a href="https://www.facebook.com/Taradol2363/" className="text-gray-600 ml-1" rel="noopener noreferrer" target="_blank">
              @ ธาราดล
            </a>
          </p>
        </div>
      </footer>

      {/* <footer>
        <div className="flex flex-col justify-between py-5 mx-auto space-y-8 lg:flex-row lg:space-y-0">
          <div className="lg:w-1/3 border-r border-blue-200 flex items-center justify-center">
            <p className="flex justify-center items-center space-x-3 lg:justify-center">
              <SVGTeacher width="55" height="55" color="#2c3e50" strokeWidth="2" />
              <span className="self-center text-4xl font-semibold">EDU</span>
            </p>
          </div>
          <div className="grid grid-cols-2 text-sm gap-x-3 gap-y-8 lg:w-2/3 sm:grid-cols-4 p-2">
            <div className="space-y-3">
              <h3 className="uppercase dark:text-gray-700 text-lg">ฝ่ายฝึกประสบการณ์วิชาชีพครู</h3>
              <ul className="space-y-1">
                <li>
                  <p rel="noopener noreferrer">คณะครุศาสตร์</p>
                </li>
                <li>
                  <p rel="noopener noreferrer">มหาวิทยาลัยราชภัฏกาญจนบุรี</p>
                </li>
              </ul>
            </div>
            <div className="space-y-3">
              <h3 className="tracking-wide uppercasedark:text-gray-7 text-lg">ที่อยู่</h3>
              <ul className="space-y-1">
                <li>
                  <p rel="noopener noreferrer">เลขที่ 70 หมู่ 4</p>
                </li>
                <li>
                  <p rel="noopener noreferrer">ตำบล : หนองบัว</p>
                </li>
                <li>
                  <p rel="noopener noreferrer">อำเภอ : เมืองกาญจนบุรี</p>
                </li>
                <li>
                  <p rel="noopener noreferrer">จังหวัด : กาญจนบุรี</p>
                </li>
                <li>
                  <p rel="noopener noreferrer">รหัสไปรษณีย์ : 71190</p>
                </li>
              </ul>
            </div>
            <div className="space-y-3">
              <h3 className="tracking-wide uppercasedark:text-gray-7 text-lg">ติดต่อ</h3>
              <ul className="space-y-1">
                <li>
                  <p rel="noopener noreferrer">โทรศัพท์ : 034-534071</p>
                </li>
                <li>
                  <p rel="noopener noreferrer">โทรสาร : 034-534071</p>
                </li>
                <li>
                  <p rel="noopener noreferrer">เว็บไซต์ : http://ed.kru.ac.th</p>
                </li>
              </ul>
            </div>
            <div className="space-y-3">
              <div className="uppercasedark:text-gray-7 text-lg">โซเชียลมีเดีย</div>
              <div className="flex justify-start space-x-3">
                <a rel="noopener noreferrer" href="https://www.facebook.com/kaninternshipedu" title="Facebook" className="flex items-center p-1" target="_blank">
                  <svg fill="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} className="w-6 h-6 text-blue-600" viewBox="0 0 24 24">
                    <path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z" />
                  </svg>
                </a>
                <a rel="noopener noreferrer" href="https://ed.kru.ac.th/" title="website" className="flex items-center p-1" target="_blank">
                  <svg xmlns="http://www.w3.org/2000/svg" width={16} height={16} fill="currentColor" className="bi bi-calendar3-week text-blue-600 w-6 h-6" viewBox="0 0 16 16">
                    <path d="M14 0H2a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zM1 3.857C1 3.384 1.448 3 2 3h12c.552 0 1 .384 1 .857v10.286c0 .473-.448.857-1 .857H2c-.552 0-1-.384-1-.857V3.857z" />
                    <path d="M12 7a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm-5 3a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm2-3a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm-5 3a1 1 0 1 0 0-2 1 1 0 0 0 0 2z" />
                  </svg>
                </a>
              </div>
            </div>
          </div>
        </div>
        <div className="flex justify-center items-center py-2 border-t mx-10 border-blue-200">
          <a href="https://www.kru.ac.th/kru/" target="_blank" className="flex title-font font-medium items-center md:justify-start justify-center text-gray-900" rel="noopener noreferrer">
            <img src={LOGOKRU} alt={LOGOKRU} className="w-8 h-8" />
            <span className="ml-3 text-sm">Kanchanaburi Rajabhat University</span>
          </a>
          <p className="text-sm text-gray-500 ml-4 pl-4 border-l-2 border-blue-200 py-2 ">
            © 2020 Tailblocks —
            <a href="https://www.facebook.com/Taradol2363/" className="text-gray-600 ml-1" rel="noopener noreferrer" target="_blank">
              @ ธาราดล
            </a>
          </p>
        </div>
      </footer> */}
    </Fragment>
  );
}
