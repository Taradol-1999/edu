import React, { Fragment, useState, useEffect } from "react";
import Footer from "./Footer";
import Header from "./Header";
import "../../styles/publicLayout.css";
import { ToastContainer } from "react-toastify";
import { Transition } from "react-transition-group";
import { useLocation } from "react-router-dom";

const defaultStyle = {
  transition: `opacity ${200}ms ease-in-out`,
  opacity: 0,
};
const transitionStyles = {
  entering: { opacity: 0 },
  entered: { opacity: 1 },
  exiting: { opacity: 1 },
  exited: { opacity: 0 },
};
export default function PublicLayout(props) {
  const [inProp, setInProp] = useState(false);
  let location = useLocation();
  // scrollTop
  const [showScroll, setShowScroll] = useState(false);
  const checkScrollTop = () => {
    if (!showScroll && window.pageYOffset > 200) {
      setShowScroll(true);
    } else if (showScroll && window.pageYOffset <= 200) {
      setShowScroll(false);
    }
  };
  const scrollTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  window.addEventListener("scroll", checkScrollTop);
  // scrollTop

  useEffect(() => {
    if (location.pathname) setInProp(true);
  }, [location.pathname]);

  return (
    <Fragment>
      <ToastContainer position="bottom-right" autoClose={1000} />
      <Header chkReq={props.chkReq} props={props} />
      <Transition in={inProp} timeout={200} unmountOnExit>
        {(state) => (
          <div
            style={{
              ...defaultStyle,
              ...transitionStyles[state],
            }}
          >
            <main
              className={`w-full items-center justify-center border-blue-700 border-t-2 bg-blue-50 ${props.auth.role !== "1" && location.pathname !== "/" && "lg:px-20 px-10 py-10"}`}
              style={{ minHeight: "calc(120vh - 520px)" }}
            >
              {props.children}
            </main>
          </div>
        )}
      </Transition>
      <Footer />
      <div className="bottom-[4rem] sticky flex justify-end -mt-[4rem] z-50 ">
        <button
          onClick={() => scrollTop()}
          className={`${showScroll ? " focus:outline-none absolute mr-5 bg-blue-700 hover:bg-blue-800 w-[3rem] h-[3rem] rounded-full flex items-center justify-center" : "hidden"} `}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 -rotate-90" fill="none" viewBox="0 0 24 24" stroke="#FFF">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </button>
      </div>
    </Fragment>
  );
}
