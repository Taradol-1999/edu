import React, { Fragment, useState } from "react";
import SVGTeacher from "../../SVGS/SVGTeacher";
import { Transition, Menu } from "@headlessui/react";
import Login from "../../views/Login/Login";
import { useHistory } from "react-router-dom";
import SVGMenu from "../../SVGS/SVGMenu";
import SVGHome from "../../SVGS/SVGHome";
import SVGLogin from "../../SVGS/SVGLogin";
import SVGInfo from "../../SVGS/SVGInfo";
import { AUTHEN, USERINFO } from "../../actions/Authen";
import { connect } from "react-redux";
import SVGLogout from "../../SVGS/SVGLogout";
import SVGRegister from "../../SVGS/SVGRegister";
import FormPasswordRequest from "../../views/public/pass-request/FormPasswordRequest";
import FromUserModal from "../../views/private/setting/users/FromUserModal";
import FormMentorModal from "../../views/private/setting/users/FormMentorModal";

function Header({ chkReq, auth, props }) {
  let history = useHistory();
  let [isOpen, setIsOpen] = useState(false);
  const [openUser, setOpenUser] = useState(false);
  const [passReq, setPassReq] = useState(false);
  let users = JSON.parse(auth.users);
  return (
    <Fragment>
      <header className="lg:px-16 px-10 bg-blue-600 flex flex-wrap items-center lg:py-0 py-3  sticky top-0 z-20 justify-between shadow-md">
        <div className="flex-1 flex justify-between items-center">
          <p onClick={() => history.push("/")} className="cursor-pointer flex title-font font-medium items-center text-white md:mb-0 text-center ">
            <SVGTeacher width="44" height="44" color="#FFFFFF" strokeWidth="2" />
            <span className="ml-3 text-xl">EDU</span>
          </p>
          <div className="lg:hidden block w-full">
            <div className="flex justify-end">
              <Menu as="div" className="relative inline-block text-left">
                <Menu.Button className="inline-flex justify-center w-full px-4 py-2 text-sm font-medium text-white bg-transparent rounded-md focus:outline-none">
                  <SVGMenu width="24" height="24" color="#FFFFFF" strokeWidth="2" className="ml-2" />
                </Menu.Button>
                <Transition
                  as={Fragment}
                  enter="transition ease-out duration-100"
                  enterFrom="transform opacity-0 scale-95"
                  enterTo="transform opacity-100 scale-100"
                  leave="transition ease-in duration-75"
                  leaveFrom="transform opacity-100 scale-100"
                  leaveTo="transform opacity-0 scale-95"
                >
                  <Menu.Items className="absolute right-0 w-56 mt-2 origin-top-right bg-white rounded-md shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
                    <div className="px-1 py-1">
                      <Menu.Item>
                        {({ active }) => (
                          <button className="bg-white hover:bg-blue-600 duration-300 hover:scale-95 group flex rounded-md items-center w-full px-2 py-2 text-sm" onClick={() => history.push("/")}>
                            {active ? (
                              <SVGHome width="24" height="24" color="#FFFFFF" strokeWidth="1.5" className="mr-1" />
                            ) : (
                              <SVGHome width="24" height="24" color="#000000" strokeWidth="1.5" className="mr-1" />
                            )}
                            {active ? <p className="text-white">หน้าหลัก</p> : <p className="text-black">หน้าหลัก</p>}
                          </button>
                        )}
                      </Menu.Item>
                    </div>
                    <div className="px-1 py-1">
                      <Menu.Item>
                        {({ active }) => (
                          <button
                            className="bg-white hover:bg-blue-600 duration-300 hover:scale-95 text-white group flex rounded-md items-center w-full px-2 py-2 text-sm"
                            onClick={() => history.push("/AboutUs")}
                          >
                            {active ? (
                              <SVGInfo width="24" height="24" color="#FFFFFF" strokeWidth="1.5" className="mr-1" />
                            ) : (
                              <SVGInfo width="24" height="24" color="#000000" strokeWidth="1.5" className="mr-1" />
                            )}
                            {active ? <p className="text-white">เกี่ยวกับเรา</p> : <p className="text-black">เกี่ยวกับเรา</p>}
                          </button>
                        )}
                      </Menu.Item>
                    </div>
                    <div className="px-1 py-1">
                      {props.auth.role === "3" && (
                        <Menu.Item>
                          {({ active }) => (
                            <button
                              className="bg-white hover:bg-blue-600 duration-300 hover:scale-95 text-white group flex rounded-md items-center w-full px-2 py-2 text-sm"
                              onClick={() => history.push("/MainRegister")}
                            >
                              {active ? (
                                <SVGRegister width="24" height="24" color="#FFFFFF" strokeWidth="1.5" className="mr-1" />
                              ) : (
                                <SVGRegister width="24" height="24" color="#000000" strokeWidth="1.5" className="mr-1" />
                              )}
                              {active ? <p className="text-white">การลงทะเบียน</p> : <p className="text-black">การลงทะเบียน</p>}
                            </button>
                          )}
                        </Menu.Item>
                      )}
                    </div>
                    <div className="px-1 py-1">
                      {props.auth.users ? (
                        <Menu.Item>
                          {({ active }) => (
                            <button
                              className="bg-white hover:bg-blue-600 duration-300 hover:scale-95 text-white group flex rounded-md items-center w-full px-2 py-2 text-sm"
                              onClick={() => {
                                if (props.auth.users) {
                                  localStorage.removeItem("users");
                                  localStorage.removeItem("accessToken");
                                  localStorage.removeItem("role");
                                  window.location.reload();
                                  history.push("/");
                                } else {
                                  setIsOpen(true);
                                }
                              }}
                            >
                              {active ? (
                                <SVGLogin width="24" height="24" color="#FFFFFF" strokeWidth="1.5" className="mr-1" />
                              ) : (
                                <SVGLogin width="24" height="24" color="#000000" strokeWidth="1.5" className="mr-1" />
                              )}
                              {active ? <p className="text-white">ออกจากระบบ</p> : <p className="text-black">ออกจากระบบ</p>}
                            </button>
                          )}
                        </Menu.Item>
                      ) : (
                        <Menu.Item>
                          {({ active }) => (
                            <button
                              className="bg-white hover:bg-blue-600 duration-300 hover:scale-95 text-white group flex rounded-md items-center w-full px-2 py-2 text-sm"
                              onClick={() => setIsOpen(true)}
                            >
                              {active ? (
                                <SVGLogin width="24" height="24" color="#FFFFFF" strokeWidth="1.5" className="mr-1" />
                              ) : (
                                <SVGLogin width="24" height="24" color="#000000" strokeWidth="1.5" className="mr-1" />
                              )}
                              {active ? <p className="text-white">เข้าสู่ระบบ</p> : <p className="text-black">เข้าสู่ระบบ</p>}
                            </button>
                          )}
                        </Menu.Item>
                      )}
                    </div>
                  </Menu.Items>
                </Transition>
              </Menu>
            </div>
          </div>
          <div className="hidden lg:flex lg:items-center w-full">
            <nav className="md:ml-4 md:pl-4 border-l-2 border-gray-200 flex text-base justify-between w-full">
              <div className="flex">
                <p className="menu-bar" onClick={() => history.push("/")}>
                  หน้าหลัก
                </p>
                <p className="menu-bar" onClick={() => history.push("/AboutUs")}>
                  เกี่ยวกับเรา
                </p>
                {(props.auth.role === "3" || props.auth.role === "4" || props.auth.role === "2") && (
                  <p className="menu-bar" onClick={() => history.push("/MainRegister")}>
                    {props.auth.role === "3" ? "ลงทะเบียนแจ้งความประสงค์" : "ประเมินนักศึกษา"}
                  </p>
                )}
                <div
                  className={`${chkReq ? "mr-5 text-white duration-300 hover:scale-105 cursor-pointer flex" : "hidden"}`}
                  onClick={() => {
                    setPassReq(true);
                  }}
                >
                  <p className="text-white">ขอรับรหัสผ่าน</p>
                  <div className="top-0 right-0 w-3 h-3 rounded-full bg-lime-400 animate-ping" />
                  <div className="top-0 right-0 -ml-3  w-3 h-3 rounded-full bg-lime-300" />
                </div>
              </div>
              <div className="flex">
                {props.auth.users && (
                  <Fragment>
                    <div className="menu-log" onClick={() => setOpenUser(users.userId)}>
                      {users.firstName + " " + users.lastName}
                    </div>
                    <div className="border-r-2 mx-2"></div>
                  </Fragment>
                )}
                <div
                  className="flex menu-log"
                  onClick={() => {
                    if (props.auth.users) {
                      localStorage.removeItem("users");
                      localStorage.removeItem("accessToken");
                      localStorage.removeItem("role");
                      window.location.reload();
                      history.push("/");
                    } else {
                      setIsOpen(true);
                    }
                  }}
                >
                  <p className="mr-1">{props.auth.users ? "ออกจากระบบ" : "เข้าสู่ระบบ"}</p>
                  {props.auth.users ? (
                    <SVGLogout width="24" height="24" color="#FFF" strokeWidth="2" className="mr-1" />
                  ) : (
                    <SVGLogin width="24" height="24" color="#FFF" strokeWidth="2" className="mr-1" />
                  )}
                </div>
              </div>
            </nav>
          </div>
        </div>
      </header>
      {props.auth.role === "4" ? <FormMentorModal openUser={openUser} setOpenUser={setOpenUser}/> : <FromUserModal openUser={openUser} setOpenUser={setOpenUser} />}

      <FormPasswordRequest onOpen={setPassReq} open={passReq} />
      <Login onOpen={setIsOpen} open={isOpen} />
    </Fragment>
  );
}

const mapStateToProps = (state) => ({
  auth: state.Authentication,
});

const mapDispatchToProps = (dispatch) => {
  return {
    AUTHEN: (users, accessToken, role) => dispatch(AUTHEN(users, accessToken, role)),
    USERINFO: () => dispatch(USERINFO()),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Header);
