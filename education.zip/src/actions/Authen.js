export function AUTHEN(users, accessToken, role) {
  return { type: "AUTHEN", users, accessToken, role };
}

export function UAUTHEN() {
  return { type: "UAUTHEN" };
}

export function USERINFO() {
  return { type: "USERINFO" };
}
