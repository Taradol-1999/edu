export const semester = [
  { id: "1", semester: "1" },
  { id: "2", semester: "2" },
];
