export const date = [
  { date: new Date().getFullYear() + 543 },
  { date: new Date().getFullYear() + 543 - 1 },
  { date: new Date().getFullYear() + 543 - 2 },
  { date: new Date().getFullYear() + 543 - 3 },
  { date: new Date().getFullYear() + 543 - 4 },
  { date: new Date().getFullYear() + 543 - 5 },
  { date: new Date().getFullYear() + 543 - 6 },
  { date: new Date().getFullYear() + 543 - 7 },
  { date: new Date().getFullYear() + 543 - 8 },
  { date: new Date().getFullYear() + 543 - 9 },
  { date: new Date().getFullYear() + 543 - 10 },
];
