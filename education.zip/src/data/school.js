export const elementary = [
  { id: "1", name: "ป.1 - ป.6" },
  { id: "2", name: "ป.1 - ม.3" },
  { id: "3", name: "ม.1 - ม.3" },
  { id: "4", name: "ม.1 - ม.6" },
];
export const status = [
  { id: "1", name: "รับรอง" },
  { id: "2", name: "ไม่รับรอง" },
];
