var initialState = {
  users: localStorage.getItem("users"),
  accessToken: localStorage.getItem("accessToken"),
  role: localStorage.getItem("role"),
};
export default function Authentication(state = initialState, action) {
  switch (action.type) {
    case "AUTHEN":
      localStorage.setItem("users", action.users);
      localStorage.setItem("accessToken", action.accessToken);
      localStorage.setItem("role", action.role);
      return {
        ...state,
        users: localStorage.getItem("users"),
        accessToken: localStorage.getItem("accessToken"),
        role: localStorage.getItem("role"),
      };
    case "UAUTHEN":
      localStorage.removeItem("users");
      localStorage.removeItem("accessToken");
      localStorage.removeItem("role");
      return {
        ...state,
        users: localStorage.getItem("users"),
        accessToken: localStorage.getItem("accessToken"),
        role: localStorage.getItem("role"),
      };
    case "USERINFO":
      return {
        ...state,
        users: localStorage.getItem("users"),
        accessToken: localStorage.getItem("accessToken"),
        role: localStorage.getItem("role"),
      };
    default:
      return {
        ...state,
        users: localStorage.getItem("users"),
        accessToken: localStorage.getItem("accessToken"),
        role: localStorage.getItem("role"),
      };
  }
}
