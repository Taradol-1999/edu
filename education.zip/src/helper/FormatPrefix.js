export function FormatPrefix(Code) {
  switch (Code) {
    case "1":
      return "นาย";
    case "2":
      return "นาง";
    case "3":
      return "นางสาว";
    default:
      return "";
  }
}
