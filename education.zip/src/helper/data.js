export const pageSize = [
  { id: 10, name: "10" },
  { id: 20, name: "20" },
  { id: 50, name: "50" },
  { id: 100, name: "100" },
  { id: 1000000, name: "ทั้งหมด" },
];
export const typeUser = [
  { id: "1", name: "เจ้าหน้าที่" },
  { id: "2", name: "อาจารย์" },
  { id: "3", name: "นักศึกษา" },
];
export const prefix = [
  { id: "1", name: "นาย" },
  { id: "2", name: "นาง" },
  { id: "3", name: "นางสาว" },
];

