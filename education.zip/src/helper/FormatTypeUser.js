export function FormatTypeUser(Code) {
  switch (Code) {
    case "1":
      return "เจ้าหน้าที่";
    case "2":
      return "อาจารย์";
    case "3":
      return "นักศึกษา";
    default:
      return "";
  }
}
