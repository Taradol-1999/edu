import axios from "axios";

export default axios.create({
  baseURL: "https://tee.kru.ac.th/cs61/61123250113/api_education-kru/api/",
  headers: {
    "Content-Type": "application/json",
    Authorization: `Bearer ${localStorage.getItem("token")}`,
  },
});
