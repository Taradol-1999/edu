import React from "react";

function SVGToggle({ color, strokeWidth, height, width, className, status = "open" }) {
  return (
    <div>
      {status === "open" ? (
        <svg xmlns="http://www.w3.org/2000/svg" className={`icon icon-tabler icon-tabler-toggle-righ ${className}`} width={width} height={height} viewBox="0 0 24 24" strokeWidth={strokeWidth} stroke={color} fill="none" strokeLinecap="round" strokeLinejoin="round">
          <path stroke="none" d="M0 0h24v24H0z" fill="none" />
          <circle cx="16" cy="12" r="2" />
          <rect x="2" y="6" width="20" height="12" rx="6" />
        </svg>
      ) : (
        <svg xmlns="http://www.w3.org/2000/svg" className={`icon icon-tabler icon-tabler-toggle-left ${className}`} width={width} height={height} viewBox="0 0 24 24" strokeWidth={strokeWidth} stroke={color} fill="none" strokeLinecap="round" strokeLinejoin="round">
          <path stroke="none" d="M0 0h24v24H0z" fill="none" />
          <circle cx="8" cy="12" r="2" />
          <rect x="2" y="6" width="20" height="12" rx="6" />
        </svg>
      )}
    </div>
  );
}

export default SVGToggle;
