import React from "react";

function SVGRegister({ color, strokeWidth, height, width, className }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" className={`icon icon-tabler icon-tabler-registered ${className}`} width={width} height={height} viewBox="0 0 24 24" strokeWidth={strokeWidth} stroke={color} fill="none" strokeLinecap="round" strokeLinejoin="round">
      <path stroke="none" d="M0 0h24v24H0z" fill="none" />
      <circle cx="12" cy="12" r="9" />
      <path d="M9 16v-8h4a2 2 0 0 1 0 4h-4m3 0l3 4" />
    </svg>
  );
}

export default SVGRegister;
