import React, { Fragment } from "react";
import { connect } from "react-redux";
import { useHistory } from "react-router-dom";

function NotFound(data) {
  const history = useHistory();

  function redirect() {
    if (data.auth.users) {
      if (data.auth.role === "1") {
        history.push("/");
      } else if (data.auth.role === "2") {
        history.push("/");
      }
      if (data.auth.role === "3") {
        history.push("/MainRegister");
      }
    } else {
      history.push("/");
    }
  }
  return <Fragment>{redirect()}</Fragment>;
}

const mapStateToProps = (state) => ({
  data: state.Authentication,
});

export default connect(mapStateToProps)(NotFound);
