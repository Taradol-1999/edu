import React, { Fragment, useEffect, useState } from "react";
import CommentInput from "../../../components/CommentInput";
import Pagination from "../../../components/Pagination";
import { ReviewSchool } from "../../../services/SchoolReview.services";
import SVGMessage from "../../../SVGS/SVGMessage";
import SVGSearch from "../../../SVGS/SVGSearch";
import SVGUser from "../../../SVGS/SVGUser";
import { LazyLoadImage } from "react-lazy-load-image-component";
import SVGClose from "../../../SVGS/SVGClose";
import DateTH from "../../../components/Date/DateTH";
import { LoadSchool, LoadSchoolReview } from "../../../services/School.services";
import CardLoadingV2 from "../../../components/loading/CardLoadingV2";
import useWindowDimensions from "../../../components/WindowSize";
import { NotDataImg } from "../../../components/NotData";

const MainSchool = () => {
  let users = JSON.parse(localStorage.getItem("users"));
  const [school, setSchool] = useState([]);
  const { width } = useWindowDimensions();
  const [pagin, setPagin] = useState({ currentPage: 1, pageSize: 15, totalRows: 0, totalPages: 0 });
  const [isOpen, setIsOpen] = useState("");
  const [values, setValues] = useState("");
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(false);
  const [review, setReview] = useState([]);

  useEffect(() => {
    loadDataSchool();
  }, []);

  async function loadDataSchool(currentPage = 1, pageSize = 15, search = "") {
    setLoading(true);
    setSearch(search);
    let res = await LoadSchool(currentPage, pageSize, search);
    if (res)
      if (res.taskStatus && res.statusCode === 200) {
        setPagin(res.pagin);
        setSchool(res.data);
      }
    setTimeout(() => {
      setLoading(false);
    }, 500);
  }
  async function loadDataSchoolReview(id) {
    let res = await LoadSchoolReview(id);
    if (res)
      if (res.taskStatus && res.statusCode === 200) {
        setReview(res.data);
      }
  }

  async function SaveReview(data) {
    let res = await ReviewSchool(data);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        loadDataSchoolReview(data.schoolId);
        setValues("");
        updateState(data.schoolId);
      }
    }
  }

  const updateState = (scId) => {
    const newState = school.map((obj) => {
      if (obj.schoolId === scId) {
        return { ...obj, countReview: obj.countReview + 1 };
      }
      return obj;
    });
    setSchool(newState);
  };

  return (
    <Fragment>
      <div className="px-5 py-5">
        <div className="border-blue-400 border-b-[3px] hover:border-sky-300 duration-300 flex my-5 w-full">
          <h1 className="text-[26px] font-bold whitespace-nowrap">รายชื่อโรงเรียนสำหรับฝึกประสบการณ์วิชาชีพครู</h1>
          <div className="relative h-9 px-2 mt-1">
            <input
              id="search"
              value={search}
              className={`h-9 outline-none bg-transparent text-[22px] pr-[3rem] placeholder-gray-500 duration-1000 focus:w-[12rem] focus:md:w-[40rem] w-0 ${search && "md:w-[30rem] w-[15rem]"}`}
              placeholder="ค้นหา..."
              onChange={(e) => {
                loadDataSchool(pagin.currentPage, pagin.pageSize, e.target.value);
              }}
            />
            <span className="absolute -ml-10 cursor-pointer" onClick={() => document.getElementById("search").focus()}>
              <SVGSearch width="28" height="32" color="#9e9eab" strokeWidth="2" className="" classNameout="px-2 border-l-2 border-gray-500" />
            </span>
          </div>
        </div>
        <div className={`${school.length === 0 ? "w-full" : "grid xl:grid-cols-3 md:grid-cols-2 grid-cols-1 gap-5"}`}>
          {loading ? (
            <CardLoadingV2 length={width > 1280 ? 3 : width > 1024 ? 2 : 1} />
          ) : school.length === 0 ? (
            <div className="flex justify-center">
              <NotDataImg />
            </div>
          ) : (
            school.map((value, index) => (
              <div className="w-full mx-auto z-10" key={index}>
                <div className="flex flex-col relative">
                  <div className="bg-white border border-white shadow-lg rounded-xl p-4 z-10 flex-none flex">
                    <div className="relative h-32 w-32 sm:mb-0 mb-3">
                      <LazyLoadImage className=" w-32 h-32 object-contain rounded-2xl" alt={value.schoolName} src={value.logoSchool} effect="blur" />
                    </div>
                    <div className="flex-auto sm:ml-5 justify-evenly">
                      <div className="flex items-center justify-between sm:mt-2">
                        <div className="flex items-center">
                          <div className="flex flex-col">
                            <div className="w-full flex-none text-lg text-gray-800 font-bold leading-none">โรงเรียน{value.schoolName}</div>
                            <div className="flex-auto text-gray-500 my-2">
                              <span className="mr-3 ">เปิดสอนระดับ {value.elementaryLevel}</span>
                              <span className="mr-3 border-r border-gray-200  max-h-0" />
                              <span>โทร {value.phone ?? "-"}</span>
                            </div>
                            {/* <div className="w-full flex-none text-sm text-gray-600">{value.address ?? "-"}</div> */}
                          </div>
                        </div>
                      </div>
                      <div className="flex h-[1px] rounded-full bg-gray-300 w-full my-2" />
                      <div className="flex pt-2  text-sm text-gray-500">
                        <div className="flex-1 inline-flex items-center">
                          <SVGUser className="h-10 w-10 mr-2" color="currentColor" />
                          <p className="">
                            <span>{value.countRegis}</span> คน <br /> (จำนวนผู้ออกฝึก)
                          </p>
                        </div>
                        <div
                          className="flex-1 inline-flex items-center cursor-pointer"
                          onClick={() => {
                            if (value.schoolId === isOpen) {
                              setIsOpen("");
                            } else {
                              setIsOpen(value.schoolId);
                              loadDataSchoolReview(value.schoolId);
                            }
                          }}
                        >
                          <SVGMessage className="h-10 w-10 mr-2" color="currentColor" />
                          <p>{value.countReview === 0 ? "ไม่มี" : `${value.countReview} `}ความคิดเห็น</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className={`${value.schoolId === isOpen ? `h-full z-50 flex items-end duration-500` : `hidden z-0`} w-full rounded-3xl absolute `}>
                    <div className="w-full border-[3px] border-gray-300 shadow-2xl rounded-2xl">
                      <div className="flex justify-between px-2 bg-white rounded-t-xl border-b-2 border-gray-300 py-2">
                        <p className="text-lg ">
                          <i className="far fa-comment-dots px-2" />
                          รายการความคิดเห็น
                        </p>
                        <SVGClose
                          width="25"
                          height="25"
                          color="#6C6C6C"
                          strokeWidth="3"
                          className="bg-gray-200 hover:bg-gray-300 rounded-full p-1 cursor-pointer duration-100"
                          onClick={() => {
                            loadDataSchoolReview(value.schoolId);
                            setIsOpen("");
                          }}
                        />
                      </div>
                      <div className={`${value.schoolId === isOpen ? "h-[20rem]" : "h-0"} bg-gray-100 p-2 overflow-y-auto  shadow-md`}>
                        {review.length === 0 ? (
                          <div className="flex justify-center items-center h-full">
                            <p className="text-center py-2 text-gray-300 ">
                              <i className="fas fa-comment-slash text-[32px] mt-4" />
                              <br />
                              ไม่มีรายการความคิดเห็น
                            </p>
                          </div>
                        ) : (
                          review.map((item, index) => (
                            <div className={`${item.color === "3" ? "bg-sky-100" : "bg-green-100"}  rounded-md p-2 mb-2 w-full`} key={index}>
                              <p className="w-full font-bold text-[18px]">
                                <span>{item.fullName}</span> <span className="italic text-green-700 text-xs mr-1">{item.color !== "3" && "(อาจารย์) "} </span> :
                                <span className="text-xs text-gray-500 italic w-full font-light text-[12px] pl-1 ">
                                  <DateTH date={item.dateReview} type="datetime" />
                                </span>
                              </p>
                              <p className="font-light">{item.detail}</p>
                            </div>
                          ))
                        )}
                      </div>

                      {users && (
                        <CommentInput
                          onSubmit={() => {
                            if (users) {
                              let data = {
                                schoolId: value.schoolId,
                                userId: users.userId,
                                detail: values,
                              };
                              SaveReview(data);
                            }
                          }}
                          name={value.schoolId}
                          value={values}
                          onChange={(e) => setValues(e.target.value)}
                        />
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
        <div className="py-5">
          <Pagination
            totalPage={pagin.pageCount}
            onChange={async (page) => {
              loadDataSchool(page);
            }}
            currentPages={pagin.currentPage}
            totalRow={pagin.rowCount}
          />
        </div>
      </div>
    </Fragment>
  );
};

export default MainSchool;
