import React, { Fragment, useEffect, useState } from "react";
import { LoadSchool } from "../../services/School.services";
import MainNews from "./news/MainNews";
import MainSchool from "./school/MainSchool";
export default function HomePage() {
  const [school, setSchool] = useState([]);
  const [pagin, setPagin] = useState({
    currentPage: 1,
    pageSize: 15,
    totalRows: 0,
    totalPages: 0,
  });
  useEffect(() => {
    loadDataSchool();
  }, []);

  async function loadDataSchool(currentPage = 1, pageSize = 15, search = "") {
    let result = await LoadSchool(currentPage, pageSize, search);
    if (result) {
      setPagin(result.pagin);
      setSchool(result.data);
    }
  }
  return (
    <Fragment>
      <div className="w-full">
        <MainNews />
        <MainSchool
          school={school}
          pagin={pagin}
          refreshSchool={loadDataSchool}
          returnloadDataSchool={(e) => {
            loadDataSchool(e, 15, "");
          }}
          returnsearch={(e) => {
            loadDataSchool(1, 15, e);
          }}
        />
      </div>
    </Fragment>
  );
}
