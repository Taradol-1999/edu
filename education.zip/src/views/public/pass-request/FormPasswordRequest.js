import React, { useState, useEffect } from "react";
import { Form, Formik } from "formik";
import { TextField } from "../../../components/TextField";
import { TextSelect } from "../../../components/TextSelect";
import { GetDropdown } from "../../../services/Dropdown.services";
import SVGLoading from "../../../SVGS/SVGLoading";
import SVGSave from "../../../SVGS/SVGSave";
import SVGReset from "../../../SVGS/SVGReset";
import { MESSAGEERROR, MESSAGESUCCESS } from "../../../components/alert";
import { SaveUser } from "../../../services/User.services";
import { validate } from "./validate";
import Modal from "../../../components/Modal";
import { TextFieldPassword } from "../../../components/TextFieldPassword";

export default function FormPasswordRequest({ open, onOpen }) {
  const [loading, setLoading] = useState(false);
  const [major, setMajor] = useState([]);
  const [faculty, setFaculty] = useState([]);
  const [title, setPrefix] = useState([]);

  useEffect(() => {
    loadDropdown();
  }, []);

  async function loadDropdown() {
    let res = await GetDropdown();
    setMajor(res.majors);
    setFaculty(res.faculty);
    setPrefix(res.title);
  }

  const SAVE = async (values) => {
    setLoading(true);
    let res = await SaveUser(values);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        MESSAGESUCCESS(res.message);
        onOpen(false);
      } else {
        MESSAGEERROR(res.message);
      }
    }
    setLoading(false);
  };
  return (
    <Modal
      width="max-w-lg"
      isOpen={open}
      title="ขอรับรหัสผ่าน"
      onClose={() => {
        onOpen(false);
      }}
    >
      <Formik
        initialValues={{
          preFix: "",
          firstName: "",
          lastName: "",
          phone: "",
          userName: "",
          passWord: "",
          facultyId: "",
          majorId: "",
          role: "3",
        }}
        validationSchema={validate}
        enableReinitialize={true}
        onSubmit={async (values) => {
          SAVE(values);
        }}
      >
        {({ values, setFieldValue }) => (
          <Form>
            <div className=" rounded-md px-6 py-5 max-w-2xl mx-auto">
              <div className="space-y-4">
                <div className="flex flex-wrap">
                  <div className="w-full">
                    <TextSelect
                      title="คำนำหน้าชื่อ"
                      options={title}
                      name="preFix"
                      value={title.filter((x) => x.titleId === values.preFix)}
                      placeholder="คำนำหน้าชื่อ"
                      getOptionLabel={(x) => x.titleName}
                      getOptionValue={(x) => x.titleId}
                      onChange={(e) => {
                        setFieldValue("preFix", e.titleId);
                      }}
                    />
                  </div>
                  <div className="w-full">
                    <TextField
                      name="firstName"
                      value={values.firstName}
                      title="ชื่อ"
                      placeholder="ชื่อ"
                      onChange={(e) => {
                        setFieldValue("firstName", e.target.value);
                      }}
                      type="text"
                    />
                  </div>
                  <div className="w-full">
                    <TextField
                      name="lastName"
                      value={values.lastName}
                      title="นามสกุล"
                      placeholder="นามสกุล"
                      onChange={(e) => {
                        setFieldValue("lastName", e.target.value);
                      }}
                      type="text"
                    />
                  </div>
                  <div className="w-full">
                    <TextField
                      name="phone"
                      value={values.phone}
                      title="เบอร์โทรศัพท์มือถือ"
                      placeholder="เบอร์โทรศัพท์มือถือ"
                      onChange={(e) => {
                        setFieldValue("phone", e.target.value);
                      }}
                      type="text"
                    />
                  </div>
                  <div className="w-full">
                    <TextSelect
                      title="คณะ"
                      options={faculty}
                      name="facultyId"
                      value={faculty.filter((x) => x.facultyId === values.facultyId)}
                      placeholder="คณะ"
                      getOptionLabel={(x) => x.facultyName}
                      getOptionValue={(x) => x.facultyId}
                      onChange={(e) => {
                        setFieldValue("facultyId", e.facultyId);
                        setFieldValue("majorId", "");
                      }}
                    />
                  </div>
                  <div className="w-full">
                    <TextSelect
                      options={major.filter((x) => x.facultyId === values.facultyId)}
                      name="majorId"
                      title="สาขา"
                      value={major.filter((x) => x.majorId === values.majorId)}
                      placeholder="สาขา"
                      getOptionLabel={(x) => x.majorName}
                      getOptionValue={(x) => x.majorId}
                      onChange={(e) => {
                        setFieldValue("majorId", e.majorId);
                      }}
                    />
                  </div>
                  <div className="w-full">
                    <TextField
                      name="userName"
                      value={values.userName}
                      title="รหัสนักศึกษา"
                      placeholder="รหัสนักศึกษา"
                      onChange={(e) => {
                        setFieldValue("userName", e.target.value);
                      }}
                      type="text"
                    />
                  </div>
                  <div className="w-full">
                    <TextFieldPassword
                      name="passWord"
                      value={values.passWord}
                      title="รหัสผ่าน"
                      placeholder="รหัสผ่าน"
                      onChange={(e) => {
                        setFieldValue("passWord", e.target.value);
                      }}
                      type="text"
                    />
                  </div>
                </div>
                <div className="flex gap-3 justify-center my-5">
                  <button className={loading ? "buttonSave cursor-no-drop" : "buttonSave"} type="submit" disabled={loading}>
                    {loading ? (
                      <div className="flex items-center justify-center text-center">
                        <SVGLoading width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" />
                        บันทึก
                      </div>
                    ) : (
                      <div className="flex items-center justify-center text-center">
                        <SVGSave width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> บันทึก
                      </div>
                    )}
                  </button>
                  <button className="buttonResetV1" type="reset">
                    <SVGReset width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> ล้างค่า
                  </button>
                </div>
              </div>
            </div>
          </Form>
        )}
      </Formik>
    </Modal>
  );
}
