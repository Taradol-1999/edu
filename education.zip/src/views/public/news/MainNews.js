import React, { Fragment, useEffect } from "react";
import { useHistory } from "react-router-dom";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination, Navigation } from "swiper";
import ListNews from "./ListNews";
import { useState } from "react";
import { LoadNews } from "../../../services/Activity.services";

const MainNews = () => {
  let history = useHistory();
  const [news, setNews] = useState([]);
  const [searchNews, setSearchNews] = useState("");
  const [loadingNews, setLoadingNews] = useState(false);
  const [newsShow, setNewsShow] = useState([]);

  useEffect(() => {
    LoadDataNews();
  }, []);

  async function LoadDataNews() {
    let res = await LoadNews("", "1");
    if (res) {
      setNews(res.data);
    }
  }

  useEffect(() => {
    LoadDataNewsShow(searchNews);
  }, [searchNews]);

  async function LoadDataNewsShow(search = "") {
    setLoadingNews(true);
    let res = await LoadNews(search, "");
    if (res) {
      setNewsShow(res.data);
    }
    setTimeout(() => {
      setLoadingNews(false);
    }, 500);
  }

  return (
    <Fragment>
      <Swiper
        spaceBetween={30}
        loop={false}
        pagination={{
          clickable: true,
          dynamicBullets: true,
        }}
        autoplay={{
          stopOnLastSlide: false,
          delay: 5500,
          disableOnInteraction: false,
        }}
        loopFillGroupWithBlank={news.length > 1}
        navigation={true}
        modules={[Pagination, Navigation, Autoplay]}
        className="mySwiper"
      >
        {news.map((item, inx) => (
          <SwiperSlide key={inx}>
            <div
              className="relative lg:h-[60rem] md:h-[40rem] h-[20rem] w-full flex items-end justify-start text-left bg-cover bg-center "
              style={{
                backgroundImage: `url(${item.imageUrl[0]})`,
              }}
            >
              <div className="absolute top-0 mt-20 right-0 bottom-0 left-0 bg-gradient-to-b from-transparent to-gray-900" />
              <div className="absolute top-0 right-0 left-0 mx-5 mt-2 flex justify-between items-center">
                <p className="text-xs bg-blue-500 text-white px-5 py-2 uppercase hover:bg-white hover:text-blue-500 transition ease-in-out duration-500">
                  {item.activityType === "1" ? "กิจกรรม" : "ข่าว"}
                </p>
                <div className="text-black font-regular flex flex-col justify-center text-center ">
                  <span className="text-3xl leading-0 font-semibold">{item.publishDay}</span>
                  <span className="-mt-2">{item.publishMonth}</span>
                </div>
              </div>
              <main className="p-5 z-10 group">
                <p
                  onClick={() => {
                    history.push("/DetailNews?id=" + item.activityId, newsShow);
                  }}
                  className="cursor-pointer text-xl font-bold tracking-tight  leading-7 font-regular text-white group-hover:underline"
                >
                  {item.activityTitle}
                </p>
                <p
                  onClick={() => {
                    history.push("/DetailNews?id=" + item.activityId, newsShow);
                  }}
                  className="cursor-pointer text-md tracking-tight font-medium leading-7 font-regular text-white group-hover:underline line-clamp-2"
                  dangerouslySetInnerHTML={{ __html: item.activityDetail ? item.activityDetail.replace(/<img.*?>/g, "") : "" }}
                />
              </main>
            </div>
          </SwiperSlide>
        ))}
      </Swiper>
      <ListNews
        data={newsShow}
        loading={loadingNews}
        searchNews={(e) => {
          setSearchNews(e);
        }}
        search={searchNews}
      />
    </Fragment>
  );
};

export default MainNews;
