import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { FreeMode, Pagination, Autoplay } from "swiper";
import SVGSearch from "../../../SVGS/SVGSearch";
import { useHistory } from "react-router-dom";
import CardLoading from "../../../components/loading/CardLoading";
import useWindowDimensions from "../../../components/WindowSize";
import { NotDataImg } from "../../../components/NotData";

export default function ListNews({ data, loading, searchNews, search }) {
  let history = useHistory();
  const { width } = useWindowDimensions();

  return (
    <div className="px-5 py-10">
      <div className="flex justify-center">
        <div className="border-blue-400 border-b-[3px] hover:border-sky-300 duration-300 flex my-5 w-full">
          <h1 className="text-[26px] font-bold whitespace-nowrap">ข่าวประชาสัมพันธ์</h1>
          <div className="relative  h-9 px-2 mt-1">
            <input
              id="searchNews"
              value={search}
              className={`h-9 outline-none bg-transparent text-[22px] pr-[3rem] placeholder-gray-500 duration-1000 focus:w-[12rem] focus:md:w-[40rem] w-0 ${search && "md:w-[30rem] w-[15rem]"}`}
              placeholder="ค้นหา..."
              onChange={(e) => {
                searchNews(e.target.value);
              }}
            />
            <span className="absolute -ml-10 cursor-pointer" onClick={() => document.getElementById("searchNews").focus()}>
              <SVGSearch width="28" height="32" color="#9e9eab" strokeWidth="2" className="" classNameout="px-2 border-l-2 border-gray-500" />
            </span>
          </div>
        </div>
      </div>
      {loading ? (
        <div className="grid xl:grid-cols-3 lg:grid-cols-2 grid-cols-1 gap-4">
          <CardLoading length={width > 1280 ? 3 : width > 1024 ? 2 : 1} />
        </div>
      ) : data.length === 0 ? (
        <div className="flex justify-center">
          <NotDataImg />
        </div>
      ) : (
        <Swiper
          freeMode={true}
          pagination={{
            clickable: true,
            dynamicBullets: true,
          }}
          modules={[FreeMode, Pagination, Autoplay]}
          autoplay={{ delay: 3500 }}
          breakpoints={{
            1280: {
              slidesPerView: 3,
              spaceBetween: 10,
              slidesPerGroup: 3,
            },
            1024: {
              slidesPerView: 2,
              spaceBetween: 10,
              slidesPerGroup: 2,
            },
            768: {
              slidesPerView: 1,
              spaceBetween: 10,
              slidesPerGroup: 1,
            },
            0: {
              slidesPerView: 1,
              spaceBetween: 10,
              slidesPerGroup: 1,
            },
          }}
        >
          {data.map((item, index) => (
            <SwiperSlide key={index}>
              <div
                onClick={() => {
                  history.push("/DetailNews?id=" + item.activityId, data);
                }}
                className="relative flex flex-col justify-center rounded-xl  bg-white bg-clip-border shadow-3xl shadow-shadow-500 p-4 group cursor-pointer"
              >
                <div className="relative w-full">
                  <div className="flex justify-center">
                    <img effect="blur" src={item.imageUrl[0]} className="mb-3 h-[17rem] w-full rounded-xl shadow-sm object-cover" alt="" />
                  </div>
                  <p className="absolute top-3 right-3 flex items-center justify-center rounded-full text-white group-hover:text-white duration-500 bg-red-500 group-hover:bg-blue-600 p-2 text-brand-500 hover:cursor-pointer">
                    {item.activityType === "1" ? "กิจกรรม" : "ข่าว"}
                  </p>
                </div>
                <div className="px-1 h-[5rem]">
                  <p className="text-lg font-bold line-clamp-2  group-hover:scale-[1.02] text-black duration-500"> {item.activityTitle}</p>
                  <p className="mt-1 text-sm font-medium text-gray-600 md:mt-2 text-right">{item.publishDateTH} </p>
                </div>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      )}
    </div>
  );
}
