/* eslint-disable react-hooks/exhaustive-deps */
import React, { Fragment, useEffect, useState } from "react";
import { useHistory } from "react-router-dom";
import { DetailActivity, LoadNews } from "../../../services/Activity.services";
import SVGClip from "../../../SVGS/SVGClip";
import ViewerImg from "../../../components/swiper/ViewerImg";
import { LazyLoadImage } from "react-lazy-load-image-component";
import { Swiper, SwiperSlide } from "swiper/react";
import { FreeMode, Pagination, Autoplay } from "swiper";
import BtnGoBack from "../../../components/BtnGoBack";

export default function DetailNews() {
  const [detail, setDetail] = useState({});
  const [news, setNews] = useState([]);
  let history = useHistory();
  let id = new URLSearchParams(history.location.search).get("id");
  const [show, setShow] = useState(false);
  const [currImg, setCurrImg] = useState(0);

  useEffect(() => {
    if (id) {
      loadDetail(id);
    }
  }, [id]);

  const scrollTop = (idToTop) => {
    document.getElementById(idToTop).scrollIntoView({ top: 0, behavior: "smooth" });
  };

  async function loadDetail(id) {
    let res = await DetailActivity(id);
    if (res) {
      setDetail(res.data);
      scrollTop(res.data.activityId);
    }
  }

  var url = id ? (detail.documentUrl ? detail.documentUrl : []) : [];
  var Original = id ? (detail.docOriginal ? detail.docOriginal : []) : [];
  const newImg = detail.imageUrl
    ? detail.imageUrl.map((i) => ({
        src: i,
      }))
    : [];

  function mergeArrayObjects(arr1, arr2) {
    return arr1.map((item, i) => {
      if (item.id === arr2[i].id) return Object.assign({}, item, arr2[i]);
    });
  }

  useEffect(() => {
    LoadDataNewsShow();
  }, []);

  async function LoadDataNewsShow() {
    let res = await LoadNews("", "");
    if (res) {
      setNews(res.data);
    }
  }

  return (
    <Fragment>
      <div className="flex flex-wrap justify-end mx-auto p-5">
        <div id={detail.activityId}></div>
        <BtnGoBack onClick={() => history.goBack()} />
      </div>
      <ViewerImg
        img={newImg}
        show={show}
        currImg={currImg}
        onClickPrev={(e) => setCurrImg(currImg - 1)}
        onClickNext={(e) => setCurrImg(currImg + 1)}
        onClickThumbnail={(index) => setCurrImg(index)}
        onClose={() => {
          setShow(false);
        }}
      />
      <div>
        <div className="px-10 py-16 w-full">
          <div className="flex flex-col text-center w-full mb-5">
            <h1 className="md:text-xl text-5xl font-medium title-font mb-4 text-gray-900">{detail.activityTitle}</h1>
            <p className={detail.startDateTH && detail.endDateTH ? "text-base" : "hidden"}>{detail.startDateTH && "วันที่เริ่ม " + detail.startDateTH + " - วันสิ้นสุด " + detail.endDateTH}</p>
          </div>
          <div className={`flex justify-center w-full`}>
            <div className={`flex flex-wrap justify-center  ${detail.documentUrl ? "w-4/6" : "w-full"}`}>
              {detail.imageUrl
                ? detail?.imageUrl.map((item, index) => (
                    <div
                      key={index}
                      onClick={() => {
                        setShow(true);
                        setCurrImg(index);
                      }}
                      className="overflow-hidden aspect-video h-[15rem] cursor-pointer rounded-xl relative group m-2"
                    >
                      <div className="rounded-xl z-50 opacity-0 group-hover:opacity-100 transition duration-300 ease-in-out cursor-pointer absolute from-black/80 to-transparent bg-gradient-to-t inset-x-0  h-full text-white flex items-center justify-center">
                        <i className="fa-solid fa-eye text-3xl " />
                      </div>
                      <img alt="" className="object-cover w-full aspect-square group-hover:scale-110 transition duration-300 ease-in-out" src={item} />
                    </div>
                  ))
                : ""}
            </div>
            <div className={detail.documentUrl ? "w-2/6" : "hidden"}>
              <h2 className="text-sm title-font text-gray-500 tracking-widest">เอกสารที่เกี่ยวข้อง</h2>
              {detail.documentUrl
                ? mergeArrayObjects(url, Original).map((item, index) => (
                    <a
                      key={index}
                      href={item.docUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex bg-white hover:bg-gray-100 border-2 border-gray-300 hover:border-gray-300 rounded-md mt-1 py-2 px-2 text-sm cursor-pointer"
                    >
                      <SVGClip width="24" height="24" color="#9ca3af" strokeWidth="2" className="mr-2" />
                      <p>{item.nameOri}</p>
                    </a>
                  ))
                : ""}
            </div>
          </div>

          <div className="flex flex-wrap mt-10">
            <div className="flex items-end">
              <p className="text-base">{"เผยแพร่ " + detail.publishDateTH}</p>
              <p className="text-sm text-red-700 ml-2">{detail.activityType === "1" ? "(กิจกรรม)" : "(ข่าว)"}</p>
            </div>
            <h1 className="text-gray-900 text-3xl title-font font-medium mb-4 w-full">{detail.activityTitle}</h1>
            <p dangerouslySetInnerHTML={{ __html: detail.activityDetail }} />
          </div>
          {news.length > 1 ? (
            <Fragment>
              <p className="text-xl text-gray-800 space-x-4 mt-10">ข่าว/กิจกรรมเพิ่มเติม</p>
              <Swiper
                freeMode={true}
                pagination={{
                  clickable: true,
                  dynamicBullets: true,
                }}
                modules={[FreeMode, Pagination, Autoplay]}
                autoplay={{ delay: 3500 }}
                breakpoints={{
                  1280: {
                    slidesPerView: 3,
                    spaceBetween: 10,
                    slidesPerGroup: 3,
                  },
                  1024: {
                    slidesPerView: 2,
                    spaceBetween: 10,
                    slidesPerGroup: 2,
                  },
                  768: {
                    slidesPerView: 1,
                    spaceBetween: 10,
                    slidesPerGroup: 1,
                  },
                  0: {
                    slidesPerView: 1,
                    spaceBetween: 10,
                    slidesPerGroup: 1,
                  },
                }}
              >
                {news
                  .filter((x) => x.activityId !== parseInt(id))
                  .map((item, index) => (
                    <SwiperSlide key={index}>
                      <div
                        onClick={() => {
                          history.push("/DetailNews?id=" + item.activityId, history.location.state);
                        }}
                        className="relative flex flex-col justify-center rounded-xl  bg-white bg-clip-border shadow-3xl shadow-shadow-500 p-4 group cursor-pointer"
                      >
                        <div className="relative w-full">
                          <div className="flex justify-center">
                            <LazyLoadImage src={item.imageUrl[0]} className="mb-3 h-[17rem] w-full rounded-xl shadow-sm object-cover" alt="" />
                          </div>
                          <p className="absolute top-3 right-3 flex items-center justify-center rounded-full text-black group-hover:text-white  duration-500 bg-white group-hover:bg-blue-600 p-2 text-brand-500 hover:cursor-pointer">
                            {item.activityType === "1" ? "กิจกรรม" : "ข่าว"}
                          </p>
                        </div>
                        <div className="px-1 h-[5rem]">
                          <p className="text-lg font-bold line-clamp-2  group-hover:scale-[1.02] text-black duration-500"> {item.activityTitle}</p>
                          <p className="mt-1 text-sm font-medium text-gray-600 md:mt-2 text-right">{item.publishDateTH} </p>
                        </div>
                      </div>
                    </SwiperSlide>
                  ))}
              </Swiper>
            </Fragment>
          ) : null}
        </div>
      </div>
    </Fragment>
  );
}
