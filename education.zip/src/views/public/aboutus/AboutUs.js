/* eslint-disable jsx-a11y/iframe-has-title */
import React, { Fragment, useState } from "react";
import LOGOKRU from "../../../assets/img/LOGO-KRU.png";
import map from "../../../assets/img/aboutUs/mapedu.png";
import ViewerImg from "../../../components/swiper/ViewerImg";
export default function AboutUs() {
  const [show, setShow] = useState(false);

  return (
    <Fragment>
      <div className="py-8 bg-white shadow lg:mt-36 mt-28 mb-6 w-full">
        <div className="grid grid-cols-1 md:grid-cols-3">
          <div className="grid grid-cols-3 text-center order-last md:order-first mt-20 md:hidden">
            <div>{/* <p className="font-bold text-gray-700 text-xl">22</p> <p className="text-gray-400">Friends</p> */}</div>
            <div>{/* <p className="font-bold text-gray-700 text-xl">10</p> <p className="text-gray-400">Photos</p> */}</div>
            <div>{/* <p className="font-bold text-gray-700 text-xl">89</p> <p className="text-gray-400">Comments</p> */}</div>
          </div>
          <div className="w-48 h-48 mx-auto  inset-x-0 top-0 -mt-32 flex items-center justify-center">
            <img src={LOGOKRU} alt={LOGOKRU} />
          </div>
        </div>
        <div className="mt-10 text-center border-b pb-12">
          <h1 className="text-4xl font-medium text-gray-700">มหาวิทยาลัยราชภัฏกาญจนบุรี</h1>
          <p className="font-light text-gray-600 mt-3">คณะครุศาสตร์, Faculty of Education</p>
          <p className="mt-8 text-gray-500">ฝ่ายฝึกประสบการณ์วิชาชีพครู</p>
        </div>
        <div className="mt-5 grid lg:grid-cols-5  gap-4 px-2">
          <div className="lg:col-span-3">
            <div className="flex flex-col text-center w-full mb-5">
              <h1 className="sm:text-4xl text-3xl font-medium title-font mb-2 text-gray-900">Google Maps</h1>
              <a
                className="mx-auto leading-relaxed text-base w-fit hover:text-blue-900 hover:underline px-2 rounded-md"
                href="https://goo.gl/maps/tQ7CUzP2XaxDtDgU7"
                target="_blank"
                rel="noopener noreferrer"
              >
                3C6G+R27 ตำบล หนองบัว อำเภอเมืองกาญจนบุรี กาญจนบุรี 71190
              </a>
            </div>
            <img src={map} className="duration-500 cursor-pointer" alt="แผนที่คณะครุศาสตร์ มหาวิทยาลัยราชภัฏกาญจนบุรี" onClick={() => setShow(true)} />

            <ViewerImg
              img={[{ src: map }]}
              show={show}
              onClose={() => {
                setShow(false);
              }}
            />
          </div>
          <div className="lg:col-span-2  pl-10">
            <div className="flex flex-col w-full mb-5">
              <h1 className="sm:text-4xl text-3xl font-medium title-font mb-2 text-gray-900 underline decoration-blue-700">เวลาทำการ</h1>
              <p className="lg:w-2/3 mx-auto leading-relaxed text-base w-full">
                เปิดทำการทุกวันจันทร์ - วันศุกร์ เวลา 08:30 - 16:30 <span className="text-red-500 text-sm">(ยกเว้น วันหยุดราชการ)</span>
              </p>
            </div>
            <div className="flex flex-col w-full mb-5">
              <h1 className="sm:text-4xl text-3xl font-medium title-font mb-2 text-gray-900 underline decoration-blue-700">ติดต่อเรา</h1>
              <p className="lg:w-2/3 mx-auto leading-relaxed text-base w-full">โทรศัพท์ : 034-534071</p>
              <p className="lg:w-2/3 mx-auto leading-relaxed text-base w-full">โทรสาร : 034-534071</p>
              <p className="lg:w-2/3 mx-auto leading-relaxed text-base w-full">เว็บไซต์ : http://ed.kru.ac.th</p>
              <p className="lg:w-2/3 mx-auto leading-relaxed text-base w-full">ที่ตั้ง : มหาวิทยาลัยราชภัฏกาญจนบุรี</p>
            </div>
            <div className="flex flex-col w-full mb-5">
              <h1 className="sm:text-4xl text-3xl font-medium title-font mb-2 text-gray-900 underline decoration-blue-700">โซเชียลมีเดีย</h1>
              <p className="lg:w-2/3 mx-auto leading-relaxed text-base w-full">เฟสบุค : ฝ่ายฝึกประสบการณ์วิชาชีพครู</p>
              <p className="lg:w-2/3 mx-auto leading-relaxed text-base w-full">เว็บไซต์ : ed.kru.ac.th</p>
            </div>
          </div>
        </div>
      </div>
    </Fragment>
  );
}
