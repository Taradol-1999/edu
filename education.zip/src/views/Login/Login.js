import React, { useState } from "react";
import SVGLock from "../../SVGS/SVGLock";
import SVGTeacher from "../../SVGS/SVGTeacher";
import SVGUser from "../../SVGS/SVGUser";
import SVGEye from "../../SVGS/SVGEye";
import { useHistory } from "react-router-dom";
import SVGLoading from "../../SVGS/SVGLoading";
import { Formik, Form } from "formik";
import { LOGINSUCCESS } from "../../components/alert";
import { Authen } from "../../services/Authen.Services";
import Swal from "sweetalert2";
import { connect } from "react-redux";
import Instance from "../../helper/axios";
import { AUTHEN, USERINFO } from "../../actions/Authen";
import Modal from "../../components/Modal";

function Login(auth) {
  const [loading, setLoading] = useState(false);
  const checkData = JSON.parse(localStorage.getItem("remember"));
  const name = localStorage.getItem("name");
  const pass = localStorage.getItem("pass");
  let history = useHistory();
  function showPass() {
    var x = document.getElementById("input-pass");
    if (x.type === "password") {
      x.type = "text";
      document.getElementById("show-Icon").innerHTML =
        '<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-eye-off" width="28" height="28" viewBox="0 0 24 24" stroke-width="1.5" stroke="#2563eb" fill="none" stroke-linecap="round" stroke-linejoin="round"> <path stroke="none" d="M0 0h24v24H0z" fill="none"/> <line x1="3" y1="3" x2="21" y2="21" /> <path d="M10.584 10.587a2 2 0 0 0 2.828 2.83" /> <path d="M9.363 5.365a9.466 9.466 0 0 1 2.637 -.365c4 0 7.333 2.333 10 7c-.778 1.361 -1.612 2.524 -2.503 3.488m-2.14 1.861c-1.631 1.1 -3.415 1.651 -5.357 1.651c-4 0 -7.333 -2.333 -10 -7c1.369 -2.395 2.913 -4.175 4.632 -5.341" /></svg>';
    } else {
      x.type = "password";
      document.getElementById("show-Icon").innerHTML =
        '<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-eye" width="28" height="28" viewBox="0 0 24 24" stroke-width="1.5" stroke="#2563eb" fill="none" stroke-linecap="round" stroke-linejoin="round"> <path stroke="none" d="M0 0h24v24H0z" fill="none"/><circle cx="12" cy="12" r="2" />  <path d="M22 12c-2.667 4.667 -6 7 -10 7s-7.333 -2.333 -10 -7c2.667 -4.667 6 -7 10 -7s7.333 2.333 10 7" /> </svg>';
    }
  }
  async function Authentication(value) {
    setLoading(true);
    const res = await Authen(value);
    if (res) {
      if (res.statusCode === 200 && res.taskStatus) {
        let user = JSON.stringify(res.users);
        auth.AUTHEN(user, res.token, res.users.role);
        auth.USERINFO();
        Instance.defaults.headers["Authorization"] = "Bearer " + res.token;
        history.push("/");
        LOGINSUCCESS();
        if (value.remember) {
          localStorage.setItem("remember", value.remember);
          localStorage.setItem("name", value.userName);
          localStorage.setItem("pass", value.passWord);
        } else {
          localStorage.removeItem("remember");
          localStorage.removeItem("name");
          localStorage.removeItem("pass");
        }
      } else {
        Swal.fire({
          icon: "error",
          title: "ไม่สามารถเข้าสู่ระบบได้",
          text: "กรุณาตรวจสอบ ชื่อผู้ใช้ หรือ รหัสผ่าน อีกครั้ง",
          showConfirmButton: false,
          showCancelButton: true,
          cancelButtonText: "ปิด",
        });
      }
    }
    setLoading(false);
  }

  return (
    <Modal
      width="max-w-lg"
      isOpen={auth.open}
      onClose={() => {
        auth.onOpen(false);
      }}
    >
      <div className="bg-white">
        <div className="flex justify-center">
          <p className="flex font-bold items-center text-blue-900 gap-2 text-3xl py-5">
            <SVGTeacher width="50" height="50" color="#111827" strokeWidth="2" />
            EDU
          </p>
        </div>
        <Formik
          initialValues={{
            userName: checkData ? name.toString() : "",
            passWord: checkData ? pass.toString() : "",
            remember: checkData ? checkData : "",
          }}
          enableReinitialize={true}
          onSubmit={(value) => {
            Authentication(value);
          }}
        >
          {({ values, setFieldValue }) => (
            <Form>
              <div className="rounded-b-lg py-2 px-4 ">
                <div className="relative">
                  <input
                    className="login-input"
                    id="userName"
                    onChange={(e) => {
                      setFieldValue("userName", e.target.value);
                    }}
                    name="userName"
                    type="text"
                    placeholder="ชื่อผู้ใช้งาน"
                    value={values.userName}
                  />
                  <div className="absolute left-0 inset-y-0 flex items-center">
                    <SVGUser width="26" height="26" color="#60a5fa" strokeWidth="2" className="h-9 w-9 ml-2 p-1" />
                  </div>
                </div>
                <div className="relative mt-3">
                  <input
                    className="login-input"
                    onChange={(e) => {
                      setFieldValue("passWord", e.target.value);
                    }}
                    id="input-pass"
                    name="passWord"
                    type="password"
                    placeholder="รหัสผ่าน"
                    value={values.passWord}
                  />
                  <div className="absolute left-0 inset-y-0 flex items-center">
                    <SVGLock width="26" height="26" color="#60a5fa" strokeWidth="2" className="h-9 w-9 ml-2 p-1" />
                  </div>
                  <div className="absolute right-0 inset-y-0 flex items-center">
                    <button type="button" className="focus:outline-none mr-3" id="show-Icon" onClick={showPass}>
                      <SVGEye width="28" height="28" color="#2563eb" strokeWidth="1.5" />
                    </button>
                  </div>
                </div>
                <div className="mt-4 flex items-center justify-end text-gray-500 ">
                  <input
                    onChange={(e) => {
                      setFieldValue("remember", e.target.checked);
                    }}
                    type="checkbox"
                    id="remember"
                    name="remember"
                    checked={values.remember}
                    className="mr-1 h-4 w-4 cursor-pointer accent-blue-800 focus:accent-blue-900 checked:border-blue-600 "
                  />
                  <label htmlFor="remember" className="cursor-pointer text-blue-800">
                    จำรหัสผ่าน
                  </label>
                </div>
                <div className="flex items-center justify-center mt-2 mb-5 gap-2">
                  <button
                    disabled={loading || (values.userName !== "" && values.passWord !== "") ? false : true}
                    className={`text-white py-2 px-6 rounded w-[8rem] shadow hover:shadow-lg font-medium focus:outline-none  ${
                      values.userName !== "" && values.passWord !== "" ? "bg-blue-600 hover:bg-blue-800" : "bg-gray-300 cursor-not-allowed"
                    }`}
                  >
                    {loading ? (
                      <p className="flex justify-center items-center gap-2">
                        <SVGLoading width={20} />
                      </p>
                    ) : (
                      " เข้าสู่ระบบ"
                    )}
                  </button>
                  <button
                    onClick={() => {
                      auth.onOpen(false);
                    }}
                    type="button"
                    className={`text-white w-[8rem] py-2 px-6 rounded shadow hover:shadow-lg font-medium focus:outline-none bg-gray-500 hover:bg-gray-600`}
                  >
                    ยกเลิก
                  </button>
                </div>
              </div>
            </Form>
          )}
        </Formik>
      </div>
    </Modal>
  );
}
const mapStateToProps = (state) => ({
  auth: state.Authentication,
});

const mapDispatchToProps = (dispatch) => {
  return {
    AUTHEN: (users, accessToken, role) => dispatch(AUTHEN(users, accessToken, role)),
    USERINFO: () => dispatch(USERINFO()),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Login);
