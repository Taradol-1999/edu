import { Form, Formik } from "formik";
import React, { useEffect, useState } from "react";
import { useRef } from "react";
import { useReactToPrint } from "react-to-print";
import Modal from "../../../components/Modal";
import PrintReport from "./PrintReport";
import { LoadReportPrint } from "../../../services/Report.Services";
import { TextSelect } from "../../../components/TextSelect";
import { GetDropdown } from "../../../services/Dropdown.services";
import { object, string } from "yup";
import { STATUSWARNING } from "../../../components/alert";

export default function ModalPrint({ open, setOpen }) {
  const [data, setData] = useState([]);
  const [major, setMajor] = useState([]);
  const [faculty, setFaculty] = useState([]);
  const [semesterSearch, setSemesterSearch] = useState([]);
  const [yearSearch, setYearSearch] = useState([]);
  const componentRef = useRef();

  async function loadData(MaId = 0, FacId = 0, Year = "", Term = "") {
    let res = await LoadReportPrint(MaId, FacId, Year, Term);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        setData(res.data);
        handlePrint();
      } else {
        STATUSWARNING();
      }
    }
  }

  useEffect(() => {
    loadDropdown();
  }, []);

  async function loadDropdown() {
    let result = await GetDropdown();
    if (result) {
      setMajor(result.majors);
      setFaculty(result.faculty);
      setSemesterSearch(result.settingRegis.semester);
      setYearSearch(result.settingRegis.year);
    }
  }
  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
  });

  const validate = object({
    year: string().required("กรุณาเลือก ปีการศึกษา"),
    semester: string().required("กรุณาเลือก เทอม"),
  });

  return (
    <Modal
      width="max-w-4xl"
      isOpen={open}
      title="คำสั่งแต่งตั้งอาจารย์นิเทศก์"
      onClose={() => {
        setOpen(false);
      }}
    >
      <Formik
        validationSchema={validate}
        initialValues={{
          year: "",
          semester: "",
          facId: 0,
          maId: 0,
        }}
        enableReinitialize={true}
        onSubmit={async (values) => {
          await loadData(values.maId, values.facId, values.year, values.semester);
        }}
      >
        {({ values, setFieldValue }) => (
          <Form>
            <div className="flex flex-wrap py-2 ">
              <div className="w-1/2">
                <TextSelect
                  title="ปีการศึกษา"
                  placeholder="ปีการศึกษา"
                  options={yearSearch}
                  name="year"
                  value={yearSearch.filter((x) => x.year === values.year)}
                  getOptionLabel={(x) => x.year}
                  getOptionValue={(x) => x.year}
                  onChange={(e) => {
                    setFieldValue("year", e.year);
                  }}
                />
              </div>
              <div className="w-1/2 px-2">
                <TextSelect
                  title="ภาคการศึกษา"
                  options={semesterSearch}
                  name="semester"
                  value={semesterSearch.filter((x) => x.semester === values.semester)}
                  placeholder="ภาคการศึกษา"
                  getOptionLabel={(x) => x.semester}
                  getOptionValue={(x) => x.semester}
                  onChange={(e) => {
                    setFieldValue("semester", e.semester);
                  }}
                />
              </div>

              <div className="w-1/2 px-2">
                <TextSelect
                  title="คณะ"
                  options={faculty}
                  value={faculty.filter((x) => x.facultyId === values.facId)}
                  name="facId"
                  placeholder="คณะ"
                  getOptionLabel={(x) => x.facultyName}
                  getOptionValue={(x) => x.facultyId}
                  onChange={(e) => {
                    setFieldValue("facId", e.facultyId);
                    setFieldValue("maId", 0);
                  }}
                />
              </div>
              <div className="w-1/2 px-2">
                <TextSelect
                  title="สาขา"
                  name="facId"
                  placeholder="สาขา"
                  options={major.filter((x) => x.facultyId === values.facId)}
                  value={major.filter((x) => x.majorId === values.maId)}
                  getOptionLabel={(x) => x.majorName}
                  getOptionValue={(x) => x.majorId}
                  onChange={(e) => {
                    setFieldValue("maId", e.majorId);
                  }}
                />
              </div>
            </div>
            <div className="flex justify-center">
              <button type="submit" className="buttonSearch">
                พิมพ์รายงาน
              </button>
              <button type="reset" className="buttonReset">
                ล้างค่า
              </button>
            </div>
          </Form>
        )}
      </Formik>

      {data && (
        <div className="hidden">
          <div ref={componentRef}>{data.length > 0 && <PrintReport data={data} />}</div>
        </div>
      )}
    </Modal>
  );
}
