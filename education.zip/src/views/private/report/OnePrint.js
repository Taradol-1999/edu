import React from "react";
import LOGOKRU from "../../../assets/img/LOGO-KRU.png";

export default function OnePrint({ data }) {
  function CalculateScore(score) {
    let m = score.major * (score.scorePercentageMajor / 100);
    let p = score.profession * (score.scorePercentageProfession / 100);
    let t = score.mentor * (score.scorePercentageMentor / 100);
    let total = m + p + t;
    return total.toFixed(2);
  }
  function CalculateScore1(score, type) {
    let m = score.major * (score.scorePercentageMajor / 100);
    let p = score.profession * (score.scorePercentageProfession / 100);
    let t = score.mentor * (score.scorePercentageMentor / 100);

    if (type === 1) return m;
    if (type === 2) return p;
    if (type === 3) return t;
  }
  return (
    <div className="page-a4">
      <p className="flex justify-center pt-3">
        <img src={LOGOKRU} alt="" className=" w-28 h-32" />
      </p>
      <div className="w-full pb-3">
        <p className="text-center font-bold text-[20pt] ">รายงานผลการฝึกประสบการณ์วิชาชีพครู</p>
        <p className="text-center text-[18pt]">คณะครุศาสตร์ มหาวิทยาลัยราชภัฏกาญจนบุรี</p>
        <p className="text-center text-[18pt]">ภาคปีการศึกษา {data.semester + "/" + data.year}</p>
      </div>
      <div className="px-[20mm] flex mt-[12pt]">
        <div className="pb-3 w-1/3 ">
          <div>
            <p className="text-[18pt]">ชื่อ : {data.fullName}</p>
            <p className="text-[18pt]">รหัสนักศึกษา : {data.studId}</p>
            <p className="text-[18pt]">คณะ : {data.facultyName}</p>
            <p className="text-[18pt]">สาขา : {data.majorName}</p>
          </div>
        </div>
        <div className="pb-3 w-2/3 ">
          <div>
            <p className="text-[18pt]">โรงเรียน : {data.schoolName}</p>
            <p className="text-[18pt]">ที่อยู่ : {data.address}</p>
            <p className="text-[18pt]">วันที่เริ่มฝึก : {data.startTraining}</p>
            <p className="text-[18pt]">วันที่สิ้นสุด : {data.endTraining}</p>
          </div>
        </div>
      </div>
      <div className="px-[20mm]">
        <p className="font-bold text-[18pt]">ผลการประเมิน</p>
        <table className="w-full">
          <thead>
            <tr>
              <th className=" school-list-theadV2 w-[2%] text-center">ลำดับ</th>
              <th className="text-left school-list-theadV2 w-[15%]">ผู้ประเมิน</th>
              <th className="text-left school-list-theadV2 w-[10%]">ตำแหน่ง</th>
              <th className="text-left school-list-theadV2 w-[10%]">อัตราการให้คะแนน (%)</th>
              <th className="text-left school-list-theadV2 w-[10%]">เต็ม/ได้ (คะแนน)</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="school-list-tbodyV2 text-center">1.</td>
              <td className="school-list-tbodyV2">{data.appoint.fullNameMajor}</td>
              <td className="school-list-tbodyV2">อาจารย์นิเทศก์เอก</td>
              <td className="school-list-tbodyV2">{data.score.scorePercentageMajor}</td>
              <td className="school-list-tbodyV2">
                100 / {data.score.major} คิดเป็น {CalculateScore1(data.score, 1)} %
              </td>
            </tr>
            <tr>
              <td className="school-list-tbodyV2 text-center">2.</td>
              <td className="school-list-tbodyV2">{data.appoint.fullNamerProfession}</td>
              <td className="school-list-tbodyV2">อาจารย์นิเทศก์วิชาชีพครู</td>
              <td className="school-list-tbodyV2">{data.score.scorePercentageProfession}</td>
              <td className="school-list-tbodyV2">
                100 / {data.score.profession} คิดเป็น {CalculateScore1(data.score, 2)} %
              </td>
            </tr>
            <tr>
              <td className="school-list-tbodyV2 text-center">3.</td>

              <td className="school-list-tbodyV2">
                {data.appointmentors.map((it, ix) => (
                  <p key={ix}>{it.fullName}</p>
                ))}
              </td>

              <td className="school-list-tbodyV2">ครูพี้เลี้ยง</td>
              <td className="school-list-tbodyV2">{data.score.scorePercentageMentor} </td>
              <td className="school-list-tbodyV2">
                100 / {data.score.mentor} คิดเป็น {CalculateScore1(data.score, 3)} %
              </td>
            </tr>

            <tr>
              <td className="school-list-tbodyV2 text-center" colSpan={3}>
                รวม
              </td>
              <td className="school-list-tbodyV2 bg-blue-100">{data.score.scorePercentageMajor + data.score.scorePercentageProfession + data.score.scorePercentageMentor} </td>
              <td className="school-list-tbodyV2 bg-blue-100 text-center font-bold">{CalculateScore(data.score)}</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div className="px-[20mm] mt-[12pt]">
        <p className="text-[18pt]">
          <span className="font-bold">หมายเหตุ : </span>การประเมินผลการเรียนรายวิชานี้เป็นไปตามระเบียบมหาวิทยาลัย โดยผู้เรียนต้องได้ระตับผลการเรียน ไม่ต่ำกว่า C จึงจะถือว่าผ่าน
        </p>
        <p className="text-[18pt] font-bold mt-[12pt]">เกณฑ์การประเมินผล</p>
        <div className="flex justify-start items-center text-[18pt] pl-[2cm] mt-[12pt]">
          <div className="w-1/2">
            <table>
              <tbody>
                <tr>
                  <th className="border-[1px] px-2">ระดับคะแนน</th>
                  <th className="border-[1px] px-2">เกณฑ์</th>
                </tr>
                <tr>
                  <td className="border-[1px] px-2">A</td>
                  <td className="border-[1px] px-2">90 - 100</td>
                </tr>
                <tr>
                  <td className="border-[1px] px-2">B+</td>
                  <td className="border-[1px] px-2">85 - 89</td>
                </tr>
                <tr>
                  <td className="border-[1px] px-2">B</td>
                  <td className="border-[1px] px-2">80 - 84</td>
                </tr>
                <tr>
                  <td className="border-[1px] px-2">C+</td>
                  <td className="border-[1px] px-2">75 - 79</td>
                </tr>
                <tr>
                  <td className="border-[1px] px-2">C</td>
                  <td className="border-[1px] px-2">70 - 74</td>
                </tr>
              </tbody>
            </table>
          </div>
          <p className={`font-bold text-[72pt] w-1/2 ${CalculateScore(data.score) > 74 ? "text-green-600" : "text-red-600"}`}>{CalculateScore(data.score) > 74 ? "ผ่าน" : "ไม่ผ่าน"}</p>
        </div>
      </div>

      <div className="flex mt-[24pt] px-[20mm] text-[18pt] justify-center">
        <div className=" w-1/2" />
        <div className=" w-1/2 flex justify-start">
          <div className="text-center ">
            <div className="mb-[84pt]">ขอแสดงความนับถือ</div>
            <p>(ผู้ช่วยศาสตราจารย์ ดร.ภูชิตภูชำนิ)</p>
            <p>คณบดีคณะครุศาสตร์</p>
            <p>มหาวิทยาลัยราชภัฏกาญจนบุรี</p>
          </div>
        </div>
      </div>
      <p className="text-[18pt] mt-[24pt] px-[20mm]">
        ฝ่ายฝึกประสบการณ์วิชาชีพครู <br />
        โทรศัพท์ 0 3453 4071 <br />
        โทรสาร 0 3453 4071
      </p>
    </div>
  );
}
