import { CardBody, CardFooter } from "@material-tailwind/react";
import React, { Fragment, useState } from "react";
import Pagination from "../../../components/Pagination";
import { SelectPageSize } from "../../../components/SelectPageSize";
import { TextSearch } from "../../../components/TextSearch";
import { useEffect } from "react";
import { pageSize } from "../../../helper/data";
import LoadingData from "../../../components/LoadingData";
import DataReport from "./DataReport";
import { SelectSearch } from "../../../components/SelectSearch";
import { GetDropdown } from "../../../services/Dropdown.services";
import { LoadReport } from "../../../services/Report.Services";
import SVGPrint from "../../../SVGS/SVGPrint";
import ModalPrint from "./ModalPrint";

export default function MainReport() {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState([]);
  const [major, setMajor] = useState([]);
  const [faculty, setFaculty] = useState([]);
  const [semesterSearch, setSemesterSearch] = useState([]);
  const [yearSearch, setYearSearch] = useState([]);
  const [open, setOpen] = useState(false);
  //   ค้นหา
  const [facId, setFacId] = useState(0);
  const [maId, setMaId] = useState(0);
  const [keyword, setKeyword] = useState("");
  const [year, setYear] = useState("");
  const [term, setTerm] = useState("");
  const [pagin, setPagin] = useState({
    currentPage: 1,
    pageSize: 10,
    totalRows: 0,
    totalPages: 0,
  });

  useEffect(() => {
    loadData();
    loadDropdown();
  }, []);

  async function loadData(currentPage = 1, pageSize = 10, search = "", FacId = 0, MaId = 0, Year = "", Term = "") {
    setLoading(true);
    let res = await LoadReport(currentPage, pageSize, search, FacId, MaId, Year, Term);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        setPagin(res.pagin);
        setData(res.data);
        setKeyword(search);
        setMaId(MaId);
        setFacId(FacId);
        setYear(Year);
        setTerm(Term);
      }
    }
    setLoading(false);
  }

  function reset() {
    loadData(1, 10, "", 0, 0, "", "");
  }

  async function loadDropdown() {
    let result = await GetDropdown();
    if (result) {
      setMajor(result.majors);
      setFaculty(result.faculty);
      setSemesterSearch(result.settingRegis.semester);
      setYearSearch(result.settingRegis.year);
    }
  }

  return (
    <Fragment>
      <ModalPrint open={open} setOpen={setOpen} />
      <p className="text-blue-800 underline">รายงานผลการฝึกประสบการณ์วิชาชีพครู</p>
      <div className="items-center mt-5 p-2 bg-white rounded hover:shadow-lg duration-300">
        <div className="flex flex-wrap gap-y-2">
          <div className="w-6/12 pr-2 ">
            <TextSearch
              placeholder="ค้นหา"
              onChange={(e) => {
                setKeyword(e.target.value.trim());
              }}
              value={keyword}
            />
          </div>
          <div className="w-3/12 pr-2">
            <SelectSearch
              placeholder="ปีการศึกษา"
              title="ปีการศึกษา"
              options={yearSearch}
              name="year"
              value={yearSearch.filter((x) => x.year === year)}
              getOptionLabel={(x) => x.year}
              getOptionValue={(x) => x.year}
              onChange={(e) => {
                setYear(e.year);
              }}
            />
          </div>
          <div className="w-3/12 pr-2">
            <SelectSearch
              options={semesterSearch}
              value={semesterSearch.filter((x) => x.semester === term)}
              placeholder="ภาคการศึกษา"
              getOptionLabel={(x) => x.semester}
              getOptionValue={(x) => x.semester}
              onChange={(e) => {
                setTerm(e.semester);
              }}
            />
          </div>
          <div className="w-3/12 pr-2">
            <SelectSearch
              placeholder="คณะ"
              options={faculty}
              value={faculty.filter((x) => x.facultyId === facId)}
              getOptionLabel={(x) => x.facultyName}
              getOptionValue={(x) => x.facultyId}
              onChange={(e) => {
                setFacId(e.facultyId);
                setMaId(0);
              }}
            />
          </div>
          <div className="w-3/12 pr-2">
            <SelectSearch
              placeholder="สาขา"
              options={major.filter((x) => x.facultyId === facId)}
              value={major.filter((x) => x.majorId === maId)}
              getOptionLabel={(x) => x.majorName}
              getOptionValue={(x) => x.majorId}
              onChange={(e) => {
                setMaId(e.majorId);
              }}
            />
          </div>
        </div>
        <div className="w-full flex justify-center py-5">
          <button
            className="buttonSearch"
            onClick={() => {
              loadData(1, pagin.pageSize, keyword, facId, maId, year, term);
            }}
          >
            <span>ค้นหา</span>
          </button>
          <button
            className="buttonReset"
            onClick={(e) => {
              reset();
            }}
          >
            <span>ล้างค่า</span>
          </button>
        </div>
      </div>
      <div className="flex justify-between mt-5">
        <SelectPageSize
          options={pageSize}
          getOptionLabel={(x) => x.name}
          getOptionValue={(x) => x.id}
          value={pageSize.filter((a) => a.id === pagin.pageSize)}
          onChange={(e) => {
            loadData(1, e.id, keyword);
          }}
        />
        <div className="flex justify-end">
          <button
            className="buttonAdd"
            onClick={() => {
              // handlePrint();
              setOpen(true);
            }}
          >
            <SVGPrint width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> รายงานภาพรวม
          </button>
        </div>
      </div>
      <CardBody>
        {loading ? (
          <div className="flex justify-center bg-transparent mt-52">
            <LoadingData />
          </div>
        ) : (
          <div className="overflow-auto">
            <DataReport data={data} pagin={pagin} />
          </div>
        )}
      </CardBody>
      <CardFooter>
        <Pagination
          totalPage={pagin.pageCount}
          onChange={async (page) => {
            loadData(page, pagin.pageSize, keyword);
          }}
          currentPages={pagin.currentPage}
          totalRow={pagin.rowCount}
        />
      </CardFooter>
    </Fragment>
  );
}
