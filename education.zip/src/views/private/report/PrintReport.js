import React from "react";
import LOGOKRU from "../../../assets/img/LOGO-KRU.png";

export default function PrintReport({ data }) {
  function CalculateScore(score) {
    let m = score.major * (score.scorePercentageMajor / 100);
    let p = score.profession * (score.scorePercentageProfession / 100);
    let t = score.mentor * (score.scorePercentageMentor / 100);
    let total = m + p + t;
    return total.toFixed(2);
  }

  return (
    <div className="page-a4">
      <p className="flex justify-center pt-3">
        <img src={LOGOKRU} alt="" className=" w-28 h-32" />
      </p>
      <div className="w-full pb-3">
        <p className="text-center font-bold text-[20px] ">รายงานผลการฝึกประสบการณ์วิชาชีพครู</p>
        <p className="text-center text-[18px]">คณะครุศาสตร์ มหาวิทยาลัยราชภัฏกาญจนบุรี</p>
        <p className="text-center text-[18px]">ภาคปีการศึกษา {data[0].semester + "/" + data[0].year}</p>
      </div>
      <div className="px-5">
        <table className="min-w-full ">
          <thead>
            <tr>
              <th className="school-list-thead" style={{ width: "2%" }}>
                ลำดับ
              </th>
              <th className="school-list-thead" style={{ width: "10%" }}>
                รหัสนักศึกษา
              </th>
              <th className="school-list-thead" style={{ width: "10%" }}>
                ชื่อ-นามสกุล
              </th>
              <th className="school-list-thead" style={{ width: "10%" }}>
                คณะ
              </th>
              <th className="school-list-thead" style={{ width: "10%" }}>
                สาขา
              </th>
              <th className="school-list-thead" style={{ width: "10%" }}>
                คะแนนรวม
              </th>
            </tr>
          </thead>
          {data.map((value, index) => (
            <tbody key={index}>
              <tr>
                <td className="school-list-tbody" style={{ width: "2%" }}>
                  {index + 1}
                </td>
                <td className="school-list-tbody" style={{ width: "10%" }}>
                  {value.studId}
                </td>
                <td className="school-list-tbody" style={{ width: "10%" }}>
                  {value.fullName}
                </td>
                <td className="school-list-tbody" style={{ width: "10%" }}>
                  {value.facultyName}
                </td>
                <td className="school-list-tbody" style={{ width: "10%" }}>
                  {value.majorName}
                </td>
                <td className="school-list-tbody" style={{ width: "10%" }}>
                  {CalculateScore(value.score)}
                </td>
              </tr>
            </tbody>
          ))}
        </table>
      </div>
    </div>
  );
}
