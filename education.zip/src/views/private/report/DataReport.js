import React, { useState } from "react";
import NotData from "../../../components/NotData";
import SVGPrint from "../../../SVGS/SVGPrint";
import OnePrint from "./OnePrint";
import { useRef } from "react";
import { useReactToPrint } from "react-to-print";

export default function DataReport({ data, pagin }) {
  const [dataPrint, setDataPrint] = useState(null);
  const componentRef = useRef();

  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
  });
  return (
    <div>
      {dataPrint && (
        <div className="hidden">
          <div ref={componentRef}>{data.length > 0 && <OnePrint data={dataPrint} />}</div>
        </div>
      )}

      <table className="w-full bg-transparent">
        <thead>
          <tr>
            <th className="w-[2%] thead-th rounded-tl-lg">#</th>
            <th className="w-[10%] thead-th">
              รหัสนักศึกษา <br /> ชื่อ-นามสกุล
            </th>
            <th className="w-[10%] thead-th">คณะ / สาขา</th>
            <th className="w-[10%] thead-th">ภาค/ปีการศึกษา</th>
            <th className="w-[15%] thead-th">โรงเรียน</th>
            <th className="w-[18%] thead-th">อาจารย์นิเทศก์</th>
            <th className="w-[10%] thead-th rounded-tr-lg">พิมพ์รายงาน</th>
          </tr>
        </thead>
        <tbody>
          {data.length === 0 ? (
            <NotData />
          ) : (
            data.map((item, index) => (
              <tr key={index}>
                <th className="tbody-th">{(pagin.currentPage - 1) * pagin.pageSize + (index + 1)}</th>
                <th className="tbody-th">
                  {item.studId} <br /> {item.fullName}
                </th>
                <th className="tbody-th">
                  {item.facultyName}
                  <br /> <span className="text-gray-500 italic font-light"> {item.majorName}</span>
                </th>
                <th className="tbody-th">{item.semester + " / " + item.year}</th>
                <th className="tbody-th">โรงเรียน{item.schoolName}</th>
                <th className="tbody-th">
                  {item.appoint ? (
                    <p>
                      {item.appoint.fullNameMajor} <span className="text-gray-500 italic font-light"> (วิชาเอก)</span>
                    </p>
                  ) : (
                    <span className="text-gray-500 italic font-light"> ไม่มีการแต่งตั้ง</span>
                  )}
                  {item.appoint && (
                    <p>
                      {item.appoint.fullNamerProfession} <span className="text-gray-500 italic font-light"> (วิชาชีพครู)</span>
                    </p>
                  )}
                </th>
                <th className="tbody-th">
                  <div className=" flex justify-start">
                    <div
                      onClick={() => {
                        handlePrint();
                        setDataPrint(item);
                      }}
                      className=" w-10 h-10 rounded-full bg-blue-600 flex justify-center items-center cursor-pointer hover:bg-blue-400 duration-300"
                    >
                      <SVGPrint width="24" height="24" color="#FFFFFF" strokeWidth="2" />
                    </div>
                  </div>
                </th>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}
