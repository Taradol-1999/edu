import { array, object, string } from "yup";
export const validateScroe = object({
  scroe: string().required("กรุณากรอก คะแนนที่ได้"),
  fullScore: string().required("กรุณากรอก คะแนนเต็ม"),
  attachEvidence: array().min(1, "กรุณาแนบ หลักฐาน").max(50, "Too Long!"),
});
