import { Form, Formik, getIn } from "formik";
import React, { Fragment } from "react";
import { TextField } from "../../../components/TextField";
import { TextFieldArea } from "../../../components/TextFieldArea";
import SVGReset from "../../../SVGS/SVGReset";
import SVGSave from "../../../SVGS/SVGSave";
import Dropzone from "../../../components/Dropzone";
import { validateScroe } from "../register/Validate";

export default function ScoreProfession({ saveData, detailProfession }) {
  return (
    <Fragment>
      <p className="text-xl font-bold py-2 underline">อาจารย์นิเทศก์วิชาชีพครู</p>
      <Formik
        initialValues={{
          id: detailProfession ? detailProfession.scroeId : "",
          scroe: detailProfession ? detailProfession.scroe : "",
          fullScore: detailProfession ? detailProfession.fullScore : "",
          note: detailProfession?.note ? detailProfession.note : "",
          scroeName: "คะแนนอาจารย์นิเทศก์วิชาชีพครู",
          attachEvidence: detailProfession ? detailProfession.attachEvidence : [],
          removeDoc: [],
        }}
        validationSchema={validateScroe}
        enableReinitialize={true}
        onSubmit={async (values) => {
          saveData(values);
        }}
      >
        {({ values, setFieldValue, handleChange, touched, errors }) => (
          <Form>
            <div className="grid md:grid-cols-12">
              <div className="md:col-span-12 flex">
                <div className="w-1/2">
                  <TextField
                    name="fullScore"
                    type="number"
                    value={values.fullScore}
                    title="คะแนนเต็ม"
                    placeholder="กรอกคะแนนเต็ม"
                    onChange={(e) => {
                      setFieldValue("fullScore", e.target.value);
                    }}
                  />
                </div>
                <div className="w-1/2 ">
                  <TextField
                    name="scroe"
                    type="number"
                    value={values.scroe}
                    title="คะแนนที่ได้"
                    placeholder="กรอกคะแนนที่ได้"
                    onChange={(e) => {
                      setFieldValue("scroe", e.target.value);
                    }}
                  />
                </div>
              </div>
              <div className="md:col-span-12">
                <TextFieldArea
                  name="note"
                  value={values.note}
                  title="หมายเหตุ"
                  placeholder="หมายเหตุ"
                  onChange={(e) => {
                    setFieldValue("note", e.target.value);
                  }}
                />
              </div>
              <div className="md:col-span-12">
                <Dropzone
                  id="profession"
                  title="อัพโหลดไฟล์หลักฐาน"
                  accept="application/pdf"
                  name="attachEvidence"
                  errors={getIn(errors, "attachEvidence")}
                  touched={getIn(touched, "attachEvidence")}
                  value={values.attachEvidence}
                  onChange={async (e) => {
                    let files = e.target.files;
                    if (files.length > 0) {
                      let addimg = [...values.attachEvidence];
                      for (let i = 0; i < files.length; i++) {
                        addimg.push(files[i]);
                      }
                      setFieldValue("attachEvidence", addimg);
                    }
                  }}
                  onDelete={(e) => {
                    let img = [...values.attachEvidence];

                    if (img[e].id) {
                      let removeFile = [...values.removeDoc];
                      removeFile.push(img[e].id);
                      setFieldValue("removeDoc", removeFile);
                    }

                    let result = img.filter((item, indx) => indx !== e);
                    setFieldValue("attachEvidence", result);
                  }}
                />
              </div>
            </div>

            <div className="w-full px-2">
              <div className="flex gap-3 justify-center my-5">
                <button className="buttonSave" type="submit">
                  <div className="flex items-center justify-center text-center">
                    <SVGSave width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> บันทึก
                  </div>
                </button>
                <button className="buttonResetV1" type="reset">
                  <SVGReset width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> ล้างค่า
                </button>
              </div>
            </div>
          </Form>
        )}
      </Formik>
    </Fragment>
  );
}
