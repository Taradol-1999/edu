import React, { Fragment } from "react";
import Modal from "../../../components/Modal";
import { CreateScore, EditScroe } from "../../../services/Score.services";
import ScoreMajor from "./ScoreMajor";
import ScoreMentor from "./ScoreMentor";
import ScoreProfession from "./ScoreProfession";
import { MESSAGEERROR, MESSAGESUCCESS } from "../../../components/alert";

export default function MainScroe({ open, close, role, item, user, detailProfession, setDetailProfession, detailMajor, setDetailMajor, detailMentor, setDetailMentor, loadData }) {
  const SAVEMajor = async (data) => {
    let res = data.id ? await EditScroe(data, item) : await CreateScore(data, item);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        MESSAGESUCCESS(res.message);
      } else {
        MESSAGEERROR(res.message);
      }
    }
  };

  const SAVEProfession = async (data) => {
    let res = data.id ? await EditScroe(data, item) : await CreateScore(data, item);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        MESSAGESUCCESS(res.message);
      } else {
        MESSAGEERROR(res.message);
      }
    }
  };

  const SAVEMentor = async (data) => {
    let res = data.id ? await EditScroe(data, item) : await CreateScore(data, item);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        MESSAGESUCCESS(res.message);
      } else {
        MESSAGEERROR(res.message);
      }
    }
  };

  return (
    <Fragment>
      <Modal
        width="max-w-2xl"
        isOpen={open}
        title={`กรอกคะแนน`}
        onClose={() => {
          close(false);
          setDetailProfession(null);
          setDetailMajor(null);
          setDetailMentor(null);
          loadData();
        }}
      >
        <div className="px-5">
          {role === "1" ? (
            <div>
              <ScoreMajor
                detailMajor={detailMajor}
                saveData={(v) => {
                  SAVEMajor(v);
                }}
              />
              <div className="border-t-2 border-blue-600" />
              <ScoreProfession
                detailProfession={detailProfession}
                saveData={(v) => {
                  SAVEProfession(v);
                }}
              />
              <div className="border-t-2 border-blue-600" />
              <ScoreMentor
                detailMentor={detailMentor}
                saveData={(v) => {
                  SAVEMentor(v);
                }}
              />
            </div>
          ) : (
            <Fragment>
              {user?.userId === item?.appoint.instructorMajor && (
                <ScoreMajor
                  detailMajor={detailMajor}
                  saveData={(v) => {
                    SAVEMajor(v);
                  }}
                />
              )}
              <div className="border-t-2 border-blue-600" />
              {user?.userId === item?.appoint.instructorProfession && (
                <ScoreProfession
                  detailProfession={detailProfession}
                  saveData={(v) => {
                    SAVEProfession(v);
                  }}
                />
              )}
              {item?.appointmentors.filter((c) => c.mentorId === user?.userId).length > 0 && (
                <ScoreMentor
                  detailMentor={detailMentor}
                  saveData={(v) => {
                    SAVEMentor(v);
                  }}
                />
              )}
            </Fragment>
          )}
        </div>
      </Modal>
    </Fragment>
  );
}
