import React, { Fragment } from "react";
import { useHistory } from "react-router-dom";
import ButtonDropdown from "../../../../components/ButtonDropdown";
import NotData from "../../../../components/NotData";
import { FormatPrefix } from "../../../../helper/FormatPrefix";
import { FormatTypeUser } from "../../../../helper/FormatTypeUser";

export default function DataUser({ retrunDelete, user, pagin }) {
  let history = useHistory();
  return (
    <Fragment>
      <table className="w-full bg-transparent">
        <thead>
          <tr>
            <th className="thead-th rounded-tl-lg">#</th>
            <th className="thead-th">ชื่อผู้ใช้งาน</th>
            <th className="thead-th">ชื่อ-นามสกุล</th>
            <th className="thead-th">คณะ/สาขา</th>
            <th className="thead-th">เบอร์โทร</th>
            <th className="thead-th">ประเภทผู้ใช้งาน</th>
            <th className="thead-th rounded-tr-lg">จัดการข้อมูล</th>
          </tr>
        </thead>
        <tbody>
          {user.length === 0 ? (
            <NotData />
          ) : (
            user.map((value, index) => (
              <tr key={index}>
                <th className="tbody-th">{(pagin.currentPage - 1) * pagin.pageSize + (index + 1)}</th>
                <th className="tbody-th">{value.userName}</th>
                <th className="tbody-th">{FormatPrefix(value.preFix) + " " + value.fullName}</th>
                <th className="tbody-th">{value.facultyName ? value.facultyName + "/" + value.majorName : "-"}</th>
                <th className="tbody-th">{value.phone}</th>
                <th className="tbody-th">{FormatTypeUser(value.role)}</th>
                <th className="tbody-th">
                  <ButtonDropdown
                    onClickEdit={() => {
                      history.push("/MainUsers/FromUser?id=" + value.userId);
                    }}
                    info={false}
                    onClickDelete={() => {
                      retrunDelete(value.userId);
                    }}
                  />
                </th>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </Fragment>
  );
}
