import { object, string } from "yup";

const email = /^[a-zA-Z0-9_\\.]+@[a-zA-Z]+\.[a-zA-Z0-9\\.]+$/;
const phone = /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/;
export const validateUser = object({
  preFix: string().required("กรุณาเลือก คำนำหน้าชื่อ"),
  firstName: string().required("กรุณากรอก ชื่อ"),
  lastName: string().required("กรุณากรอก นามสกุล"),
  role: string().required("กรุณาเลือก ประเภทผู้ใช้งาน"),
  phone: string().matches(phone, "กรุณากรอก เบอร์โทร").required("กรุณากรอก เบอร์โทร").max(10, "กรุณาตรวจสอบ เบอร์โทร"),
  userName: string().when("role", (value, schema) => {
    if (value === "3") {
      return schema.required("กรุณากรอก รหัสนักศึกษา").matches(/^(0|[1-9]\d*)$/, "กรุณากรอก รหัสนักศึกษา");
    } else {
      return schema.required("กรุณากรอก อีเมล").matches(email, "รูปแบบอีเมลไม่ถูกต้อง");
    }
  }),
  passWord: string().required("กรุณากรอก รหัสผ่าน").min(6, "รหัสผ่านต้องมากกว่า 6 อักษร").max(50, "รหัสผ่านต้องไม่มากกว่า 50 อักษร"),
  facultyId: string().when("role", (value, schema) => {
    if (value !== "1") {
      return schema.required("กรุณาเลือก คณะ");
    } else {
      return schema.notRequired();
    }
  }),
  majorId: string().when("role", (value, schema) => {
    if (value !== "1") {
      return schema.required("กรุณาเลือก สาขา");
    } else {
      return schema.notRequired();
    }
  }),
});

export const validateMajor = object({
  majorName: string().required("กรุณากรอก ชื่อสาขา"),
  facultyID: string().required("กรุณาเลือก คณะ"),
});
export const validatepreFix = object({
  preFix: string().required("กรุณากรอก คำนำหน้าชื่อ"),
});
