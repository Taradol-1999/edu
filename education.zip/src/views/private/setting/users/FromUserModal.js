import React, { useState, useEffect } from "react";
import { Formik, Form } from "formik";
import SVGSave from "../../../../SVGS/SVGSave";
import SVGReset from "../../../../SVGS/SVGReset";
import { TextField } from "../../../../components/TextField";
import { validateUser } from "./validate";
import { LoadByUserId, UpdateUser } from "../../../../services/User.services";
import { MESSAGEERROR, MESSAGESUCCESS } from "../../../../components/alert";
import SVGLoading from "../../../../SVGS/SVGLoading";
import { TextSelect } from "../../../../components/TextSelect";
import { GetDropdown } from "../../../../services/Dropdown.services";
import Modal from "../../../../components/Modal";
import { Fragment } from "react";
import SVGClose from "../../../../SVGS/SVGClose";
import { TextFieldPassword } from "../../../../components/TextFieldPassword";

export default function FromUserModal({ openUser, setOpenUser }) {
  const user = JSON.parse(localStorage.getItem("users"));
  const [loading, setLoading] = useState(false);
  const [detail, setDetail] = useState([]);
  const [edit, setEdit] = useState(false);
  const [title, setPrefix] = useState([]);

  useEffect(() => {
    if (openUser) {
      loadDetail(openUser);
    }
    loadDropdown();
  }, [openUser]);

  async function loadDetail(id) {
    let result = await LoadByUserId(id);

    setDetail(result.data);
  }

  async function loadDropdown() {
    let result = await GetDropdown();
    setPrefix(result.title);
  }

  const SAVE = async (values) => {
    let data = { ...values };
    data.majorId = data.majorId ? data.majorId : null;
    setLoading(true);
    let res = await UpdateUser(data);
    if (res) {
      if (res.statusCode === 200 && res.taskStatus) {
        setEdit(false);
        MESSAGESUCCESS(res.message);
      } else {
        MESSAGEERROR(res.message);
      }
    }
    setLoading(false);
  };

  function chkRole(role) {
    switch (role) {
      case "1":
        return "เจ้าหน้าที่";
      case "2":
        return "อาจารย์";
      case "3":
        return "นักศึกษา";
      default:
        return "-";
    }
  }
  return (
    <Modal
      width="max-w-[50rem]"
      title={`ข้อมูลผู้ใช้งาน`}
      subTitle={`(${chkRole(detail.role)})`}
      isOpen={openUser ? true : false}
      onClose={() => {
        setOpenUser(false);
        setEdit(false);
      }}
    >
      <div className={`duration-300  ${edit ? "h-[15rem]" : "h-[18rem]"}`}>
        {edit ? (
          <Formik
            initialValues={{
              userId: detail.userId ? detail.userId : "",
              preFix: detail.preFix ? detail.preFix : "",
              firstName: detail.firstName ? detail.firstName : "",
              lastName: detail.lastName ? detail.lastName : "",
              phone: detail.phone ? detail.phone : "",
              userName: detail.userName ? detail.userName : "",
              passWord: detail.passWord ? detail.passWord : "",
              facultyId: detail.facultyId ? detail.facultyId : "",
              majorId: detail.majorId ? detail.majorId : "",
              role: detail.role ? detail.role : "",
            }}
            validationSchema={validateUser}
            enableReinitialize={true}
            onSubmit={async (values) => {
              SAVE(values);
            }}
          >
            {({ values, setFieldValue, handleChange }) => (
              <Form>
                <div className="w-full flex-col-reverse items-center justify-between">
                  <div className="flex flex-wrap">
                    <div className="md:w-2/12">
                      <TextSelect
                        title="คำนำหน้าชื่อ"
                        options={title}
                        name="preFix"
                        value={title.filter((x) => x.titleId === values.preFix)}
                        placeholder="คำนำหน้าชื่อ"
                        getOptionLabel={(x) => x.titleName}
                        getOptionValue={(x) => x.titleId}
                        onChange={(e) => {
                          setFieldValue("preFix", e.titleId);
                        }}
                      />
                    </div>
                    <div className="md:w-5/12">
                      <TextField name="firstName" value={values.firstName} title="ชื่อ" placeholder="ชื่อ" onChange={handleChange} type="text" />
                    </div>
                    <div className="md:w-5/12">
                      <TextField name="lastName" value={values.lastName} title="นามสกุล" placeholder="นามสกุล" onChange={handleChange} type="text" />
                    </div>
                    <div className="md:w-2/12">
                      <TextField name="phone" value={values.phone} title="เบอร์โทร" placeholder="เบอร์โทร" onChange={handleChange} type="text" />
                    </div>
                    <div className="md:w-5/12">
                      <TextField
                        disabled={user.role === "3"}
                        name="userName"
                        value={values.userName}
                        title={values.role !== "3" ? "ชื่อผู้ใช้(อีเมล)" : "รหัสนักศึกษา"}
                        placeholder="ชื่อผู้ใช้"
                        onChange={handleChange}
                        type="text"
                      />
                    </div>
                    <div className="md:w-5/12">
                      <TextFieldPassword name="passWord" value={values.passWord} title="รหัสผ่าน" placeholder="รหัสผ่าน" onChange={handleChange} type="text" />
                    </div>
                  </div>
                  <div className="flex gap-3 justify-center my-10">
                    <button className={loading ? "buttonSave cursor-no-drop" : "buttonSave"} type="submit" disabled={loading}>
                      {loading ? (
                        <div className="flex items-center justify-center text-center">
                          <SVGLoading width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" />
                          บันทึก
                        </div>
                      ) : (
                        <div className="flex items-center justify-center text-center">
                          <SVGSave width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> บันทึก
                        </div>
                      )}
                    </button>
                    <button className="buttonResetV1" type="reset">
                      <SVGReset width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> ล้างค่า
                    </button>
                    <button className="buttonClose" type="reset" onClick={() => setEdit(false)}>
                      <SVGClose width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> ยกเลิก
                    </button>
                  </div>
                </div>
              </Form>
            )}
          </Formik>
        ) : (
          <Fragment>
            <div className="p-2">
              <table className="text-lg my-3">
                <tbody>
                  <tr>
                    <td className="px-2 py-2 text-gray-600 font-semibold">ชื่อ</td>
                    <td className="px-2 py-2">{detail.fullName}</td>
                  </tr>
                  <tr>
                    <td className="px-2 py-2 text-gray-600 font-semibold">{detail.role !== "3" ? "ชื่อผู้ใช้งาน" : "รหัสนักศึกษา"}</td>
                    <td className="px-2 py-2">{detail.userName}</td>
                  </tr>
                  <tr>
                    <td className="px-2 py-2 text-gray-600 font-semibold">คณะ</td>
                    <td className="px-2 py-2">{detail.facultyName ?? "-"}</td>
                  </tr>
                  <tr>
                    <td className="px-2 py-2 text-gray-600 font-semibold">สาขา</td>
                    <td className="px-2 py-2">{detail.majorName ?? "-"}</td>
                  </tr>
                  <tr>
                    <td className="px-2 py-2 text-gray-600 font-semibold">เบอร์โทรศัพท์</td>
                    <td className="px-2 py-2">{detail.phone}</td>
                  </tr>
                </tbody>
              </table>
              <div className="text-center my-3">
                <p onClick={() => setEdit(true)} className="text-base cursor-pointer text-indigo-500 italic hover:underline hover:text-indigo-600 font-medium">
                  แก้ไขข้อมูลส่วนตัว
                </p>
              </div>
            </div>
          </Fragment>
        )}
      </div>
    </Modal>
  );
}
