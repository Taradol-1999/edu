import React, { Fragment, useEffect, useState } from "react";
import CardBody from "@material-tailwind/react/CardBody";
import CardFooter from "@material-tailwind/react/CardFooter";
import { TextSearch } from "../../../../components/TextSearch";
import { SelectSearch } from "../../../../components/SelectSearch";
import DataUser from "./DataUser";
import Pagination from "../../../../components/Pagination";
import { SelectPageSize } from "../../../../components/SelectPageSize";
import SVGAdd from "../../../../SVGS/SVGAdd";
import Swal from "sweetalert2";
import { DElALERT, MESSAGESUCCESS, STATUSERROR } from "../../../../components/alert";
import { DelUser, LoadUser } from "../../../../services/User.services";
import { pageSize, typeUser } from "../../../../helper/data";
import { useHistory } from "react-router-dom";
import LoadingData from "../../../../components/LoadingData";
import { GetDropdown } from "../../../../services/Dropdown.services";

export default function MainUsers() {
  let history = useHistory();
  const [user, setUser] = useState([]);
  const [keyword, setKeyword] = useState("");
  const [typeRole, setTyperole] = useState("");
  const [facId, setFacId] = useState(0);
  const [maId, setMaId] = useState(0);
  const [major, setMajor] = useState([]);
  const [faculty, setFaculty] = useState([]);
  const [loading, setLoading] = useState(false);
  const [pagin, setPagin] = useState({
    currentPage: 1,
    pageSize: 10,
    totalRows: 0,
    totalPages: 0,
  });

  function DELETE(code) {
    Swal.fire(DElALERT).then(async (result) => {
      if (result.isConfirmed) {
        let res = await DelUser(code);
        if (res) {
          if (res.taskStatus && res.statusCode === 200) {
            MESSAGESUCCESS(res.message);
            loadData();
          } else {
            STATUSERROR();
          }
        }
      }
    });
  }
  useEffect(() => {
    loadData();
    loadDropdown();
  }, []);
  async function loadData(currentPage = 1, pageSize = 10, search = "", role = "", facId = 0, maId = 0) {
    setLoading(true);
    let res = await LoadUser(currentPage, pageSize, search, role, facId, maId);
    if (res) {
      if (res.statusCode === 200 && res.taskStatus) {
        setTyperole(role);
        setKeyword(search);
        setMaId(maId);
        setFacId(facId);
        setPagin(res.pagin);
        setUser(res.data);
        setLoading(false);
      }
    }
  }
  async function loadDropdown() {
    let result = await GetDropdown();
    setMajor(result.majors);
    setFaculty(result.faculty);
  }
  function reset() {
    loadData(1, 10, "", "", 0, 0);
  }
  return (
    <Fragment>
      <form onSubmit={(e) => e.preventDefault()}>
        <p className="text-blue-800 underline">ข้อมูลผู้ใช้งาน</p>
        <div className="items-center mt-5 p-2 bg-white rounded  hover:shadow-lg duration-300">
          <div className="grid lg:grid-cols-12 md:grid-cols-6 sm:grid-cols-2 md:gap-0 gap-2">
            <div className="lg:col-span-4 md:col-span-4">
              <TextSearch
                placeholder="ค้นหา_รหัส_ชื่อ_เบอร์โทร"
                onChange={(e) => {
                  setKeyword(e.target.value.trim());
                }}
                value={keyword}
              />
            </div>
            <div className="lg:col-span-2 md:col-span-2">
              <SelectSearch
                placeholder="ประเภทผู้ใช้งาน"
                options={typeUser}
                value={typeUser.filter((x) => x.id === typeRole)}
                getOptionLabel={(x) => x.name}
                getOptionValue={(x) => x.id}
                onChange={(e) => {
                  setTyperole(e.id);
                  setFacId(0);
                  setMaId(0);
                }}
              />
            </div>
            <div className={typeRole !== "" && typeRole !== "1" ? "lg:col-span-2 md:col-span-3" : "hidden"}>
              <SelectSearch
                placeholder="ค้นหา_คณะ"
                options={faculty}
                value={faculty.filter((x) => x.facultyId === facId)}
                getOptionLabel={(x) => x.facultyName}
                getOptionValue={(x) => x.facultyId}
                onChange={(e) => {
                  setFacId(e.facultyId);
                  setMaId(0);
                }}
              />
            </div>
            <div className={facId !== 0 && typeRole !== "" && typeRole !== "1" ? "lg:col-span-2 md:col-span-3" : "hidden"}>
              <SelectSearch
                placeholder="ค้นหา_สาขา"
                options={major.filter((x) => x.facultyId === facId)}
                value={major.filter((x) => x.majorId === maId)}
                getOptionLabel={(x) => x.majorName}
                getOptionValue={(x) => x.majorId}
                onChange={(e) => {
                  setMaId(e.majorId);
                }}
              />
            </div>
            <div className="flex">
              <button
                className="buttonSearch"
                type="submit"
                onClick={() => {
                  loadData(1, pagin.pageSize, keyword, typeRole, facId, maId);
                }}
              >
                <span>ค้นหา</span>
              </button>
              <button
                className="buttonReset"
                type="reset"
                onClick={() => {
                  reset();
                }}
              >
                <span>ล้างค่า</span>
              </button>
            </div>
          </div>
        </div>
      </form>

      <div className="flex justify-between mt-5">
        <SelectPageSize
          options={pageSize}
          getOptionLabel={(x) => x.name}
          getOptionValue={(x) => x.id}
          value={pageSize.filter((a) => a.id === pagin.pageSize)}
          onChange={(e) => {
            loadData(1, e.id, keyword, "");
          }}
        />
        <div className="flex justify-end">
          <button
            className="buttonAdd"
            onClick={() => {
              history.push("/MainUsers/FromUser");
            }}
          >
            <SVGAdd width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> เพิ่มข้อมูล
          </button>
        </div>
      </div>

      <CardBody>
        {loading ? (
          <div className="flex justify-center bg-transparent mt-52">
            <LoadingData />
          </div>
        ) : (
          <div className="overflow-auto">
            <DataUser
              pagin={pagin}
              user={user}
              loading={loading}
              retrunPageNumber={(number) => {
                loadData(number, pagin.pageSize, keyword, typeRole);
              }}
              retrunDelete={(code) => {
                DELETE(code);
              }}
            />
          </div>
        )}
      </CardBody>
      <CardFooter>
        <Pagination
          totalPage={pagin.pageCount}
          onChange={async (page) => {
            loadData(page, pagin.pageSize, keyword, typeRole);
          }}
          currentPages={pagin.currentPage}
          totalRow={pagin.rowCount}
        />
      </CardFooter>
    </Fragment>
  );
}
