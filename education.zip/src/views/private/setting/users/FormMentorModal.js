import React from "react";
import Modal from "../../../../components/Modal";
import { useState } from "react";
import { LoadMentorById, UpdateMentor } from "../../../../services/Mentor.services";
import { useEffect } from "react";
import SVGReset from "../../../../SVGS/SVGReset";
import SVGSave from "../../../../SVGS/SVGSave";
import SVGLoading from "../../../../SVGS/SVGLoading";
import { TextSelect } from "../../../../components/TextSelect";
import { TextFieldPassword } from "../../../../components/TextFieldPassword";
import { TextField } from "../../../../components/TextField";
import { Form, Formik } from "formik";
import { validateMentor } from "../../register/Validate";
import { Fragment } from "react";
import { GetDropdown } from "../../../../services/Dropdown.services";
import { MESSAGEERROR, MESSAGESUCCESS } from "../../../../components/alert";

export default function FormMentorModal({ openUser, setOpenUser }) {
  const [mentorDetail, setMentorDetail] = useState(null);
  const [title, setPrefix] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (openUser) loadMentorById(openUser);
  }, [openUser]);

  async function loadMentorById(id) {
    let res = await LoadMentorById(id);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        setMentorDetail(res.data);
      }
    }
  }

  useEffect(() => {
    loadDropdown();
  }, []);

  async function loadDropdown() {
    let result = await GetDropdown();
    if (result) {
      setPrefix(result.title);
    }
  }

  const SAVE = async (values) => {
    setLoading(true);
    let res = await UpdateMentor(values);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        MESSAGESUCCESS(res.message);
      } else {
        MESSAGEERROR(res.message);
      }
    }
    setLoading(false);
  };

  return (
    <Modal
      width="max-w-[50rem]"
      title={`ข้อมูลผู้ใช้งาน `}
      subTitle={`ครูพี่เลี้ยง`}
      isOpen={openUser ? true : false}
      onClose={() => {
        setOpenUser(false);
      }}
    >
      <Fragment>
        <Formik
          validationSchema={validateMentor}
          initialValues={{
            mentorId: mentorDetail ? mentorDetail.mentorId : 0,
            preFix: mentorDetail ? mentorDetail.preFix : "",
            firstName: mentorDetail ? mentorDetail.firstName : "",
            lastName: mentorDetail ? mentorDetail.lastName : "",
            phone: mentorDetail ? mentorDetail.phone : "",
            passWord: mentorDetail ? mentorDetail.password : "",
            groupId: mentorDetail?.groupId,
            schoolId: mentorDetail?.schoolId,
          }}
          enableReinitialize={true}
          onSubmit={async (values) => {
            await SAVE(values);
          }}
        >
          {({ values, setFieldValue, handleChange }) => (
            <Form>
              <div className="flex flex-wrap my-2">
                <div className="md:w-2/12">
                  <TextSelect
                    title="คำนำหน้าชื่อ"
                    options={title}
                    name="preFix"
                    value={title.filter((x) => x.titleId === values.preFix)}
                    placeholder="คำนำหน้าชื่อ"
                    getOptionLabel={(x) => x.titleName}
                    getOptionValue={(x) => x.titleId}
                    onChange={(e) => {
                      setFieldValue("preFix", e.titleId);
                    }}
                  />
                </div>
                <div className="md:w-5/12">
                  <TextField name="firstName" value={values.firstName} title="ชื่อ" placeholder="ชื่อ" onChange={handleChange} type="text" />
                </div>
                <div className="md:w-5/12">
                  <TextField name="lastName" value={values.lastName} title="นามสกุล" placeholder="นามสกุล" onChange={handleChange} type="text" />
                </div>
                <div className="md:w-5/12">
                  <TextField name="phone" value={values.phone} title="เบอร์โทรศัพท์มือถือ" placeholder="เบอร์โทรศัพท์มือถือ" onChange={handleChange} type="text" />
                </div>
                <div className="md:w-5/12">
                  <TextFieldPassword
                    name="passWord"
                    value={values.passWord}
                    title="รหัสผ่าน"
                    placeholder="รหัสผ่าน"
                    onChange={(e) => {
                      setFieldValue("passWord", e.target.value);
                    }}
                    type="text"
                  />
                </div>
              </div>
              <div className="w-full px-2">
                <div className="flex gap-3 justify-center my-5">
                  <button className={loading ? "buttonSave_disabled cursor-no-drop" : "buttonSave"} type="submit" disabled={loading ? true : false}>
                    {loading ? (
                      <div className="flex items-center justify-center text-center">
                        <SVGLoading width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" />
                        บันทึก
                      </div>
                    ) : (
                      <div className="flex items-center justify-center text-center">
                        <SVGSave width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> บันทึก
                      </div>
                    )}
                  </button>
                  <button className="buttonResetV1" type="reset">
                    <SVGReset width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> ล้างค่า
                  </button>
                </div>
              </div>
            </Form>
          )}
        </Formik>
      </Fragment>
    </Modal>
  );
}
