import React, { Fragment, useState } from "react";
import { Form, Formik } from "formik";
import { TextSelect } from "../../../../components/TextSelect";
import { TextField } from "../../../../components/TextField";
import SVGLoading from "../../../../SVGS/SVGLoading";
import SVGSave from "../../../../SVGS/SVGSave";
import SVGReset from "../../../../SVGS/SVGReset";
import { CreateMajor } from "../../../../services/User.services";
import { MESSAGEERROR, MESSAGESUCCESS } from "../../../../components/alert";
import { validateMajor } from "./validate";

export default function FromMajor({ faculty, setIsOpen, loadDropdown }) {
  const [loading, setLoading] = useState(false);

  const SAVE = async (values) => {
    setLoading(true);
    let res = await CreateMajor(values);
    if (res) {
      if (res.statusCode === 200 && res.taskStatus) {
        MESSAGESUCCESS(res.message);
        setIsOpen(false);
        loadDropdown();
      } else {
        MESSAGEERROR(res.message);
      }
    }
    setLoading(false);
  };
  return (
    <Fragment>
      <Formik
        initialValues={{
          majorName: "",
          facultyID: "",
        }}
        validationSchema={validateMajor}
        enableReinitialize={true}
        onSubmit={async (values) => {
          SAVE(values);
        }}
      >
        {({ values, setFieldValue }) => (
          <Form>
            <div className="bg-white">
              <div className="w-full">
                <TextSelect
                  title="คณะ"
                  options={faculty}
                  name="facultyID"
                  value={faculty.filter((x) => x.facultyId === values.facultyID)}
                  placeholder="คณะ"
                  getOptionLabel={(x) => x.facultyName}
                  getOptionValue={(x) => x.facultyId}
                  onChange={(e) => {
                    setFieldValue("facultyID", e.facultyId);
                  }}
                />
              </div>
              <div className="w-full">
                <TextField
                  name="majorName"
                  value={values.majorName}
                  title="ชื่อสาขา"
                  placeholder="ชื่อสาขา"
                  onChange={(e) => {
                    setFieldValue("majorName", e.target.value);
                  }}
                  type="text"
                />
              </div>
              <div className="flex gap-3 justify-center my-5">
                <button className={loading ? "buttonSave cursor-no-drop" : "buttonSave"} type="submit" disabled={loading}>
                  {loading ? (
                    <div className="flex items-center justify-center text-center">
                      <SVGLoading width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" />
                      บันทึก
                    </div>
                  ) : (
                    <div className="flex items-center justify-center text-center">
                      <SVGSave width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> บันทึก
                    </div>
                  )}
                </button>
                <button className="buttonResetV1" type="reset">
                  <SVGReset width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> ล้างค่า
                </button>
              </div>
            </div>
          </Form>
        )}
      </Formik>
    </Fragment>
  );
}
