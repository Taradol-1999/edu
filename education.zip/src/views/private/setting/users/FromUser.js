import React, { Fragment, useState, useEffect } from "react";
import { Formik, Form } from "formik";
import SVGSave from "../../../../SVGS/SVGSave";
import SVGReset from "../../../../SVGS/SVGReset";
import { useHistory } from "react-router-dom";
import { TextField } from "../../../../components/TextField";
import { validateUser } from "./validate";
import { SaveUser, LoadByUserId, UpdateUser } from "../../../../services/User.services";
import { MESSAGEERROR, MESSAGESUCCESS } from "../../../../components/alert";
import SVGLoading from "../../../../SVGS/SVGLoading";
import { TextSelect } from "../../../../components/TextSelect";
import { GetDropdown } from "../../../../services/Dropdown.services";
import { typeUser } from "../../../../helper/data";
import FromMajor from "./FromMajor";
import SVGAdd from "../../../../SVGS/SVGAdd";
import FormPerfix from "./FormPerfix";
import BtnGoBack from "../../../../components/BtnGoBack";
import Modal from "../../../../components/Modal";
import { TextFieldPassword } from "../../../../components/TextFieldPassword";

export default function FromUser() {
  let history = useHistory();
  let id = new URLSearchParams(history.location.search).get("id");
  const user = JSON.parse(localStorage.getItem("users"));
  let [isOpen, setIsOpen] = useState(false);
  let [isOpenPerfix, setIsOpenPerfix] = useState(false);
  const [loading, setLoading] = useState(false);
  const [detail, setDetail] = useState([]);
  const [major, setMajor] = useState([]);
  const [faculty, setFaculty] = useState([]);
  const [title, setPrefix] = useState([]);
  useEffect(() => {
    if (id) {
      loadDetail(id);
    }
    loadDropdown();
  }, [id]);
  async function loadDetail(id) {
    let result = await LoadByUserId(id);
    setDetail(result.data);
  }
  async function loadDropdown() {
    let result = await GetDropdown();
    setMajor(result.majors);
    setFaculty(result.faculty);
    setPrefix(result.title);
  }
  const SAVE = async (values) => {
    let data = { ...values };
    data.majorId = data.majorId ? data.majorId : null;
    setLoading(true);
    let res = data.userId ? await UpdateUser(data) : await SaveUser(data);
    if (res) {
      if (res.statusCode === 200 && res.taskStatus) {
        history.goBack();
        MESSAGESUCCESS(res.message);
      } else {
        MESSAGEERROR(res.message);
      }
    }

    setLoading(false);
  };
  return (
    <Fragment>
      <Formik
        initialValues={{
          userId: detail.userId ? detail.userId : "",
          preFix: detail.preFix ? detail.preFix : "",
          firstName: detail.firstName ? detail.firstName : "",
          lastName: detail.lastName ? detail.lastName : "",
          phone: detail.phone ? detail.phone : "",
          userName: detail.userName ? detail.userName : "",
          passWord: detail.passWord ? detail.passWord : "",
          facultyId: detail.facultyId ? detail.facultyId : "",
          majorId: detail.majorId ? detail.majorId : "",
          role: detail.role ? detail.role : "",
        }}
        validationSchema={validateUser}
        enableReinitialize={true}
        onSubmit={async (values) => {
          SAVE(values);
        }}
      >
        {({ values, setFieldValue, handleChange }) => (
          <Form>
            <div className="flex flex-wrap mx-auto ">
              <div className="w-full flex justify-between items-end">
                <p className="text-blue-900 text-lg">เพิ่มผู้ใช้งาน</p>
                <div className="flex">
                  <button
                    type="button"
                    className={user.role !== "1" ? "hidden" : "buttonAdd mr-2"}
                    onClick={() => {
                      setIsOpenPerfix(true);
                    }}
                  >
                    <SVGAdd width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> เพิ่มคำนำหน้าชื่อ
                  </button>
                  <button
                    type="button"
                    className={user.role !== "1" ? "hidden" : "buttonAdd mr-2"}
                    onClick={() => {
                      setIsOpen(true);
                    }}
                  >
                    <SVGAdd width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> เพิ่มสาขา
                  </button>
                  <BtnGoBack onClick={() => history.goBack()} />
                </div>
              </div>
            </div>
            <div className="mt-2 border-b border-gray-400" />
            <div className="w-full my-3">
              <div className="flex flex-wrap">
                <div className="md:w-2/12">
                  <TextSelect
                    title="คำนำหน้าชื่อ"
                    options={title}
                    name="preFix"
                    value={title.filter((x) => x.titleId === values.preFix)}
                    placeholder="คำนำหน้าชื่อ"
                    getOptionLabel={(x) => x.titleName}
                    getOptionValue={(x) => x.titleId}
                    onChange={(e) => {
                      setFieldValue("preFix", e.titleId);
                    }}
                  />
                </div>
                <div className="md:w-5/12">
                  <TextField name="firstName" value={values.firstName} title="ชื่อ" placeholder="ชื่อ" onChange={handleChange} type="text" />
                </div>
                <div className="md:w-5/12">
                  <TextField name="lastName" value={values.lastName} title="นามสกุล" placeholder="นามสกุล" onChange={handleChange} type="text" />
                </div>
                <div className="md:w-2/12">
                  <TextField name="phone" value={values.phone} title="เบอร์โทร" placeholder="เบอร์โทร" onChange={handleChange} type="text" />
                </div>
                <div className="md:w-5/12">
                  <TextSelect
                    title="ประเภทผู้ใช้งาน"
                    options={typeUser}
                    name="role"
                    value={typeUser.filter((x) => x.id === values.role)}
                    placeholder="ประเภทผู้ใช้งาน"
                    getOptionLabel={(x) => x.name}
                    getOptionValue={(x) => x.id}
                    onChange={(e) => {
                      setFieldValue("role", e.id);
                      setFieldValue("facultyId", "");
                      setFieldValue("majorId", "");
                    }}
                  />
                </div>
                <div className={values.role === "1" ? "hidden" : "md:w-2/12"}>
                  <TextSelect
                    title="คณะ"
                    options={faculty}
                    name="facultyId"
                    value={faculty.filter((x) => x.facultyId === values.facultyId)}
                    placeholder="คณะ"
                    getOptionLabel={(x) => x.facultyName}
                    getOptionValue={(x) => x.facultyId}
                    onChange={(e) => {
                      setFieldValue("facultyId", e.facultyId);
                      setFieldValue("majorId", "");
                    }}
                  />
                </div>
                <div className={values.role === "1" ? "hidden" : "md:w-3/12"}>
                  <TextSelect
                    options={major.filter((x) => x.facultyId === values.facultyId)}
                    name="majorId"
                    title="สาขา"
                    value={major.filter((x) => x.majorId === values.majorId)}
                    placeholder="สาขา"
                    getOptionLabel={(x) => x.majorName}
                    getOptionValue={(x) => x.majorId}
                    onChange={(e) => {
                      setFieldValue("majorId", e.majorId);
                    }}
                  />
                </div>
                <div className="md:w-6/12">
                  <TextField name="userName" value={values.userName} title={values.role !== "3" ? "ชื่อผู้ใช้(อีเมล)" : "รหัสนักศึกษา"} placeholder="ชื่อผู้ใช้" onChange={handleChange} type="text" />
                </div>
                <div className="md:w-6/12">
                  <TextFieldPassword name="passWord" value={values.passWord} title="รหัสผ่าน" placeholder="รหัสผ่าน" onChange={handleChange} type="text" />
                </div>
              </div>
              <div className="flex gap-3 justify-center my-5">
                <button className={loading ? "buttonSave cursor-no-drop" : "buttonSave"} type="submit" disabled={loading}>
                  {loading ? (
                    <div className="flex items-center justify-center text-center">
                      <SVGLoading width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" />
                      บันทึก
                    </div>
                  ) : (
                    <div className="flex items-center justify-center text-center">
                      <SVGSave width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> บันทึก
                    </div>
                  )}
                </button>
                <button className="buttonResetV1" type="reset">
                  <SVGReset width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> ล้างค่า
                </button>
              </div>
            </div>
          </Form>
        )}
      </Formik>
      <Modal
        width="max-w-lg"
        isOpen={isOpen}
        title="เพิ่มสาขา"
        onClose={() => {
          setIsOpen(false);
        }}
      >
        <div className="inline-block w-full max-w-lg overflow-hidden transform bg-transparent rounded text-left">
          <FromMajor faculty={faculty} setIsOpen={setIsOpen} loadDropdown={loadDropdown} />
        </div>
      </Modal>
      <Modal
        width="max-w-lg"
        title="เพิ่มคำนำหน้าชื่อ"
        isOpen={isOpenPerfix}
        onClose={() => {
          setIsOpenPerfix(false);
        }}
      >
        <div className="inline-block w-full max-w-lg overflow-hidden transform bg-transparent rounded text-left">
          <FormPerfix setIsOpenPerfix={setIsOpenPerfix} loadDropdown={loadDropdown} />
        </div>
      </Modal>
    </Fragment>
  );
}
