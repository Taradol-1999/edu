import React, { Fragment, useState, useEffect } from "react";
import { Formik, Form, ErrorMessage } from "formik";
import SVGSave from "../../../../SVGS/SVGSave";
import SVGReset from "../../../../SVGS/SVGReset";
import { useHistory } from "react-router-dom";
import { TextField } from "../../../../components/TextField";
import { TextSelect } from "../../../../components/TextSelect";
import { elementary, status } from "../../../../data/school";
import { TextFieldArea } from "../../../../components/TextFieldArea";
import { validateRegisterSchool } from "./ValidateSchool";
import SVGImage from "../../../../SVGS/SVGImage";
import { MESSAGEERROR, MESSAGESUCCESS } from "../../../../components/alert";
import { SaveSchool, SchoolsDetail, UpdateSchools } from "../../../../services/School.services";
import SVGLoading from "../../../../SVGS/SVGLoading";
import BtnGoBack from "../../../../components/BtnGoBack";

export default function FromSchool() {
  let history = useHistory();
  let id = new URLSearchParams(history.location.search).get("id");
  const [loading, setLoading] = useState(false);
  const [hidImg, setHidImg] = useState(true);
  const [detail, setDetail] = useState([]);
  useEffect(() => {
    if (id) {
      loadDetail(id);
    }
  }, [id]);
  async function loadDetail(id) {
    let result = await SchoolsDetail(id);
    setDetail(result.data);
  }
  const SAVE = async (values) => {
    setLoading(true);
    let res = values.schoolId ? await UpdateSchools(values) : await SaveSchool(values);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        history.push("/Mainschools");
        MESSAGESUCCESS(res.message);
      } else {
        MESSAGEERROR(res.message);
      }
    }

    setLoading(false);
  };
  return (
    <Fragment>
      <Formik
        initialValues={{
          schoolId: detail.schoolId ? detail.schoolId : "",
          schoolName: detail.schoolName ? detail.schoolName : "",
          address: detail.address ? detail.address : "",
          statusElementary: detail.statusElementary ? detail.statusElementary : "",
          elementaryLevel: detail.elementaryLevel ? detail.elementaryLevel : "",
          statusHighSchool: detail.statusHighSchool ? detail.statusHighSchool : "",
          distance: detail.distance ? detail.distance : "",
          phone: detail.phone ? detail.phone : "",
          logo: detail.logo ? detail.logo : "",
        }}
        validationSchema={validateRegisterSchool}
        enableReinitialize={true}
        onSubmit={async (values) => {
          SAVE(values);
        }}
      >
        {({ touched, errors, values, setFieldValue, handleChange }) => (
          <Form>
            <div className="flex flex-wrap mx-auto ">
              <div className="w-full flex justify-between items-end">
                <p className="text-blue-900 text-lg">เพิ่มโรงเรียน</p>
                <BtnGoBack onClick={() => history.goBack()} />
              </div>
            </div>
            <div className="mt-2 border-b border-gray-400" />
            <div className="flex flex-wrap mt-5">
              <div className="flex flex-wrap md:w-3/12 p-8">
                <div className="w-full text-center">
                  <label className="truncate">ตราสถานศึกษา</label>
                  <div
                    className={`cursor-pointer flex justify-center items-center pt-2 border-2 border-dashed rounded-md w-full h-full ${
                      touched.logo
                        ? errors.logo
                          ? "border-2 border-red-500 hover:bg-red-100 bg-red-50"
                          : "border-2 border-green-500 hover:bg-green-100 bg-green-50"
                        : "border-2 border-blue-800 hover:bg-gray-100 bg-gray-50 "
                    }`}
                    onClick={() => {
                      document.getElementById("file-upload").click();
                    }}
                  >
                    <div>
                      {values.logo.length !== 0 ? (
                        <div className="flex flex-wrap justify-center items-center">
                          {values.logo !== "" && hidImg ? (
                            <img
                              alt={values.file_obj !== undefined ? values.file_obj : `${detail.logoUrl}?${Date.now()}`}
                              src={values.file_obj !== undefined ? values.file_obj : `${detail.logoUrl}?${Date.now()}`}
                              className="w-24 h-full"
                              onError={(e) => {
                                setHidImg(false);
                              }}
                            />
                          ) : values.file_obj === undefined || !hidImg ? (
                            <>
                              <SVGImage width="44" height="44" color="#000000" strokeWidth="1" className="flex justify-center items-center" />
                              <p className="text-xs tracking-wider text-gray-400 group-hover:text-gray-600">เลือกไฟล์รูปภาพ (PNG, JPG)</p>
                            </>
                          ) : (
                            <></>
                          )}
                        </div>
                      ) : (
                        <div className="flex justify-center items-end">
                          <SVGImage width="44" height="44" color="#000000" strokeWidth="1" />
                        </div>
                      )}

                      <div className="flex justify-center text-sm text-red-600">
                        <label className="cursor-pointer">
                          <span>อัพโหลดรูปภาพ</span>
                        </label>
                      </div>
                      <p className="text-xs text-center text-gray-500">.png .jpg .jpeg</p>
                    </div>
                  </div>
                  <div className="text-sm text-red-500">
                    <ErrorMessage component="div" name="logo" className="invalid-feedback" />
                  </div>
                </div>
              </div>
              <div className="flex flex-wrap md:w-9/12">
                <div className="md:w-9/12">
                  <TextField title="ชื่อสถานศึกษา" onChange={handleChange} name="schoolName" value={values.schoolName} type="text" placeholder="ชื่อสถานศึกษา" />
                </div>
                <div className="md:w-3/12">
                  <TextField title="เบอร์โทรศัพท์" onChange={handleChange} name="phone" value={values.phone} type="text" placeholder="เบอร์โทรศัพท์" />
                </div>
                <div className="md:w-3/12">
                  <TextField title="ระยะทางห่างจาก มหาลัย ถึง ร.ร." onChange={handleChange} name="distance" value={values.distance} type="text" placeholder="ระยะทางห่างจาก มหาลัย ถึง ร.ร." />
                </div>
                <div className="md:w-3/12">
                  <TextSelect
                    title="รับรอง สมศ. ประถมศึกษา"
                    options={status}
                    name="statusElementary"
                    value={status.filter((x) => x.id === values.statusElementary)}
                    placeholder="รับรอง สมศ. ประถมศึกษา"
                    getOptionLabel={(x) => x.name}
                    getOptionValue={(x) => x.id}
                    onChange={(e) => {
                      setFieldValue("statusElementary", e.id);
                    }}
                  />
                </div>
                <div className="md:w-3/12">
                  <TextSelect
                    title="ระดับชั้นการสอน"
                    options={elementary}
                    name="elementaryLevel"
                    value={elementary.filter((x) => x.name === values.elementaryLevel)}
                    placeholder="ระดับชั้นการสอน"
                    getOptionLabel={(x) => x.name}
                    getOptionValue={(x) => x.name}
                    onChange={(e) => {
                      setFieldValue("elementaryLevel", e.name);
                    }}
                  />
                </div>
                <div className="md:w-3/12">
                  <TextSelect
                    title="รับรอง สมศ. มัธยม"
                    options={status}
                    name="statusHighSchool"
                    value={status.filter((x) => x.id === values.statusHighSchool)}
                    placeholder="รับรอง สมศ. มัธยม"
                    getOptionLabel={(x) => x.name}
                    getOptionValue={(x) => x.id}
                    onChange={(e) => {
                      setFieldValue("statusHighSchool", e.id);
                    }}
                  />
                </div>
                <div className="md:w-full">
                  <TextFieldArea title="ที่อยู่" onChange={handleChange} name="address" value={values.address} type="text" placeholder="ที่อยู่" />
                </div>
              </div>
            </div>
            <div className="w-full px-2">
              <div className="flex gap-3 justify-center my-5">
                <button className={loading ? "buttonSave cursor-no-drop" : "buttonSave"} type="submit" disabled={loading}>
                  {loading ? (
                    <div className="flex items-center justify-center text-center">
                      <SVGLoading width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" />
                      บันทึก
                    </div>
                  ) : (
                    <div className="flex items-center justify-center text-center">
                      <SVGSave width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> บันทึก
                    </div>
                  )}
                </button>
                <button
                  className="buttonResetV1"
                  type="reset"
                  onClick={() => {
                    setLoading(false);
                  }}
                >
                  <SVGReset width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> ล้างค่า
                </button>
                <input
                  id="file-upload"
                  type="file"
                  className="sr-only"
                  name="logo"
                  accept="jpeg,png"
                  onChange={(e) => {
                    if (e.target.files.length !== 0) {
                      e.preventDefault();
                      setHidImg(true);
                      setFieldValue("file_name", e.target.files[0].name);
                      setFieldValue("file_obj", e.target.files[0] !== undefined ? URL.createObjectURL(e.target.files[0]) : "");
                      setFieldValue("logo", e.currentTarget.files[0]);
                    }
                  }}
                />
              </div>
            </div>
          </Form>
        )}
      </Formik>
    </Fragment>
  );
}
