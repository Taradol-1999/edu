import React, { Fragment, useEffect, useState } from "react";
import { useHistory } from "react-router-dom";
import { SchoolsDetail } from "../../../../services/School.services";

export default function DetailSchool() {
  let history = useHistory();
  const [detail, setDetail] = useState([]);
  let id = new URLSearchParams(history.location.search).get("id");
  useEffect(() => {
    if (id !== null) {
      loadDetail(id);
    }
  }, [id]);

  async function loadDetail(id) {
    let result = await SchoolsDetail(id);
    setDetail(result.data);
  }

  return (
    <Fragment>
      <section className="relative pt-12 bg-blueGray-50">
        <div className="items-center flex flex-wrap">
          <div className="w-full md:w-4/12 ml-auto mr-auto px-4">
            <img alt={detail.logoUrl} className="max-w-full" src={detail.logoUrl} />
          </div>
          <div className="w-full md:w-5/12 ml-auto mr-auto px-4">
            <div className="md:pr-12">
              <h3 className="text-3xl font-semibold">{"โรงเรียน " + detail.schoolName}</h3>
              <ul className="list-none mt-6">
                <li className="py-2">
                  <div className="flex items-center">
                    <div>
                      <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-pink-600 bg-pink-200 mr-3">
                        <i className="fas fa-fingerprint" />
                      </span>
                    </div>
                    <div>
                      <h4 className="text-blueGray-500">
                        <span className="text-xl font-black">ที่อยู่ : </span> {detail.address}
                      </h4>
                    </div>
                  </div>
                </li>
                <li className="py-2">
                  <div className="flex items-center">
                    <div>
                      <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-pink-600 bg-pink-200 mr-3">
                        <i className="fab fa-html5" />
                      </span>
                    </div>
                    <div>
                      <span className="text-xl font-black">เบอร์โทร : </span> {detail.phone ? detail.phone : "-"}
                    </div>
                  </div>
                </li>
                <li className="py-2">
                  <div className="flex items-center">
                    <div>
                      <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-pink-600 bg-pink-200 mr-3">
                        <i className="far fa-paper-plane" />
                      </span>
                    </div>
                    <div>
                      <span className="text-xl font-black">ระดับชั้นการสอน : </span> {detail.elementaryLevel}
                    </div>
                  </div>
                </li>
                <li className="py-2">
                  <div className="flex items-center">
                    <div>
                      <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-pink-600 bg-pink-200 mr-3">
                        <i className="far fa-paper-plane" />
                      </span>
                    </div>
                    <div>
                      <span className="text-xl font-black">รับรอง สมศ. ประถมศึกษา : </span> {detail.statusElementary === "1" ? "รับรอง" : "ไม่รับรอง"}
                    </div>
                  </div>
                </li>
                <li className="py-2">
                  <div className="flex items-center">
                    <div>
                      <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-pink-600 bg-pink-200 mr-3">
                        <i className="far fa-paper-plane" />
                      </span>
                    </div>
                    <div>
                      <span className="text-xl font-black">รับรอง สมศ. มัธยม : </span> {detail.statusHighSchool === "1" ? "รับรอง" : "ไม่รับรอง"}
                    </div>
                  </div>
                </li>
                <li className="py-2">
                  <div className="flex items-center">
                    <div>
                      <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-pink-600 bg-pink-200 mr-3">
                        <i className="far fa-paper-plane" />
                      </span>
                    </div>
                    <div>
                      <span className="text-xl font-black">ระยะทางจากมหาวิทยาลัยราชภัฏกาญจนบุรี : </span> {(detail.distance ? detail.distance : "-") + " กิโลเมตร"}
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>
    </Fragment>
  );
}
