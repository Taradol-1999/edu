import React, { Fragment } from "react";
import { useHistory } from "react-router-dom";
import ButtonDropdown from "../../../../components/ButtonDropdown";
export default function DataSchool({ retrunDelete, school, pagin }) {
  let history = useHistory();
  return (
    <Fragment>
      <table className="w-full bg-transparent">
        <thead>
          <tr>
            <th className="thead-th rounded-tl-lg">#</th>
            <th className="thead-th">รหัส</th>
            <th className="thead-th">ชื่อโรงเรียน</th>
            <th className="thead-th">เบอร์โทร</th>
            <th className="thead-th">ที่อยู่</th>
            <th className="thead-th rounded-tr-lg">จัดการข้อมูล</th>
          </tr>
        </thead>
        <tbody>
          {school.map((value, index) => (
            <tr key={index}>
              <th className="tbody-th">{(pagin.currentPage - 1) * pagin.pageSize + (index + 1)}</th>
              <th className="tbody-th">{value.schoolId}</th>
              <th className="tbody-th">
                <img className="inline object-cover w-10 h-10 mr-2 rounded-full" src={value.logoSchool} alt={value.logoSchool} />
                {value.schoolName}
              </th>
              <th className="tbody-th">{value.phone ? value.phone : "-"}</th>
              <th className="tbody-th">{value.address}</th>
              <th className="tbody-th">
                <ButtonDropdown
                  onClickEdit={() => {
                    history.push("/Mainschools/FromSchool?id=" + value.schoolId);
                  }}
                  onClickInfo={() => {
                    history.push("/Mainschools/DetailSchool?id=" + value.schoolId);
                  }}
                  onClickDelete={() => {
                    retrunDelete(value.schoolId);
                  }}
                />
              </th>
            </tr>
          ))}
        </tbody>
      </table>
    </Fragment>
  );
}
