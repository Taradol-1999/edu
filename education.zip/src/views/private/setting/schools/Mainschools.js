import React, { Fragment, useState, useEffect, useRef } from "react";
import Swal from "sweetalert2";
import CardBody from "@material-tailwind/react/CardBody";
import { TextSearch } from "../../../../components/TextSearch";
import DataSchool from "./DataSchool";
import SVGAdd from "../../../../SVGS/SVGAdd";
import { DElALERT, MESSAGESUCCESS, STATUSERROR } from "../../../../components/alert";
import { LoadSchool, DelSchool, PrintDataSchool } from "../../../../services/School.services";
import { SelectPageSize } from "../../../../components/SelectPageSize";
import { CardFooter } from "@material-tailwind/react";
import Pagination from "../../../../components/Pagination";
import { pageSize } from "../../../../helper/data";
import { useHistory } from "react-router-dom";
import LoadingData from "../../../../components/LoadingData";
import { useReactToPrint } from "react-to-print";
import PrintSchools from "./PrintSchools";
import SVGPrint from "../../../../SVGS/SVGPrint";
export default function Mainschools() {
  const componentRef = useRef();
  let history = useHistory();
  const [loading, setLoading] = useState(false);
  const [school, setSchool] = useState([]);
  const [keyword, setKeyword] = useState("");
  const [printSchool, setPrintSchool] = useState([]);
  const [pagin, setPagin] = useState({
    currentPage: 1,
    pageSize: 10,
    totalRows: 0,
    totalPages: 0,
  });

  function DELETE(code) {
    Swal.fire(DElALERT).then(async (result) => {
      if (result.isConfirmed) {
        let res = await DelSchool(code);
        if (res) {
          if (res.taskStatus && res.statusCode === 200) {
            MESSAGESUCCESS(res.message);
            loadData();
          } else {
            STATUSERROR();
          }
        }
      }
    });
  }
  useEffect(() => {
    loadData();
    PrintSchool();
  }, []);

  async function loadData(currentPage = 1, pageSize = 10, search = "") {
    setLoading(true);
    let res = await LoadSchool(currentPage, pageSize, search);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        setKeyword(search);
        setPagin(res.pagin);
        setSchool(res.data);
        setLoading(false);
      }
    }
  }
  function reset() {
    loadData(1, 10, "");
  }
  async function PrintSchool() {
    let res = await PrintDataSchool();
    setPrintSchool(res.data);
  }
  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
  });
  return (
    <Fragment>
      <div className="hidden">
        <div ref={componentRef}>
          <PrintSchools data={printSchool} />
        </div>
      </div>

      <p className="text-blue-800 underline">โรงเรียน</p>
      <div className="items-center mt-5 p-2 bg-white rounded hover:shadow-lg duration-300">
        <div className="grid lg:grid-cols-2 md:grid-cols-2 sm:grid-cols-2 md:gap-0 gap-2">
          <div className="lg:col-span-1 md:col-span-1">
            <TextSearch
              placeholder="ค้นหา_ชื่อโรงเรียน_เบอร์โทร"
              onChange={(e) => {
                setKeyword(e.target.value.trim());
              }}
              value={keyword}
            />
          </div>

          <div className="flex">
            <button
              className="buttonSearch"
              onClick={() => {
                loadData(1, pagin.pageSize, keyword);
              }}
              disabled={keyword === "" ? true : false}
            >
              <span>ค้นหา</span>
            </button>
            <button
              className="buttonReset"
              onClick={(e) => {
                reset();
              }}
            >
              <span>ล้างค่า</span>
            </button>
          </div>
        </div>
      </div>
      <div className="flex justify-between mt-5">
        <SelectPageSize
          options={pageSize}
          getOptionLabel={(x) => x.name}
          getOptionValue={(x) => x.id}
          value={pageSize.filter((a) => a.id === pagin.pageSize)}
          onChange={(e) => {
            loadData(1, e.id, keyword);
          }}
        />
        <div className="flex justify-end">
          <button
            className="buttonAdd"
            onClick={() => {
              history.push("/Mainschools/FromSchool");
            }}
          >
            <SVGAdd width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> เพิ่มข้อมูล
          </button>
          <button
            className="buttonPrint ml-2"
            onClick={() => {
              handlePrint();
            }}
          >
            <SVGPrint width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> ปริ้น
          </button>
        </div>
      </div>
      <CardBody>
        {loading ? (
          <div className="flex justify-center bg-transparent mt-52">
            <LoadingData />
          </div>
        ) : (
          <div className="overflow-auto">
            <DataSchool
              retrunPageNumber={(number) => {
                loadData(number, pagin.pageSize, keyword);
              }}
              keyword={keyword}
              pagin={pagin}
              school={school}
              retrunDelete={(code) => {
                DELETE(code);
              }}
            />
          </div>
        )}
      </CardBody>
      <CardFooter>
        <Pagination
          totalPage={pagin.pageCount}
          onChange={async (page) => {
            loadData(page, pagin.pageSize, keyword);
          }}
          currentPages={pagin.currentPage}
          totalRow={pagin.rowCount}
        />
      </CardFooter>
    </Fragment>
  );
}
