import React from "react";
import LOGOKRU from "../../../../assets/img/LOGO-KRU.png";

export default function PrintSchools({ data }) {
  return (
    <div className="page-a4">
      <p className="flex justify-center pt-3">
        <img src={LOGOKRU} alt="" className=" w-28 h-32" />
      </p>
      <div className="w-full pb-3">
        <p className="text-center font-bold text-[20px] ">รายชื่อโรงเรียนร่วมฝึกประสบการณ์วิชาชีพครู</p>
        <p className="text-center text-[18px]"> คณะครุศาสตร์ มหาวิทยาลัยราชภัฏกาญจนบุรี</p>
      </div>
      <div className="px-5">
        <table className="min-w-full ">
          <thead>
            <tr>
              <th className="school-list-thead" style={{ width: "2%" }}>
                ลำดับ
              </th>
              <th className="school-list-thead" style={{ width: "15%" }}>
                รายชื่อโรงเรียน
              </th>
              <th className="school-list-thead" style={{ width: "33%" }}>
                ที่อยู่
              </th>
              <th className="school-list-thead" style={{ width: "10%" }}>
                ระดับขั้นปฐมวัย
              </th>
              <th className="school-list-thead" style={{ width: "10%" }}>
                รับรองสมศ. ประถมศึกษา
              </th>
              <th className="school-list-thead" style={{ width: "10%" }}>
                ระดับชั้น
              </th>
              <th className="school-list-thead" style={{ width: "10%" }}>
                รับรองสมศ. มัธยม
              </th>
              <th className="school-list-thead" style={{ width: "10%" }}>
                ระยะกิโลเมตร
              </th>
            </tr>
          </thead>
          {data.map((value, index) => (
            <tbody key={index}>
              <tr>
                <td className="school-list-tbody" style={{ width: "2%" }}>
                  {index + 1}
                </td>
                <td className="school-list-tbody text-left px-2" style={{ width: "15%" }}>
                  {value.schoolName}
                </td>
                <td className="school-list-tbody text-left px-2" style={{ width: "33%" }}>
                  {value.address + (value.phone ? " (โทร : " + value.phone + ")" : "")}
                </td>
                <td className="school-list-tbody" style={{ width: "10%" }}>
                  {value.elementarySchool}
                </td>
                <td className="school-list-tbody" style={{ width: "10%" }}>
                  {value.statusElementary === "1" ? "รับรอง" : "ไม่รับรอง"}
                </td>
                <td className="school-list-tbody" style={{ width: "10%" }}>
                  {value.elementaryLevel}
                </td>
                <td className="school-list-tbody" style={{ width: "10%" }}>
                  {value.statusHighSchool === "1" ? "รับรอง" : "ไม่รับรอง"}
                </td>
                <td className="school-list-tbody" style={{ width: "10%" }}>
                  {value.distance ?? "-"}
                </td>
              </tr>
            </tbody>
          ))}
        </table>
      </div>
    </div>
  );
}
