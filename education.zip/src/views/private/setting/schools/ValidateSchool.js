import * as Yup from "yup";
export const phoneRegExp = /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/;

export const validateRegisterSchool = Yup.object({
  schoolName: Yup.string().required("***กรุณากรอกชื่อโรงเรียน***"),
  address: Yup.string().required("***กรุณากรอกที่อยู่***"),
  statusElementary: Yup.string().required("***กรุณาเลือกรับรอง สมศ. ประถมศึกษา***"),
  elementaryLevel: Yup.string().required("***กรุณาเลือกระดับชั้นการสอน***"),
  statusHighSchool: Yup.string().required("***กรุณาเลือกรับรอง สมศ. มัธยม***"),
  // phone: Yup.string().required("***กรุณากรอกเบอร์โทร***").matches(phoneRegExp, "***หมายเลขไม่ถูกต้อง***"),
});
