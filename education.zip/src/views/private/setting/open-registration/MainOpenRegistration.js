import React, { Fragment, useEffect, useState } from "react";
import Swal from "sweetalert2";
import { MESSAGESUCCESS } from "../../../../components/alert";
import DateTH from "../../../../components/Date/DateTH";
import ToggleButton from "../../../../components/ToggleButton";
import { GetRequestsPrivate, UpdateRequest } from "../../../../services/Request.services";
import SVGToggle from "../../../../SVGS/SVGToggle";
import { Dialog, Transition } from "@headlessui/react";
import Question from "../../../../assets/img/Question.gif";
import { MultipleDatepicker } from "../../../../components/MultipleDatepicker";
import SVGSave from "../../../../SVGS/SVGSave";
import SVGClose from "../../../../SVGS/SVGClose";
const MainOpenRegistration = () => {
  const [requests, setRequests] = useState([]);
  const [isOpen, setIsOpen] = useState(false);
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [values, setValues] = useState({
    requestId: 0,
    startDate: null,
    endDate: null,
    status: "",
  });

  useEffect(() => {
    GetRequests();
  }, []);

  async function GetRequests() {
    let res = await GetRequestsPrivate();
    if (res)
      if (res.statusCode) {
        setRequests(res.data);
      }
  }

  async function Updata(data) {
    let value = { ...data };
    value.startDate = startDate;
    value.endDate = endDate;
    if (data.status === "0") {
      if (startDate || endDate) {
        let toDay = new Date();
        if (toDay >= new Date(startDate)) {
          value.status = "1";
        } else {
          value.status = "0";
        }
        let res = await UpdateRequest(value);
        if (res.statusCode === 1) MESSAGESUCCESS("เปิดการใช้งานสำเร็จ");
        setIsOpen(false);
        GetRequests();
        setEndDate(null);
        setStartDate(null);
      } else {
        Swal.fire({
          text: "คุณระบุวันที่ หรือไม่ ?",
          imageUrl: Question,
          imageWidth: 140,
          imageHeight: 120,
          showCancelButton: true,
          cancelButtonColor: "#d33",
          cancelButtonText: "ยกเลิก",
          confirmButtonColor: "#01a53d",
          confirmButtonText: "เปิด",
          denyButtonColor: "#3085d6",
          showDenyButton: true,
          denyButtonText: `ระบุวันที่`,
        }).then(async (result) => {
          if (result.isConfirmed) {
            value.status = "1";
            let res = await UpdateRequest(value);
            if (res.statusCode === 1) MESSAGESUCCESS("เปิดการใช้งานสำเร็จ");
            setIsOpen(false);
            GetRequests();
            setEndDate(null);
            setStartDate(null);
          } else if (result.isDenied) {
            setIsOpen(true);
            setValues(value);
          }
        });
      }
    } else {
      Swal.fire({
        text: "คุณปิดการใช้งานใช่ หรือไม่ ?",
        imageUrl: Question,
        imageWidth: 140,
        imageHeight: 120,
        showCancelButton: true,
        cancelButtonColor: "#d33",
        cancelButtonText: "ยกเลิก",
        confirmButtonColor: "#01a53d",
        confirmButtonText: "ตกลง",
      }).then(async (result) => {
        if (result.isConfirmed) {
          value.status = "0";
          let res = await UpdateRequest(value);
          if (res.statusCode === 1) MESSAGESUCCESS("ปิดการใช้งานสำเร็จ");
          GetRequests();
          setEndDate(null);
          setStartDate(null);
        }
      });
    }
  }
  return (
    <Fragment>
      {requests.map((item, index) => (
        <div key={index} className={`bg-white rounded-[10px] mt-3 flex justify-between shadow  border-2 ${item.status === "1" ? "shadow-blue-300 border-blue-400" : "shadow-gray-200 border-gray-300"}`}>
          <div className=" p-4">
            <div className={`text-sm flex items-center gap-x-2 ${item.status === "1" ? "text-blue-400" : "text-gray-300"} `}>
              <SVGToggle width="28" height="28" color={item.status === "1" ? "#60a5fa" : "#d1d5db"} status={item.status === "1" ? "open" : "off"} strokeWidth="1.5" />
              {item.status === "1" ? "เปิด" : "ปิด"}
            </div>
            <div className={`${item.status === "1" ? "text-gray-900" : "text-gray-300 "} font-bold text-xl mb-2`}>{item.requestName}</div>
            <p className={item.startDate ? "text-red-600" : "hidden"}>
              <span className="font-bold"> *** เปิดตั้งแต่วันที่ &nbsp;</span>
              {item.startDate ? <DateTH date={item.startDate} type="date" /> : null} <span className="font-bold"> ถึง </span> {item.endDate ? <DateTH date={item.endDate} type="date" /> : null}
              ***
            </p>
          </div>
          <ToggleButton
            value={item.status === "1"}
            onClick={() => {
              Updata(item);
            }}
          />
        </div>
      ))}

      <Transition show={isOpen} as={Fragment}>
        <Dialog as="div" className="fixed inset-0 z-40 overflow-y-auto" onClose={() => setIsOpen(true)}>
          <div className="w-full min-h-screen px-4 text-center">
            <Transition.Child>
              <Dialog.Overlay className="fixed inset-0 bg-gray-900 opacity-20" />
            </Transition.Child>
            <span className="inline-block h-screen align-middle " aria-hidden="true">
              &#8203;
            </span>
            <Transition.Child as={Fragment} enter="transition ease-out duration-300" enterFrom="opacity-0 -translate-y-10" enterTo="opacity-100 -translate-y-0" leave="transition ease-in duration-200" leaveFrom="opacity-100 -translate-y-0" leaveTo="opacity-0 -translate-y-10">
              <div className="inline-block w-full max-w-lg overflow-hidden transform bg-transparent rounded">
                <div className="p-5 bg-white">
                  <p className="text-left font-bold">ระบุวันที่ เริ่ม - สิ้นสุด</p>
                  <MultipleDatepicker
                    placeholderStart="วันที่เริ่ม"
                    placeholderEnd="วันที่สิ้นสุด"
                    nameEnd="endDate"
                    nameStart="startDate"
                    onChangeStart={(e) => {
                      setStartDate(e.target.value);
                    }}
                    onChangeEnd={(e) => {
                      setEndDate(e.target.value);
                    }}
                    valueStart={startDate}
                    valueEnd={endDate}
                  />
                  <div className="flex gap-3 justify-center my-5 w-full">
                    <button className="buttonSave">
                      <div className="flex items-center justify-center text-center" onClick={() => Updata(values)}>
                        <SVGSave width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" />
                        บันทึก
                      </div>
                    </button>
                    <button className="buttonResetV1" type="reset" onClick={() => setIsOpen(false)}>
                      <SVGClose width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> ยกเลิก
                    </button>
                  </div>
                </div>
              </div>
            </Transition.Child>
          </div>
        </Dialog>
      </Transition>
    </Fragment>
  );
};

export default MainOpenRegistration;
