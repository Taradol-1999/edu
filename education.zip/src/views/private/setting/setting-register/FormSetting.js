import { Form, Formik } from "formik";
import React from "react";
import { Fragment } from "react";
import { useState } from "react";
import { useEffect } from "react";
import { useHistory, useLocation } from "react-router-dom";
import BtnGoBack from "../../../../components/BtnGoBack";
import { TextField } from "../../../../components/TextField";
import SVGLoading from "../../../../SVGS/SVGLoading";
import SVGSave from "../../../../SVGS/SVGSave";
import SVGReset from "../../../../SVGS/SVGReset";
import { MESSAGEERROR, MESSAGESUCCESS } from "../../../../components/alert";
import { DetailSettingregisters, SettingRegister, UpdateSettingregister } from "../../../../services/SettingRegister.services";
import { Validate } from "./Validate";
import ToggleSwitche from "../../../../components/ToggleSwitche";

export default function FormSetting() {
  let history = useHistory();
  let location = useLocation();
  const [loading, setLoading] = useState(false);
  const [detail, setDetail] = useState(null);
  useEffect(() => {
    if (location.state) {
      loadDetail(location.state);
    }
  }, [location.state]);

  async function loadDetail(id) {
    let result = await DetailSettingregisters(id);
    setDetail(result.data);
  }

  const SAVE = async (values) => {
    setLoading(true);
    let res = values.id ? await UpdateSettingregister(values) : await SettingRegister(values);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        history.push("/setting-register");
        MESSAGESUCCESS(res.message);
      } else {
        MESSAGEERROR(res.message);
      }
    }
    setLoading(false);
  };
  return (
    <Fragment>
      <Formik
        initialValues={{
          id: detail ? detail.id : 0,
          year: detail ? detail.year : "",
          semester: detail ? detail.semester : "",
          trainingStartDate: detail ? detail.trainingStartDate : "",
          trainingEndDate: detail ? detail.trainingEndDate : "",
          scorePercentageProfession: detail ? detail.scorePercentageProfession : "",
          scorePercentageMajor: detail ? detail.scorePercentageMajor : "",
          scorePercentageMentor: detail ? detail.scorePercentageMentor : "",
          status: detail ? detail.status : "1",
        }}
        validationSchema={Validate}
        enableReinitialize={true}
        onSubmit={async (values) => {
          SAVE(values);
        }}
      >
        {({ touched, errors, values, setFieldValue, handleChange }) => (
          <Form>
            <div className="flex flex-wrap mx-auto ">
              <div className="w-full flex justify-between items-end">
                <p className="text-blue-900 text-lg">เพิ่มตั้งค่าการลงทะเบียน</p>
                <BtnGoBack onClick={() => history.goBack()} />
              </div>
            </div>
            <div className="mt-2 border-b border-gray-400" />
            <div className="flex flex-wrap mt-5">
              <div className="md:w-2/12">
                <TextField
                  title="ภาคการศึกษา"
                  onChange={(e) => {
                    setFieldValue("semester", e.target.value);
                  }}
                  name="semester"
                  value={values.semester}
                  type="text"
                  placeholder="ภาคการศึกษา"
                />
              </div>
              <div className="md:w-2/12">
                <TextField
                  title="ปีการศึกษา"
                  onChange={(e) => {
                    setFieldValue("year", e.target.value);
                  }}
                  name="year"
                  value={values.year}
                  type="text"
                  placeholder="ปีการศึกษา"
                />
              </div>
              <div className="md:w-4/12">
                <TextField
                  name="trainingStartDate"
                  value={values.trainingStartDate}
                  title="วันที่เริ่มฝึก"
                  placeholder="เริ่มฝึก"
                  onChange={(e) => {
                    setFieldValue("trainingStartDate", e.target.value);
                  }}
                  type="date"
                />
              </div>
              <div className="md:w-4/12">
                <TextField
                  name="trainingEndDate"
                  value={values.trainingEndDate}
                  title="วันที่สิ้นสุดฝึก"
                  placeholder="ฝึกสำเร็จ"
                  onChange={(e) => {
                    setFieldValue("trainingEndDate", e.target.value);
                  }}
                  type="date"
                />
              </div>
              <div className="md:w-4/12">
                <TextField
                  title="คะแนนจากอาจารย์นิเทศก์วิชาเอก (%)"
                  onChange={(e) => {
                    setFieldValue("scorePercentageMajor", e.target.value);
                  }}
                  name="scorePercentageMajor"
                  value={values.scorePercentageMajor}
                  type="number"
                  placeholder="คะแนนจากอาจารย์นิเทศก์วิชาเอก"
                />
              </div>
              <div className="md:w-4/12">
                <TextField
                  title="คะแนนจากอาจารย์นิเทศก์วิชาชีพครู (%)"
                  onChange={(e) => {
                    setFieldValue("scorePercentageProfession", e.target.value);
                  }}
                  name="scorePercentageProfession"
                  value={values.scorePercentageProfession}
                  type="number"
                  placeholder="คะแนนจากอาจารย์นิเทศก์วิชาชีพครู"
                />
              </div>
              <div className="md:w-4/12">
                <TextField
                  title="คะแนนจากครูพี้เลี้ยง (%)"
                  onChange={(e) => {
                    setFieldValue("scorePercentageMentor", e.target.value);
                  }}
                  name="scorePercentageMentor"
                  value={values.scorePercentageMentor}
                  type="number"
                  placeholder="คะแนนจากครูพี้เลี้ยง"
                />
              </div>
              <div className="md:w-1/12 pl-1">
                <ToggleSwitche
                  title="สถานะ"
                  checked={values.status === "1"}
                  name="status"
                  onChange={(e) => {
                    setFieldValue("status", e.target.checked ? "1" : "2");
                  }}
                />
              </div>
            </div>
            <div className="w-full px-2">
              <p className="text-red-600 text-base font-bold my-5">หมายเหตุ : ผลรวมของคะแนนต้องจะเท่ากับ 100 *</p>
              <div className="flex gap-3 justify-center my-5">
                <button className={loading ? "buttonSave cursor-no-drop" : "buttonSave"} type="submit" disabled={loading}>
                  {loading ? (
                    <div className="flex items-center justify-center text-center">
                      <SVGLoading width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" />
                      บันทึก
                    </div>
                  ) : (
                    <div className="flex items-center justify-center text-center">
                      <SVGSave width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> บันทึก
                    </div>
                  )}
                </button>
                <button
                  className="buttonResetV1"
                  type="reset"
                  onClick={() => {
                    setLoading(false);
                  }}
                >
                  <SVGReset width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> ล้างค่า
                </button>
              </div>
            </div>
          </Form>
        )}
      </Formik>
    </Fragment>
  );
}
