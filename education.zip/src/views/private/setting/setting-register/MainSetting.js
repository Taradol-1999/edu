import React from "react";
import Pagination from "../../../../components/Pagination";
import { Fragment } from "react";
import { TextSearch } from "../../../../components/TextSearch";
import { SelectPageSize } from "../../../../components/SelectPageSize";
import SVGAdd from "../../../../SVGS/SVGAdd";
import { CardBody, CardFooter } from "@material-tailwind/react";
import LoadingData from "../../../../components/LoadingData";
import { pageSize } from "../../../../helper/data";
import { useEffect } from "react";
import { DElALERT, MESSAGESUCCESS, STATUSERROR } from "../../../../components/alert";
import { useState } from "react";
import { useHistory } from "react-router-dom";
import Swal from "sweetalert2";
import { DeteleSettingregister, GetSettingregisters } from "../../../../services/SettingRegister.services";
import DataSetting from "./DataSetting";

export default function MainSetting() {
  let history = useHistory();
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState([]);
  const [keyword, setKeyword] = useState("");
  const [pagin, setPagin] = useState({
    currentPage: 1,
    pageSize: 10,
    totalRows: 0,
    totalPages: 0,
  });

  function DELETE(code) {
    Swal.fire(DElALERT).then(async (result) => {
      if (result.isConfirmed) {
        let res = await DeteleSettingregister(code);
        if (res) {
          if (res.taskStatus && res.statusCode === 200) {
            MESSAGESUCCESS(res.message);
            loadData();
          } else {
            STATUSERROR();
          }
        }
      }
    });
  }

  useEffect(() => {
    loadData();
  }, []);

  async function loadData(currentPage = 1, pageSize = 10, search = "") {
    setLoading(true);
    let res = await GetSettingregisters(currentPage, pageSize, search);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        setKeyword(search);
        setPagin(res.pagin);
        setData(res.data);
        setLoading(false);
      }
    }
  }
  function reset() {
    loadData(1, 10, "");
  }

  // console.log(100 * (35 / 100));
  // console.log(100 * (35 / 100));
  // console.log(100 * (30 / 100));
  return (
    <Fragment>
      <p className="text-blue-800 underline">ตั้งค่าการลงทะเบียน</p>
      <div className="items-center mt-5 p-2 bg-white rounded hover:shadow-lg duration-300">
        <div className="grid lg:grid-cols-2 md:grid-cols-2 sm:grid-cols-2 md:gap-0 gap-2">
          <div className="lg:col-span-1 md:col-span-1">
            <TextSearch
              placeholder="ค้นหา"
              onChange={(e) => {
                setKeyword(e.target.value.trim());
              }}
              value={keyword}
            />
          </div>

          <div className="flex">
            <button
              className="buttonSearch"
              onClick={() => {
                loadData(1, pagin.pageSize, keyword);
              }}
              disabled={keyword === "" ? true : false}
            >
              <span>ค้นหา</span>
            </button>
            <button
              className="buttonReset"
              onClick={(e) => {
                reset();
              }}
            >
              <span>ล้างค่า</span>
            </button>
          </div>
        </div>
      </div>
      <div className="flex justify-between mt-5">
        <SelectPageSize
          options={pageSize}
          getOptionLabel={(x) => x.name}
          getOptionValue={(x) => x.id}
          value={pageSize.filter((a) => a.id === pagin.pageSize)}
          onChange={(e) => {
            loadData(1, e.id, keyword);
          }}
        />
        <div className="flex justify-end">
          <button
            className="buttonAdd"
            onClick={() => {
              history.push("/setting-register/form-setting-register");
            }}
          >
            <SVGAdd width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> เพิ่มข้อมูล
          </button>
        </div>
      </div>
      <CardBody>
        {loading ? (
          <div className="flex justify-center bg-transparent mt-52">
            <LoadingData />
          </div>
        ) : (
          <div className="overflow-auto">
            <DataSetting
              retrunPageNumber={(number) => {
                loadData(number, pagin.pageSize, keyword);
              }}
              keyword={keyword}
              pagin={pagin}
              data={data}
              retrunDelete={(code) => {
                DELETE(code);
              }}
            />
          </div>
        )}
      </CardBody>
      <CardFooter>
        <Pagination
          totalPage={pagin.pageCount}
          onChange={async (page) => {
            loadData(page, pagin.pageSize, keyword);
          }}
          currentPages={pagin.currentPage}
          totalRow={pagin.rowCount}
        />
      </CardFooter>
    </Fragment>
  );
}
