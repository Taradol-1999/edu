import * as Yup from "yup";

export const Validate = Yup.object({
  year: Yup.string().required("กรุณากรอก ภาคการศึกษา"),
  semester: Yup.string().required("กรุณากรอก ปีการศึกษา"),
  trainingStartDate: Yup.string().required("กรุณาเลือก วันที่เริ่มฝึก"),
  trainingEndDate: Yup.string().required("กรุณาเลือก วันที่สิ้นสุดฝึก"),
  scorePercentageProfession: Yup.number()
    .required("กรุณากรอก คะแนนจากอาจารย์นิเทศก์วิชาเอก")
    .min(1, "ต้องมากกว่าหรือเท่ากับ 1")
    .max(100, "ต้องน้อยกว่าหรือเท่ากับ 100")
    .test("sum-validation", "ผลรวมของคะแนนต้องเท่ากับ 100", function (value) {
      const { scorePercentageMentor, scorePercentageMajor, scorePercentageProfession } = this.parent;
      return scorePercentageMentor + scorePercentageMajor + scorePercentageProfession === 100;
    }),
  scorePercentageMajor: Yup.number()
    .required("กรุณากรอก คะแนนจากอาจารย์นิเทศก์วิชาชีพครู")
    .min(1, "ต้องมากกว่าหรือเท่ากับ 1")
    .max(100, "ต้องน้อยกว่าหรือเท่ากับ 100")
    .test("sum-validation", "ผลรวมของคะแนนต้องเท่ากับ 100", function (value) {
      const { scorePercentageMentor, scorePercentageMajor, scorePercentageProfession } = this.parent;
      return scorePercentageMentor + scorePercentageMajor + scorePercentageProfession === 100;
    }),
  scorePercentageMentor: Yup.number()
    .required("กรุณากรอก คะแนนจากครูพี้เลี้ยง")
    .min(1, "ต้องมากกว่าหรือเท่ากับ 1")
    .max(100, "ต้องน้อยกว่าหรือเท่ากับ 100")
    .test("sum-validation", "ผลรวมของคะแนนต้องเท่ากับ 100", function (value) {
      const { scorePercentageMentor, scorePercentageMajor, scorePercentageProfession } = this.parent;
      return scorePercentageMentor + scorePercentageMajor + scorePercentageProfession === 100;
    }),
});
