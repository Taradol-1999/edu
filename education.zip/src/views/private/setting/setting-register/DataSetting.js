import React from "react";
import { useHistory } from "react-router-dom";
import ButtonDropdown from "../../../../components/ButtonDropdown";
import { Fragment } from "react";
import NotData from "../../../../components/NotData";

export default function DataSetting({ retrunDelete, data, pagin }) {
  let history = useHistory();
  return (
    <Fragment>
      <table className="w-full bg-transparent">
        <thead>
          <tr>
            <th className="thead-th rounded-tl-lg">#</th>
            <th className="thead-th">ภาค/ปีการศึกษา</th>
            <th className="thead-th">คะแนนจากอาจารย์นิเทศก์วิชาเอก (%)</th>
            <th className="thead-th">คะแนนจากอาจารย์นิเทศก์วิชาชีพครู (%)</th>
            <th className="thead-th">คะแนนจากครูพี้เลี้ยง (%)</th>
            <th className="thead-th">วันที่เริ่ม-สิ้นสุด</th>
            <th className="thead-th rounded-tr-lg">จัดการ</th>
          </tr>
        </thead>
        <tbody>
          {data.length === 0 ? (
            <NotData />
          ) : (
            data.map((value, index) => (
              <tr key={index}>
                <th className="tbody-th">{(pagin.currentPage - 1) * pagin.pageSize + (index + 1)}</th>
                <th className="tbody-th">{value.semester + "/" + value.year}</th>
                <th className="tbody-th">{value.scorePercentageMajor} เปอร์เซ็นต์</th>
                <th className="tbody-th">{value.scorePercentageProfession} เปอร์เซ็นต์</th>
                <th className="tbody-th">{value.scorePercentageMentor} เปอร์เซ็นต์</th>
                <th className="tbody-th">{value.trainingStartDateTh + " ถึง " + value.trainingEndDateTh}</th>
                <th className="tbody-th">
                  <ButtonDropdown
                    onClickEdit={() => {
                      history.push("/setting-register/edit-form-setting-register", value.id);
                    }}
                    info={false}
                    onClickDelete={() => {
                      retrunDelete(value.id);
                    }}
                  />
                </th>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </Fragment>
  );
}
