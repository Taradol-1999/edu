import { Form, Formik, getIn, ErrorMessage } from "formik";
import React, { useState, Fragment, useEffect } from "react";
import { useHistory } from "react-router-dom";
import { TextField } from "../../../components/TextField";
import { TextSelect } from "../../../components/TextSelect";
import SVGLoading from "../../../SVGS/SVGLoading";
import SVGReset from "../../../SVGS/SVGReset";
import SVGSave from "../../../SVGS/SVGSave";
import { validateActivity } from "./Validate";
import { CreateActivity, DetailActivity, UpDateActivity } from "../../../services/Activity.services";
import { MESSAGEERROR, MESSAGESUCCESS } from "../../../components/alert";
import SVGClip from "../../../SVGS/SVGClip";
import BtnGoBack from "../../../components/BtnGoBack";
import CKEditors from "../../../components/CKEditors";
import ToggleSwitche from "../../../components/ToggleSwitche";

export default function FormActivity() {
  let history = useHistory();
  const [loading, setLoading] = useState(false);
  const [detail, setDetail] = useState({});
  let id = new URLSearchParams(history.location.search).get("id");

  const Status = [
    { id: "1", name: "เผยแพร่" },
    { id: "0", name: "ไม่เผยแพร่" },
  ];
  const ActivityType = [
    { id: "1", name: "กิจกรรม" },
    { id: "0", name: "ข่าว" },
  ];

  useEffect(() => {
    if (id) {
      loadDetail(id);
    }
  }, [id]);
  async function loadDetail(id) {
    let res = await DetailActivity(id);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        setDetail(res.data);
      }
    }
  }
  const SAVE = async (data) => {
    setLoading(true);
    let res = data.activityId ? await UpDateActivity(data) : await CreateActivity(data);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        MESSAGESUCCESS(res.message);
        history.goBack();
      } else {
        MESSAGEERROR(res.message);
      }
    }
    setLoading(false);
  };

  var url = id ? (detail.documentUrl ? detail.documentUrl : []) : [];
  var Original = id ? (detail.docOriginal ? detail.docOriginal : []) : [];

  function mergeArrayObjects(arr1, arr2) {
    return arr1.map((item, i) => {
      if (item.id === arr2[i].id) {
        return Object.assign({}, item, arr2[i]);
      }
    });
  }
  return (
    <Fragment>
      <Formik
        validationSchema={validateActivity}
        initialValues={{
          activityId: id ? (detail.activityId ? detail.activityId : "") : "",
          activityTitle: id ? (detail.activityTitle ? detail.activityTitle : "") : "",
          activityDetail: id ? (detail.activityDetail ? detail.activityDetail : "") : "",
          startDate: id ? (detail.startDate ? detail.startDate : "") : "",
          endDate: id ? (detail.endDate ? detail.endDate : "") : "",
          activityType: id ? (detail.activityType ? detail.activityType : "") : "",
          publishStatus: id ? (detail.publishStatus ? detail.publishStatus : "") : "",
          publishDate: id ? (detail.publishDate ? detail.publishDate : "") : "",
          documents: id ? mergeArrayObjects(url, Original) : [],
          image: id ? (detail.imageUrl ? detail.imageUrl : []) : [],
          removeImg: [],
          removeDoc: [],
          removeDocName: [],
          showOnSlide: id ? (detail.showOnSlide ? detail.showOnSlide : "1") : "1",
        }}
        enableReinitialize={true}
        onSubmit={async (values) => {
          SAVE(values);
        }}
      >
        {({ values, setFieldValue, touched, errors }) => (
          <Form>
            <div className="flex flex-wrap mx-auto ">
              <div className="w-full flex justify-between items-end">
                <p className="text-blue-900 text-lg">เพิ่มข้อมูลประชาสัมพันธ์/กิจกรรม</p>
                <BtnGoBack onClick={() => history.goBack()} />
              </div>
            </div>

            <div className="mt-2 border-b border-gray-400" />
            <div className="bg-white mt-5">
              <div className="w-full px-2 flex flex-wrap">
                <div className="md:w-11/12 pl-1">
                  <TextField
                    title="หัวข้อเรื่อง"
                    name="activityTitle"
                    value={values.activityTitle}
                    placeholder="หัวข้อเรื่อง"
                    onChange={(e) => {
                      setFieldValue("activityTitle", e.target.value);
                    }}
                  />
                </div>
                <div className="md:w-1/12 pl-1">
                  <ToggleSwitche
                    title="แสดงบนสไลด์"
                    checked={values.showOnSlide === "1"}
                    name="showOnSlide"
                    onChange={(e) => {
                      setFieldValue("showOnSlide", e.target.checked ? "1" : "2");
                    }}
                  />
                </div>
                <div className="md:w-3/12 pl-1">
                  <TextField
                    title="วันที่เริ่ม"
                    name="startDate"
                    type="datetime-local"
                    value={values.startDate}
                    placeholder="วันที่เริ่ม"
                    onChange={(e) => {
                      setFieldValue("startDate", e.target.value);
                    }}
                  />
                </div>
                <div className="md:w-3/12 pl-1">
                  <TextField
                    title="วันที่สินสุด"
                    type="datetime-local"
                    name="endDate"
                    value={values.endDate}
                    placeholder="วันที่สินสุด"
                    onChange={(e) => {
                      setFieldValue("endDate", e.target.value);
                    }}
                  />
                </div>
                <div className="md:w-3/12 pl-1">
                  <TextField
                    title="วันที่เผยแพร่"
                    type="datetime-local"
                    name="publishDate"
                    value={values.publishDate}
                    placeholder="วันที่เผยแพร่"
                    onChange={(e) => {
                      setFieldValue("publishDate", e.target.value);
                    }}
                  />
                </div>
                <div className="md:w-2/12 pl-1">
                  <TextSelect
                    options={Status}
                    name="publishStatus"
                    title="สถานะการเผยแพร่"
                    value={Status.filter((x) => x.id === values.publishStatus)}
                    placeholder="สถานะการเผยแพร่"
                    getOptionLabel={(x) => x.name}
                    getOptionValue={(x) => x.id}
                    onChange={(e) => {
                      setFieldValue("publishStatus", e.id);
                    }}
                  />
                </div>
                <div className="md:w-1/12 pl-1">
                  <TextSelect
                    options={ActivityType}
                    name="activityType"
                    title="ประเภทกิจกรรม"
                    value={ActivityType.filter((x) => x.id === values.activityType)}
                    placeholder="ประเภทกิจกรรม"
                    getOptionLabel={(x) => x.name}
                    getOptionValue={(x) => x.id}
                    onChange={(e) => {
                      setFieldValue("activityType", e.id);
                    }}
                  />
                </div>
                <div className="md:w-full pl-1 ">
                  <p className="truncate text-left">รายละเอียด</p>
                  <div className="ck-editor__editable_inline">
                    <CKEditors
                      toolbar={[
                        "heading",
                        "|",
                        "bold",
                        "italic",
                        "underline",
                        "|",
                        "fontFamily",
                        "fontSize",
                        "fontColor",
                        "fontBackgroundColor",
                        "bulletedList",
                        "numberedList",
                        "|",
                        "uploadImage",
                        "insertTable",
                        "link",
                        "mediaEmbed",
                        "undo",
                        "redo",
                      ]}
                      data={values.activityDetail}
                      name="activityDetail"
                      onChange={(event, editor) => {
                        const data = editor.getData();
                        setFieldValue("activityDetail", data);
                      }}
                    />
                  </div>
                </div>
                {/* //! image // */}
                <div className="flex flex-wrap items-center justify-center my-4 w-1/2">
                  <div className="w-full md:w-3/4">
                    <div className="p-2">
                      <label className="block text-sm font-medium text-gray-700">รูปภาพ</label>
                      <div
                        className={
                          "cursor-pointer flex justify-center px-6 pt-5 pb-6 border-2 border-dashed rounded-md " +
                          (getIn(touched, "image")
                            ? getIn(errors, "image")
                              ? "hover:border-red-500 border-red-300 hover:bg-red-100 bg-red-50"
                              : "hover:border-gray-500 border-gray-300 hover:bg-gray-100 bg-gray-50"
                            : "hover:border-gray-500 border-gray-300 hover:bg-gray-100 bg-gray-50")
                        }
                        onClick={() => {
                          document.getElementById("file-upload").click();
                        }}
                      >
                        <div>
                          {values.image.length !== 0 ? (
                            <div className="flex flex-wrap">
                              {values.image.map((img, keyind) => (
                                <div className="relative filter drop-shadow-lg" key={keyind}>
                                  <div className="w-24 h-full m-2">
                                    <img src={Object.keys(img).length !== 0 ? img : URL.createObjectURL(img)} alt="" width="100%" height="100%" />
                                  </div>
                                  <button
                                    className="absolute top-0 right-0 flex justify-center "
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      let img = { ...values };
                                      if (Object.keys(img.image[keyind]).length !== 0) {
                                        img.removeImg.push(img.image[keyind]);
                                        setFieldValue("removeImg", img.removeImg);
                                      }
                                      let result = img.image.filter((item, indx) => indx !== keyind);
                                      setFieldValue("image", result);
                                    }}
                                  >
                                    <span className="text-white bg-red-700 rounded-md hover:bg-red-800 p-1">ลบ</span>
                                  </button>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <svg className="w-12 h-12 mx-auto text-gray-500" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true">
                              <path
                                d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02"
                                strokeWidth={2}
                                strokeLinecap="round"
                                strokeLinejoin="round"
                              />
                            </svg>
                          )}

                          <div className="flex justify-center text-sm text-red-600">
                            <label className="cursor-pointer">
                              <span>อัพโหลดรูปภาพ</span>
                            </label>
                          </div>
                          <p className="text-xs text-center text-gray-500">.png .jpg .jpeg</p>
                        </div>
                      </div>

                      <div className="text-sm text-red-500">
                        <ErrorMessage component="div" name="image" className="invalid-feedback" />
                      </div>
                    </div>
                  </div>
                </div>
                {/* //?? documents */}
                <div className="flex flex-wrap items-center justify-center my-4 w-1/2">
                  <div className="w-full md:w-3/4">
                    <div className="p-2">
                      <label className="block text-sm font-medium text-gray-700">ไฟล์</label>
                      <div
                        className={
                          "cursor-pointer flex justify-center px-6 pt-5 pb-6 border-2 border-dashed rounded-md " +
                          (getIn(touched, "image")
                            ? getIn(errors, "image")
                              ? "hover:border-red-500 border-red-300 hover:bg-red-100 bg-red-50"
                              : "hover:border-gray-500 border-gray-300 hover:bg-gray-100 bg-gray-50"
                            : "hover:border-gray-500 border-gray-300 hover:bg-gray-100 bg-gray-50")
                        }
                        onClick={() => {
                          document.getElementById("documents-upload").click();
                        }}
                      >
                        <div className="w-full mx-20">
                          {values.documents.length !== 0 ? (
                            values.documents.map((doc, keyind) => (
                              <div key={keyind}>
                                <div className="p-2 border border-gray-200 rounded-md flex mt-2">
                                  <SVGClip width="24" height="24" color="#9ca3af" strokeWidth="2" className="mr-2" />
                                  <span className="ml-2 flex-1 w-0 truncate">{doc.name ? doc.name : doc.nameOri}</span>
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      let doc = { ...values };

                                      if (Object.keys(doc.documents[keyind]).length !== 0) {
                                        doc.removeDoc.push(doc.documents[keyind].docUrl);
                                        doc.removeDocName.push(doc.documents[keyind].nameOri);
                                        setFieldValue("removeDoc", doc.removeDoc);
                                        setFieldValue("removeDocName", doc.removeDocName);
                                      }
                                      let result = doc.documents.filter((item, indx) => indx !== keyind);
                                      setFieldValue("documents", result);
                                    }}
                                  >
                                    <span className="text-white bg-red-700 rounded-md hover:bg-red-800 p-1">ลบ</span>
                                  </button>
                                </div>
                              </div>
                            ))
                          ) : (
                            <svg xmlns="http://www.w3.org/2000/svg" className="w-10 h-10 mx-auto text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13"
                              />
                            </svg>
                          )}

                          <div className="flex justify-center text-sm text-red-600 mt-2">
                            <label className="cursor-pointer">
                              <span>อัพโหลดไฟล์</span>
                            </label>
                          </div>
                          <p className="text-xs text-center text-gray-500">.xlsx .xls .doc .docx .ppt .pptx .txt .pdf</p>
                        </div>
                      </div>

                      <div className="text-sm text-red-500">
                        <ErrorMessage component="div" name="image" className="invalid-feedback" />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex gap-3 justify-center my-5 w-full">
                  <button className={loading ? "buttonSave_disabled cursor-no-drop" : "buttonSave"} type="submit" disabled={loading ? true : false}>
                    {loading ? (
                      <div className="flex items-center justify-center text-center">
                        <SVGLoading width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" />
                        บันทึก
                      </div>
                    ) : (
                      <div className="flex items-center justify-center text-center">
                        <SVGSave width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> บันทึก
                      </div>
                    )}
                  </button>
                  <button className="buttonResetV1" type="reset">
                    <SVGReset width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> ล้างค่า
                  </button>

                  <input
                    id="file-upload"
                    type="file"
                    className="sr-only"
                    name="image"
                    multiple
                    accept="image/*"
                    onChange={(e) => {
                      let addimg = [...values.image];
                      addimg.push(...e.target.files);
                      setFieldValue("image", addimg);
                    }}
                  />
                  <input
                    id="documents-upload"
                    type="file"
                    className="sr-only"
                    name="documents"
                    multiple
                    accept=".xlsx,.xls,.doc, .docx,.ppt, .pptx,.txt,.pdf"
                    onChange={(e) => {
                      let addimg = [...values.documents];
                      addimg.push(...e.target.files);
                      setFieldValue("documents", addimg);
                    }}
                  />
                </div>
              </div>
            </div>
          </Form>
        )}
      </Formik>
    </Fragment>
  );
}
