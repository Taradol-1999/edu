import React, { Fragment, useState, useEffect } from "react";
import CardBody from "@material-tailwind/react/CardBody";
import CardFooter from "@material-tailwind/react/CardFooter";
import DataActivity from "./DataActivity";
import SVGAdd from "../../../SVGS/SVGAdd";
import Pagination from "../../../components/Pagination";
import { TextSearch } from "../../../components/TextSearch";
import { SelectSearch } from "../../../components/SelectSearch";
import { SelectPageSize } from "../../../components/SelectPageSize";
import { useHistory } from "react-router-dom";
import { DelActivity, LoadActivity } from "../../../services/Activity.services";
import LoadingData from "../../../components/LoadingData";
import { pageSize } from "../../../helper/data";
import { MultipleDatepicker } from "../../../components/MultipleDatepicker";
import Swal from "sweetalert2";
import { DElALERT, MESSAGESUCCESS, STATUSERROR } from "../../../components/alert";

export default function MainActivity() {
  let history = useHistory();
  const [activity, setActivity] = useState([]);
  const [loading, setLoading] = useState(false);
  const [keyword, setKeyword] = useState("");
  const [publishStatus, setPublishStatus] = useState("");
  const [activityType, setActivityType] = useState("");
  const [since, setSince] = useState("");
  const [to, setTo] = useState("");
  const [pagin, setPagin] = useState({
    currentPage: 1,
    pageSize: 10,
    rowCount: 0,
    pageCount: 0,
  });

  useEffect(() => {
    LoadDataActivity();
  }, []);

  async function LoadDataActivity(currentPage = 1, pageSize = 10, search = "", publishStatus = "", activityType = "", since = "", to = "") {
    setLoading(true);
    let res = await LoadActivity(currentPage, pageSize, search, publishStatus, activityType, since, to);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        setPagin(res.pagin);
        setActivity(res.data);
        setKeyword(search);
        setPublishStatus(publishStatus);
        setActivityType(activityType);
        setSince(since);
        setTo(to);
        setLoading(false);
      }
    }
  }
  function reset() {
    LoadDataActivity(1, 10, "", "", "", "", "");
  }

  function DELETE(code) {
    Swal.fire(DElALERT).then(async (result) => {
      if (result.isConfirmed) {
        let res = await DelActivity(code);
        console.log(res);
        if (res) {
          if (res.taskStatus && res.statusCode === 200) {
            MESSAGESUCCESS(res.message);
            LoadDataActivity();
          } else {
            STATUSERROR();
          }
        }
      }
    });
  }

  return (
    <Fragment>
      <form onSubmit={(e) => e.preventDefault()}>
        <p className="text-blue-800 underline">ประชาสัมพันธ์</p>
        <div className="items-center mt-5 p-2 bg-white rounded hover:shadow-lg duration-300">
          <div className="grid lg:grid-cols-12 md:grid-cols-8 sm:grid-cols-2 md:gap-0 gap-2">
            <div className="lg:col-span-3 md:col-span-4">
              <TextSearch
                placeholder="ค้นหา_หัวข้อ"
                onChange={(e) => {
                  setKeyword(e.target.value.trim());
                }}
                value={keyword}
              />
            </div>
            <div className="lg:col-span-2 md:col-span-2">
              <SelectSearch
                placeholder="สถานะการเผยแพร่"
                title="สถานะการเผยแพร่"
                options={[
                  { id: "1", name: "เผยแพร่" },
                  { id: "0", name: "ไม่เผยแพร่" },
                ]}
                value={[
                  { id: "1", name: "เผยแพร่" },
                  { id: "0", name: "ไม่เผยแพร่" },
                ].filter((x) => x.id === publishStatus)}
                getOptionLabel={(x) => x.name}
                getOptionValue={(x) => x.id}
                onChange={(e) => {
                  setPublishStatus(e.id);
                }}
              />
            </div>
            <div className="lg:col-span-2 md:col-span-2">
              <SelectSearch
                placeholder="ประเภทกิจกรรม"
                title="ประเภทกิจกรรม"
                options={[
                  { id: "1", name: "บังคับ" },
                  { id: "0", name: "ไม่บังคับ" },
                ]}
                value={[
                  { id: "1", name: "บังคับ" },
                  { id: "0", name: "ไม่บังคับ" },
                ].filter((x) => x.id === activityType)}
                getOptionLabel={(x) => x.name}
                getOptionValue={(x) => x.id}
                onChange={(e) => {
                  setActivityType(e.id);
                }}
              />
            </div>
            <div className="lg:col-span-3 md:col-span-4">
              <MultipleDatepicker
                placeholderStart="วันที่เริ่มเผยแพร่"
                placeholderEnd="วันที่สิ้นสุดเผยแพร่"
                onChangeStart={(e) => {
                  setSince(e.target.value);
                }}
                onChangeEnd={(e) => {
                  setTo(e.target.value);
                }}
                valueStart={since}
                valueEnd={to}
              />
            </div>
            <div className="flex lg:col-span-1 md:col-span-2">
              <button
                className="buttonSearch"
                onClick={() => {
                  LoadDataActivity(1, pagin.pageSize, keyword, publishStatus, activityType, since, to);
                }}
              >
                <span>ค้นหา</span>
              </button>
              <button className="buttonReset" onClick={() => reset()}>
                <span>ล้างค่า</span>
              </button>
            </div>
          </div>
        </div>
      </form>
      <div className="flex justify-between mt-5">
        <SelectPageSize
          options={pageSize}
          getOptionLabel={(x) => x.name}
          getOptionValue={(x) => x.id}
          value={pageSize.filter((a) => a.id === pagin.pageSize)}
          onChange={(e) => {
            LoadDataActivity(1, e.id, keyword, publishStatus, activityType, since, to);
          }}
        />
        <div className="flex justify-end">
          <button
            className="buttonAdd"
            onClick={() => {
              history.push("/MainActivity/FormActivity");
            }}
          >
            <SVGAdd width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> เพิ่มข้อมูล
          </button>
        </div>
      </div>
      <CardBody>
        {loading ? (
          <div className="flex justify-center bg-transparent mt-52">
            <LoadingData />
          </div>
        ) : (
          <div className="overflow-auto">
            <DataActivity
              activity={activity}
              pagin={pagin}
              retrunDelete={(code) => {
                DELETE(code);
              }}
            />
          </div>
        )}
      </CardBody>

      <CardFooter>
        {pagin.rowCount < 1 || loading === true ? (
          <div className="hidden" />
        ) : (
          <div className="flex gap-2">
            <div className="w-full">
              <Pagination
                totalPage={pagin.pageCount}
                onChange={async (page) => {
                  LoadDataActivity(page, pagin.pageSize, keyword, publishStatus, activityType, since, to);
                }}
                currentPages={pagin.currentPage}
                totalRow={pagin.rowCount}
              />
            </div>
          </div>
        )}
      </CardFooter>
    </Fragment>
  );
}
