import React, { Fragment } from "react";
import { useHistory } from "react-router-dom";
import ButtonDropdown from "../../../components/ButtonDropdown";
import NotData from "../../../components/NotData";

export default function DataActivity({ activity, pagin, retrunDelete }) {
  let history = useHistory();
  return (
    <Fragment>
      <table className="w-full bg-transparent">
        <thead>
          <tr>
            <th className="thead-th rounded-tl-lg" style={{ width: "5%" }}>
              #
            </th>
            <th className="thead-th" style={{ width: "30%" }}>
              หัวข้อ
            </th>
            <th className="thead-th" style={{ width: "10%" }}>
              วันที่เผยแพร่
            </th>
            <th className="thead-th" style={{ width: "10%" }}>
              สถานะการเผยแพร่
            </th>
            <th className="thead-th" style={{ width: "10%" }}>
              ประเภทกิจกรรม
            </th>
            <th className="thead-th rounded-tr-lg" style={{ width: "10%" }}>
              จัดการข้อมูล
            </th>
          </tr>
        </thead>
        <tbody>
          {activity.length === 0 ? (
            <NotData />
          ) : (
            activity.map((item, index) => (
              <tr key={index}>
                <th className="tbody-th" style={{ width: "5%" }}>
                  {(pagin.currentPage - 1) * pagin.pageSize + (index + 1)}
                </th>
                <th className="tbody-th " style={{ width: "30%" }}>
                  {item.activityTitle}
                </th>
                <th className="tbody-th" style={{ width: "10%" }}>
                  {item.publishDateTH}
                </th>
                <th className="tbody-th" style={{ width: "10%" }}>
                  {item.publishStatus === "1" ? "เผยแพร่" : "ไม่เผยแพร่"}
                </th>
                <th className="tbody-th" style={{ width: "10%" }}>
                  {item.activityType === "1" ? "กิจกรรม" : "ข่าว"}
                </th>
                <th className="tbody-th" style={{ width: "10%" }}>
                  <ButtonDropdown
                    onClickEdit={() => {
                      history.push("/MainActivity/FormActivity?id=" + item.activityId);
                    }}
                    onClickInfo={() => {
                      history.push("/MainActivity/DetailActivity?id=" + item.activityId);
                    }}
                    onClickDelete={() => {
                      retrunDelete(item.activityId);
                    }}
                  />
                </th>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </Fragment>
  );
}
