import { object, string } from "yup";
export const validateActivity = object({
  activityTitle: string().required("กรุณากรอก หัวข้อเรื่อง"),
  activityDetail: string().required("กรุณากรอก รายละเอียด"),
  activityType: string().required("กรุณาเลือก ประเภทกิจกรรม"),
  publishStatus: string().required("กรุณาเลือก สถานะการเผยแพร่"),
  publishDate: string().required("กรุณาเลือก วันที่เผยแพร่"),
});
