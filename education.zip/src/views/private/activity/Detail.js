import React, { Fragment, useEffect, useState } from "react";
import { useHistory } from "react-router-dom";
import SVGClip from "../../../SVGS/SVGClip";
import { DetailActivity } from "../../../services/Activity.services";
import BtnGoBack from "../../../components/BtnGoBack";
export default function Detail() {
  const [detail, setDetail] = useState({});
  let history = useHistory();
  let id = new URLSearchParams(history.location.search).get("id");

  useEffect(() => {
    if (id) {
      loadDetail(id);
    }
  }, [id]);

  async function loadDetail(id) {
    let res = await DetailActivity(id);
    if (res) {
      setDetail(res.data);
    }
  }
  const handleClick = (Link) => () => {
    window.location.href = Link;
  };

  var url = id ? (detail.documentUrl ? detail.documentUrl : []) : [];
  var Original = id ? (detail.docOriginal ? detail.docOriginal : []) : [];

  function mergeArrayObjects(arr1, arr2) {
    return arr1.map((item, i) => {
      if (item.id === arr2[i].id) {
        return Object.assign({}, item, arr2[i]);
      }
    });
  }
  return (
    <Fragment>
      <div className="w-full flex justify-between items-end">
        <p className="text-blue-900 text-lg">รายละเอียดข้อมูลประชาสัมพันธ์/กิจกรรม</p>
        <BtnGoBack onClick={() => history.goBack()} />
      </div>
      <div className="px-24 py-16 w-full">
        <div className="flex flex-col text-center w-full mb-5">
          <h1 className="sm:text-3xl text-3xl font-medium title-font mb-4 text-gray-900">{detail.activityTitle}</h1>
          <p className={detail.startDateTH && detail.endDateTH ? "text-base" : "hidden"}>{"วันที่เริ่ม " + detail.startDateTH + " - วันสิ้นสุด " + detail.endDateTH}</p>
        </div>
        <div className="flex flex-wrap justify-center">
          {detail.imageUrl
            ? detail.imageUrl.map((item, index) => (
                <div className="lg:w-1/5 sm:w-1/2 p-2 " key={index}>
                  <img alt="gallery" className="w-full h-full hover:scale-150 duration-300 cursor-pointer" src={item} />
                </div>
              ))
            : ""}
        </div>

        <div className="flex flex-wrap mt-10">
          <div className="lg:w-3/4">
            <div className="flex items-end">
              <p className="text-base">{"เผยแพร่ " + detail.publishDateTH}</p>
              <p className="text-sm text-red-700 ml-2">{detail.activityType === "1" ? "(กิจกรรม)" : "(ข่าว)"}</p>
            </div>
            <h1 className="text-gray-900 text-3xl title-font font-medium mb-4">{detail.activityTitle}</h1>
            <p dangerouslySetInnerHTML={{ __html: detail.activityDetail }} />
          </div>
          <div className={detail.documentUrl ? "lg:w-1/4" : "hidden"}>
            <h2 className="text-sm title-font text-gray-500 tracking-widest">เอกสารที่เกี่ยวข้อง</h2>
            {detail.documentUrl
              ? mergeArrayObjects(url, Original).map((item, index) => (
                  <div
                    key={index}
                    onClick={handleClick(item.docUrl)}
                    className="flex bg-white hover:bg-gray-100 border-2 border-gray-300 hover:border-gray-300 rounded-md mt-1 py-2 px-2 text-sm cursor-pointer"
                  >
                    <SVGClip width="24" height="24" color="#9ca3af" strokeWidth="2" className="mr-2" />
                    <a href={item.docUrl} target="_blank" rel="noopener noreferrer">
                      {item.nameOri}
                    </a>
                  </div>
                ))
              : ""}
          </div>
        </div>
      </div>
    </Fragment>
  );
}
