import React, { Fragment, useState, useEffect } from "react";
import { Formik, Form } from "formik";
import { useHistory } from "react-router-dom";
import SVGReset from "../../../SVGS/SVGReset";
import SVGSave from "../../../SVGS/SVGSave";
import { TextField } from "../../../components/TextField";
import { semester } from "../../../data/semester";
import { TextSelect } from "../../../components/TextSelect";
import { GetDropdown } from "../../../services/Dropdown.services";
import { validateRegister } from "./Validate";
import { MESSAGEERROR, MESSAGESUCCESS } from "../../../components/alert";
import { LoadBytRegisterId, Registers, UpdateRegisters } from "../../../services/Register.services";
import SVGLoading from "../../../SVGS/SVGLoading";
import BtnGoBack from "../../../components/BtnGoBack";
export default function FormRegister({ role }) {
  let history = useHistory();
  let id = new URLSearchParams(history.location.search).get("id");
  const user = JSON.parse(localStorage.getItem("users"));
  const [school, setSchool] = useState([]);
  const [group, setGroup] = useState([]);
  const [detail, setDetail] = useState([]);
  const [loading, setLoading] = useState(false);
  const date = [{ date: new Date().getFullYear() + 543 }, { date: new Date().getFullYear() + 543 - 1 }, { date: new Date().getFullYear() + 543 - 2 }];
  useEffect(() => {
    if (id) {
      loadDetail(id);
    }
    dropdown();
  }, [id]);

  async function dropdown() {
    let res = await GetDropdown();
    if (res) {
      setSchool(res.school);
      setGroup(res.grouplearninh);
    }
  }
  async function loadDetail(id) {
    let res = await LoadBytRegisterId(id);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        setDetail(res.data);
      }
    }
  }
  const SAVE = async (values) => {
    setLoading(true);
    let res = values.regisId ? await UpdateRegisters(values) : await Registers(values);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        MESSAGESUCCESS(res.message);
        history.push("/MainRegister");
      } else MESSAGEERROR(res.message);
    }
    setLoading(false);
  };

  return (
    <Fragment>
      <Formik
        initialValues={{
          regisId: detail.regisId ? detail.regisId : "",
          studId: user?.role === "3" ? user?.userId : detail.studId ? detail.studId : "",
          schoolId: detail.schoolId ? detail.schoolId : "",
          semester: detail.semester ? detail.semester : "",
          year: detail.year ? detail.year : "",
          groupLearning: detail.groupLearning ? detail.groupLearning : "",
        }}
        validationSchema={validateRegister}
        enableReinitialize={true}
        onSubmit={async (values) => {
          SAVE(values);
        }}
      >
        {({ values, setFieldValue, handleChange }) => (
          <Form>
            {user.role === "1" && (
              <Fragment>
                <div className="flex flex-wrap mx-auto ">
                  <div className="w-full flex justify-between items-end">
                    <p className="text-blue-900 text-lg">ลงทะเบียน</p>
                    <BtnGoBack onClick={() => history.goBack()} />
                  </div>
                </div>
                <div className="mt-2 border-b border-gray-400" />
              </Fragment>
            )}

            <div className="grid md:grid-cols-12 mt-5">
              <div className={user.role === "3" ? "hidden" : "md:col-span-12"}>
                <TextField
                  name="studId"
                  value={values.studId}
                  disabled={id}
                  title="รหัสนักศึกษา"
                  placeholder="รหัสนักศึกษา"
                  onChange={(e) => {
                    setFieldValue("studId", e.target.value);
                  }}
                  type="number"
                />
              </div>
              <div className="md:col-span-6">
                <TextSelect
                  title="โรงเรียน"
                  options={school}
                  name="schoolId"
                  value={school.filter((x) => x.schoolId === values.schoolId)}
                  placeholder="โรงเรียน"
                  getOptionLabel={(x) => "โรงเรียน " + x.schoolName}
                  getOptionValue={(x) => x.schoolId}
                  onChange={(e) => {
                    setFieldValue("schoolId", e.schoolId);
                  }}
                />
              </div>
              <div className="md:col-span-6">
                <TextSelect
                  title="กลุ่มสาระการเรียนรู้ที่สอน"
                  options={group}
                  name="groupLearning"
                  value={group.filter((x) => x.groupId === values.groupLearning)}
                  placeholder="กลุ่มสาระการเรียนรู้ที่สอน"
                  getOptionLabel={(x) => x.groupName}
                  getOptionValue={(x) => x.groupId}
                  onChange={(e) => {
                    setFieldValue("groupLearning", e.groupId);
                  }}
                />
              </div>
              <div className="md:col-span-3">
                <TextSelect
                  title="ปีการศึกษา"
                  options={date}
                  name="year"
                  value={date.filter((x) => x.date.toString() === values.year)}
                  placeholder="ปีการศึกษา"
                  getOptionLabel={(x) => x.date.toString()}
                  getOptionValue={(x) => x.date}
                  onChange={(e) => {
                    setFieldValue("year", e.date.toString());
                  }}
                />
              </div>
              <div className="md:col-span-3">
                <TextSelect
                  title="เทอม"
                  options={semester}
                  name="semester"
                  value={semester.filter((x) => x.id === values.semester)}
                  placeholder="เทอม"
                  getOptionLabel={(x) => x.semester}
                  getOptionValue={(x) => x.id}
                  onChange={(e) => {
                    setFieldValue("semester", e.id);
                  }}
                />
              </div>
            </div>
            <div className="w-full px-2">
              <div className="flex gap-3 justify-center my-5">
                <button className={loading ? "buttonSave cursor-no-drop" : "buttonSave"} type="submit" disabled={loading}>
                  {loading ? (
                    <div className="flex items-center justify-center text-center">
                      <SVGLoading width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" />
                      บันทึก
                    </div>
                  ) : (
                    <div className="flex items-center justify-center text-center">
                      <SVGSave width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> บันทึก
                    </div>
                  )}
                </button>
                <button className="buttonResetV1" type="reset">
                  <SVGReset width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> ล้างค่า
                </button>
              </div>
            </div>
          </Form>
        )}
      </Formik>
    </Fragment>
  );
}
