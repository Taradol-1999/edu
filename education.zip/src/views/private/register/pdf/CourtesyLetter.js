import moment from "moment";
import React, { Fragment } from "react";
import DateTH from "../../../../components/Date/DateTH";
import LOGOKRUT from "../../../../components/PrintPDF/img/3CM.PNG";

export default function CourtesyLetter() {
  return (
    <div className="font-THSarabun-Psk text-[17pt]">
      <Fragment>
        <div className="px-[2cm] ">
          <div className="flex justify-center  w-full">
            <img className="h-[3cm] w-[2.5cm] mb-[6pt]" src={LOGOKRUT} alt="" />
          </div>
          <div className="flex justify-between -mt-10">
            <div>ที่ อว ๐๖๓๒.๓ / ว. 00๕๒</div>
            <div>
              คณะครุศาสตร์ <br /> มหาวิทยาลัยราชภัฏกาญจนบุรี
              <br /> อ.เมือง จ.กาญจนบุรี ๗๑๑๙๐
            </div>
          </div>
          <div className="flex">
            <div className=" w-1/2" />
            <div className=" w-1/2">
              <DateTH date={moment().format()} type="date" />
            </div>
          </div>
        </div>
      </Fragment>
      <Fragment>
        <div className="px-[2cm]">
          <p>เรื่อง ขอความอนุเคราะห์สถานศึกษาฝึกปฏิบัติการสอนในสถานศึกษา ๑</p>
          <p>เรียน ผู้อำ นวยการโรงเรียนร่มเกล้ากาญจนบุรี</p>
          <p className="flex justify-between">
            <span>สิ่งที่ส่งมาด้วย รายชื่อนักศึกษา</span>
            <span>จำนวน ๑ ฉบับด้วย</span>
          </p>
          <p className="text-justify indent-[2.5cm]">
            ด้วยหลักสูตรครุศาสตรบัณฑิต (ค.บ.) ๕ ปีกำหนดให้นักศึกษาต้องฝึกปฏิบัติการวิชาชีพครู ในสถานศึกษา เป็นเวลา ๑ ปี คณะครุศาสตร์ มหาวิทยาลัยราชภัฏกาญจนบุรี จึงกำหนดให้นักศึกษาออกฝึก
            ปฏิบัติการสอนในสถานศึกษา ในภาคเรียนที่ ๑/๒๕๖๖ และ ๒/๒๕๖๖
          </p>
          <p className="text-justify indent-[2.5cm]">
            คณะครุศาสตร์ จึงขอความอนุคราะห์สถานศึกษาของท่านเป็นโรงเรียนร่วมฝึก ปฏิบัติการสอนในสถานศึกษา ๑ และเพื่อให้นักศึกษาได้มีการเตรียมตัวล่วงหน้า จึงขอให้สถานศึกษาจัดภาระ
            งานสอนที่ตรงสาขาวิชาของนักศึกษา ซึ่งนักศึกษาต้องปฏิบัติการสอนอย่างน้อยสัปดาห์ละ ๘ ชั่วโมง แต่ไม่เกิน ๑๒ ชั่วโมง และจัดครูพี่เลี้ยงที่ตรงกับสาขาวิชาของนักศึกษา
            หรือมีประสบการณ์สอนในสาขาวิชานั้น อย่างน้อย ๓ ปี และมอบหมายงานอื่น ๆ ให้กับนักศึกษาทำในระหว่างฝึกปฏิบัติการวิชาชีพครู ซึ่งนักศึกษาจะเข้าไปติดต่อ ขอรับมอบงานตามที่โรงเรียนนัดหมาย
          </p>
          <p className="text-justify indent-[2.5cm]">จึงเรียนมาเพื่อโปรดพิจารณาและขอขอบพระคุณมา ณ โอกาสนี้</p>
          <div className="flex">
            <div className=" w-1/2" />
            <div className=" w-1/2">ขอแสดงความนับถือ</div>
          </div>
          <div className="flex mt-[60pt]">
            <div className=" w-1/2" />
            <div className=" w-1/2 flex justify-start">
              <div className="text-center ">
                <p>(ผู้ช่วยศาสตราจารย์ ดร.ภูชิตภูชำนิ)</p>
                <p>คณบดีคณะครุศาสตร์</p>
                <p>มหาวิทยาลัยราชภัฏกาญจนบุรี</p>
              </div>
            </div>
          </div>
          <p>
            ฝ่ายฝึกประสบการณ์วิชาชีพครู <br />
            โทรศัพท์ 0 ๓๔๕๓ ๔๐๗๑ <br />
            โทรสาร 0 ๓๔๕๓ ๕๐๗๑
          </p>
        </div>
      </Fragment>
    </div>
  );
}
