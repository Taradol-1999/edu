import React, { Fragment } from "react";
import { useState } from "react";
import { useHistory } from "react-router-dom";
import Swal from "sweetalert2";
import { DElALERT, MESSAGEERROR, MESSAGESUCCESS, STATUSERROR } from "../../../components/alert";
import ButtonDropdown from "../../../components/ButtonDropdown";
import NotData from "../../../components/NotData";
import { DeleteAppMentor, LoadAppointMentorById } from "../../../services/Mentor.services";
import SVGInfo from "../../../SVGS/SVGInfo";
import FormAppointMentor from "./FormAppointMentor";
import Mentor from "./Mentor";
import MainScroe from "../score/MainScroe";
import SVGWriting from "../../../SVGS/SVGWriting";
import { DetailScroe } from "../../../services/Score.services";
import FormRequesttransferschool from "./FormRequesttransferschool";
import { ApproveRequesttransferschool } from "../../../services/Register.services";

export default function DataRegister({ regis, pagin, retrunDelete, user, loadData }) {
  let history = useHistory();
  const [open, setOpen] = useState(false);
  const [data, setData] = useState(false);
  const [appointmentors, setAppointmentors] = useState([]);
  const [openScroe, setOpenScroe] = useState(false);
  const [item, setItem] = useState(null);
  const [detailProfession, setDetailProfession] = useState(null);
  const [detailMajor, setDetailMajor] = useState(null);
  const [req, setReq] = useState(false);
  const [detailMentor, setDetailMentor] = useState(null);

  async function MentorById(id) {
    let res = await LoadAppointMentorById(id);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        setAppointmentors(res.data);
      }
    }
  }

  function DELETE(code, regisId) {
    Swal.fire(DElALERT).then(async (result) => {
      if (result.isConfirmed) {
        let res = await DeleteAppMentor(code);
        if (res) {
          if (res.taskStatus && res.statusCode === 200) {
            MESSAGESUCCESS(res.message);
            MentorById(regisId);
          } else {
            STATUSERROR();
          }
        }
      }
    });
  }

  async function loadDetailMajor(id) {
    let res = await DetailScroe(id);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        setDetailMajor(res.data);
      }
    }
  }
  async function loadDetailProfession(id) {
    let res = await DetailScroe(id);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        setDetailProfession(res.data);
      }
    }
  }
  async function loadDetailMentor(id) {
    let res = await DetailScroe(id);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        setDetailMentor(res.data);
      }
    }
  }

  function ChkApprove(id) {

    Swal.fire({
      title: "คุณต้องการอนุมัติคำขอนี้ หรือไม่",
      showDenyButton: true,
      showCancelButton: true,
      confirmButtonText: "ยืนยัน",
      denyButtonText: `ปฏิเสธ`,
    }).then((result) => {
      if (result.isConfirmed) {
        Approve(id, "1");
      } else if (result.isDenied) {
        Approve(id, "0");
      }
    });
  }

  const Approve = async (id, status) => {
    let res = await ApproveRequesttransferschool(id, status);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        loadData();
        MESSAGESUCCESS(res.message);
      } else MESSAGEERROR(res.message);
    }
  };
  return (
    <Fragment>
      <MainScroe close={setOpenScroe} open={openScroe} role={user?.role} user={user} item={item} setDetailProfession={setDetailProfession} detailProfession={detailProfession} setDetailMajor={setDetailMajor} detailMajor={detailMajor} detailMentor={detailMentor} setDetailMentor={setDetailMentor} loadData={loadData} />
      <FormRequesttransferschool open={req} setReq={setReq} loadData={loadData}/>
      <table className="w-full bg-transparent">
        <thead>
          <tr>
            <th className="w-[2%] thead-th">#</th>
            <th className="w-[15%] thead-th">
              รหัสนักศึกษา <br /> ชื่อ-นามสกุล
            </th>
            <th className="w-[15%] thead-th">คณะ / สาขา</th>
            <th className="w-[10%] thead-th">ภาค/ปีการศึกษา</th>
            <th className="w-[15%] thead-th">โรงเรียน</th>
            <th className="w-[18%] thead-th">อาจารย์นิเทศก์</th>
            <th className={user?.role === "1" ? "thead-th" : user?.role === "2" || user?.role === "4" ? "thead-th" : "thead-th"}>ครูพี้เลี้ยง</th>
            <th className={user?.role === "1" ? "thead-th" : "hidden"}>จัดการ</th>
            <th className={user?.role === "2" || user?.role === "4" ? "thead-th" : "hidden"}>ให้คะแนน</th>
            <th className={user?.role === "3" ? "thead-th" : "hidden"}>จัดการ</th>
          </tr>
        </thead>
        <tbody>
          {regis.length === 0 ? (
            <NotData />
          ) : (
            regis.map((item, index) => (
              <tr key={index}>
                <th className="tbody-th">{(pagin.currentPage - 1) * pagin.pageSize + (index + 1)}</th>
                <th className="tbody-th">
                  {item.studId}{" "}
                  <span className="text-gray-400 italic text-ms font-light">
                    {item.changeLocation === "0" && "(รออนุมัติการย้าย)"}
                    {item.changeLocation === "1" && "(ขอย้าย)"}
                  </span>
                  <br />
                  {item.fullName}
                </th>
                <th className="tbody-th">
                  {item.facultyName}
                  <br />
                  <span className="text-gray-500 italic font-light"> {item.majorName}</span>
                </th>
                <th className="tbody-th">{item.semester + " / " + item.year}</th>
                <th className="tbody-th">โรงเรียน{item.schoolName}</th>

                <th className="tbody-th">
                  {item.appoint ? (
                    <p>
                      {item?.appoint.major !== 0 && <i className="fa-solid fa-circle-check text-green-500 text-base mr-1" />}
                      {item.appoint.fullNameMajor} <span className="text-gray-500 italic font-light"> (วิชาเอก)</span>
                    </p>
                  ) : (
                    <span className="text-gray-500 italic font-light"> ไม่มีการแต่งตั้ง</span>
                  )}
                  {item.appoint && (
                    <p>
                      {item?.appoint.profession !== 0 && <i className="fa-solid fa-circle-check text-green-500  text-base mr-1" />}
                      {item.appoint.fullNamerProfession} <span className="text-gray-500 italic font-light"> (วิชาชีพครู)</span>
                    </p>
                  )}
                </th>
                <th className="tbody-th">
                  <div className="flex items-center">
                    {item.appointmentors.find((x) => x.mentor !== 0)?.mentor && <i className="fa-solid fa-circle-check text-green-500  text-base mr-1" />}
                    {item.appointmentors.length > 0 ? item.appointmentors[0].fullName : <span className="text-gray-500 italic font-light"> ไม่มีการแต่งตั้ง</span>}
                    {item.appointmentors.length > 0 && <SVGInfo onClick={() => MentorById(item.regisId)} width="25" height="25" color="blue" strokeWidth="1.5" className="ml-2 cursor-pointer" />}
                  </div>
                </th>
                <th className={user?.role === "1" ? "tbody-th" : "hidden"}>
                  {item.status === "1" ? (
                    <Fragment>
                      {item.changeLocation === "1" ? (
                        <button
                          onClick={() => {
                            ChkApprove(item.checkReId);
                          }}
                          className={`${item.status === "1" ? "bg-orange-100 hover:bg-orange-300" : "bg-gray-300 text-gray-500"} text-gray-900 duration-300 rounded w-[9rem] flex py-2 px-2 text-base  items-center focus:outline-none`}
                        >
                          <SVGWriting width="28" height="28" color="#f97316" strokeWidth="1.5" className="mr-2" /> อนุมัติคำขอ
                        </button>
                      ) : (
                        <ButtonDropdown
                          edit={user?.role === "1"}
                          onClickEdit={() => {
                            history.push("/MainRegister/FormRegister?id=" + item.regisId);
                          }}
                          info={false}
                          del={user?.role === "1"}
                          onClickDelete={() => {
                            retrunDelete(item.regisId);
                          }}
                          app={user?.role === "1"}
                          onClickApp={() => {
                            setOpen(item.regisId);
                            setData(item);
                          }}
                          scroe={item.appointmentors.length > 0 && item?.appoint !== null ? user?.role === "1" || user?.role === "3" : false}
                          onClickScroe={() => {
                            setOpenScroe(true);
                            setItem(item);
                          }}
                        />
                      )}
                    </Fragment>
                  ) : null}
                </th>
                <th className={user?.role === "2" || user?.role === "4" ? "tbody-th" : "hidden"}>
                  <button
                    onClick={() => {
                      setOpenScroe(true);
                      setItem(item);
                      if (item?.appoint.major) {
                        loadDetailMajor(item?.appoint.major);
                      }
                      if (item?.appoint.profession) {
                        loadDetailProfession(item?.appoint.profession);
                      }
                      let meCode = item.appointmentors.find((x) => x.mentor !== 0).mentor;
                      if (meCode) {
                        loadDetailMentor(meCode);
                      }
                    }}
                    disabled={item.appointmentors.length === 0 || item.appoint === null}
                    className={`${item.appointmentors.length === 0 || item.appoint === null ? "bg-gray-300 text-gray-500" : "bg-blue-100 text-gray-900 hover:bg-blue-300 "} duration-300 rounded w-[8rem] flex py-2 px-4 text-base  items-center focus:outline-none`}
                  >
                    <SVGWriting width="28" height="28" color={item.appointmentors.length === 0 || item.appoint === null ? "#9ca3af" : "#1d4ed8"} strokeWidth="1.5" className="mr-2" /> ให้คะแนน
                  </button>
                </th>
                <th className={user?.role === "3" ? "tbody-th" : "hidden"}>
                  <button
                    onClick={() => {
                      setReq(item);
                    }}
                    disabled={item.status !== "1" || item.changeLocation === "1"}
                    className={`${item.status === "1" && item.changeLocation !== "1" ? "bg-orange-100 hover:bg-orange-300" : "bg-gray-300 text-gray-500"} text-gray-900 duration-300 rounded w-[8rem] flex py-2 px-2 text-base  items-center focus:outline-none`}
                  >
                    <SVGWriting width="28" height="28" color="#f97316" strokeWidth="1.5" className="mr-2" /> คำขอย้าย
                  </button>
                </th>
              </tr>
            ))
          )}
        </tbody>
      </table>
      <Mentor
        appointmentors={appointmentors}
        setAppointmentors={setAppointmentors}
        retrunDel={(code, regisId) => {
          DELETE(code, regisId);
        }}
      />
      <FormAppointMentor open={open} loadData={loadData} onOpen={setOpen} data={data} />
    </Fragment>
  );
}
