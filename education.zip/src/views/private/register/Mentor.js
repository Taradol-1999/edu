import React from "react";
import Modal from "../../../components/Modal";
import NotData from "../../../components/NotData";
import DateTH from "../../../components/Date/DateTH";
import SVGClose from "../../../SVGS/SVGClose";

export default function Mentor({ appointmentors, setAppointmentors, retrunDel }) {
  const user = JSON.parse(localStorage.getItem("users"));
  return (
    <Modal
      width="max-w-5xl"
      height="min-h-[30rem]"
      isOpen={appointmentors.length > 0 ? true : false}
      title={`รายชื่อครูพี่เลี้ยงของ ${appointmentors.length > 0 ? appointmentors[0].stdName : ""}`}
      onClose={() => {
        setAppointmentors([]);
      }}
    >
      <table className="w-full bg-transparent mt-2">
        <thead>
          <tr>
            <th className="thead-th rounded-tl-lg">ชื่อ-นามสกุล</th>
            <th className="thead-th">เบอร์โทรศัพท์</th>
            <th className={`${user?.role === "1" ? "" : "rounded-tr-lg"} thead-th `}>วันที่แต่งตั้ง</th>
            <th className={`${user?.role === "1" ? "thead-th rounded-tr-lg" : "hidden"}`}>ยกเลิก</th>
          </tr>
        </thead>
        <tbody>
          {appointmentors.length === 0 ? (
            <NotData />
          ) : (
            appointmentors.map((item, index) => (
              <tr key={index}>
                <th className="tbody-th">
                  {index + 1}. {item.fullName}
                </th>
                <th className="tbody-th">{item.phone}</th>
                <th className={`${user.role === "1" ? "rounded-tr-lg" : ""} tbody-th`}>{item.appointDate ? <DateTH date={item.appointDate} type="date" /> : ""}</th>
                <th className={`${user.role === "1" ? "tbody-th" : "hidden"}`}>
                  <button
                    type="button"
                    className="flex items-end  justify-center focus:outline-none text-black hover:text-black/80 "
                    onClick={() => {
                      retrunDel(item.appointMentorsId, item.regisId);
                    }}
                  >
                    <SVGClose width="28" height="28" color="red" strokeWidth="1.5" className="mr-2" />
                  </button>
                </th>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </Modal>
  );
}
