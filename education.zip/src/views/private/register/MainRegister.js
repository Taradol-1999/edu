import React, { Fragment, useState, useEffect, useRef } from "react";
import CardBody from "@material-tailwind/react/CardBody";
import CardFooter from "@material-tailwind/react/CardFooter";
import { TextSearch } from "../../../components/TextSearch";
import { SelectSearch } from "../../../components/SelectSearch";
import DataRegister from "./DataRegister";
import Pagination from "../../../components/Pagination";
import { SelectPageSize } from "../../../components/SelectPageSize";
import SVGAdd from "../../../SVGS/SVGAdd";
import { useHistory } from "react-router-dom";
import { LoadRegister, DeleteRegis } from "../../../services/Register.services";
import LoadingData from "../../../components/LoadingData";
import { pageSize } from "../../../helper/data";
import { GetDropdown } from "../../../services/Dropdown.services";
import { DElALERT, MESSAGESUCCESS, STATUSERROR } from "../../../components/alert";
import Swal from "sweetalert2";
import Modal from "../../../components/Modal";
import FormRegister from "./FormRegister";
import SVGPrint from "../../../SVGS/SVGPrint";
import { useReactToPrint } from "react-to-print";
import CourtesyLetter from "./pdf/CourtesyLetter";

export default function MainRegister(props) {
  const componentRef = useRef();
  const [open, setOpen] = useState(false);
  const user = JSON.parse(localStorage.getItem("users"));
  let history = useHistory();
  const [loading, setLoading] = useState(false);
  const [regis, SetRegister] = useState([]);
  const [keyword, setKeyword] = useState("");
  const [major, setMajor] = useState([]);
  const [faculty, setFaculty] = useState([]);
  const [facId, setFacId] = useState(0);
  const [maId, setMaId] = useState(0);
  const [year, setYear] = useState("");
  const [term, setTerm] = useState("");
  const [semesterSearch, setSemesterSearch] = useState([]);
  const [yearSearch, setYearSearch] = useState([]);
  const [pagin, setPagin] = useState({
    currentPage: 1,
    pageSize: 10,
    totalRows: 0,
    totalPages: 0,
  });

  useEffect(() => {
    loadData();
    loadDropdown();
  }, []);

  async function loadData(currentPage = 1, pageSize = 10, search = "", FacId = 0, MaId = 0, Year = "", Term = "") {
    setLoading(true);
    let res = await LoadRegister(currentPage, pageSize, search, FacId, MaId, Year, Term);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        SetRegister(res.data);
        setPagin(res.pagin);
        setKeyword(search);
        setMaId(MaId);
        setFacId(FacId);
        setYear(Year);
        setTerm(Term);
      }
    }
    setLoading(false);
  }
  async function loadDropdown() {
    let result = await GetDropdown();
    if (result) {
      setMajor(result.majors);
      setFaculty(result.faculty);
      setSemesterSearch(result.settingRegis.semester);
      setYearSearch(result.settingRegis.year);
    }
  }

  function reset() {
    loadData(1, 10, "", 0, 0, "", "");
  }
  function DELETE(code) {
    Swal.fire(DElALERT).then(async (result) => {
      if (result.isConfirmed) {
        let res = await DeleteRegis(code);
        if (res) {
          if (res.taskStatus && res.statusCode === 200) {
            MESSAGESUCCESS(res.message);
            loadData();
          } else {
            STATUSERROR();
          }
        }
      }
    });
  }

  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
    // onAfterPrint: () => setPrint(false),
  });

  return (
    <Fragment>
      <div className="hidden">
        <div ref={componentRef}>
          <CourtesyLetter />
        </div>
      </div>
      <form onSubmit={(e) => e.preventDefault()}>
        <p className="text-blue-800 underline">ข้อมูลการลงทะเบียนแจ้งความประสงค์</p>
        <div className="items-center mt-5 p-2 rounded hover:shadow-lg duration-300">
          <div className="grid lg:grid-cols-12 md:grid-cols-6 sm:grid-cols-2 md:gap-0 gap-2">
            <div className={user?.role === "3" ? "hidden" : "lg:col-span-4 md:col-span-4"}>
              <TextSearch
                placeholder="ค้นหา_รหัสนักศึกษา_ชื่อ-นามสกุล_โรงเรียน"
                onChange={(e) => {
                  setKeyword(e.target.value.trim());
                }}
                value={keyword}
              />
            </div>
            <div className={user?.role === "3" ? "hidden" : "lg:col-span-2 md:col-span-2"}>
              <SelectSearch
                placeholder="คณะ"
                options={faculty}
                value={faculty.filter((x) => x.facultyId === facId)}
                getOptionLabel={(x) => x.facultyName}
                getOptionValue={(x) => x.facultyId}
                onChange={(e) => {
                  setFacId(e.facultyId);
                  setMaId(0);
                }}
              />
            </div>
            <div className={user?.role === "3" ? "hidden" : "lg:col-span-2 md:col-span-2"}>
              <SelectSearch
                placeholder="สาขา"
                options={major.filter((x) => x.facultyId === facId)}
                value={major.filter((x) => x.majorId === maId)}
                getOptionLabel={(x) => x.majorName}
                getOptionValue={(x) => x.majorId}
                onChange={(e) => {
                  setMaId(e.majorId);
                }}
              />
            </div>
            <div className="lg:col-span-1 md:col-span-1">
              <SelectSearch
                placeholder="ปีการศึกษา"
                title="ปีการศึกษา"
                options={yearSearch}
                name="year"
                value={yearSearch.filter((x) => x.year === year)}
                getOptionLabel={(x) => x.year}
                getOptionValue={(x) => x.year}
                onChange={(e) => {
                  setYear(e.year);
                }}
              />
            </div>
            <div className="lg:col-span-1 md:col-span-1">
              <SelectSearch
                options={semesterSearch}
                value={semesterSearch.filter((x) => x.semester === term)}
                placeholder="ภาคการศึกษา"
                getOptionLabel={(x) => x.semester}
                getOptionValue={(x) => x.semester}
                onChange={(e) => {
                  setTerm(e.semester);
                }}
              />
            </div>
            <div className="lg:col-span-2 md:col-span-1 flex w-full">
              <button
                className="buttonSearch"
                onClick={() => {
                  loadData(1, pagin.pageSize, keyword, facId, maId, year, term);
                }}
              >
                ค้นหา
              </button>
              <button
                className="buttonReset"
                onClick={() => {
                  reset();
                }}
              >
                ล้างค่า
              </button>
            </div>
          </div>
        </div>
      </form>
      <div className="flex justify-between mt-5">
        <div className="flex items-end">
          <SelectPageSize
            options={pageSize}
            getOptionLabel={(x) => x.name}
            getOptionValue={(x) => x.id}
            value={pageSize.filter((a) => a.id === pagin.pageSize)}
            onChange={(e) => {
              loadData(1, e.id, keyword, facId, maId, year, term);
            }}
          />
          <p className=" w-fit px-2 rounded-full text-black h-fit ml-2">
            <i className="fa-solid fa-circle-check text-green-500  text-lg " /> = ให้คะแนนแล้ว
          </p>
        </div>
        {user?.role !== "4" && user?.role !== "2" && (
          <div className={`${user?.role !== "1" ? (props.chkRegis ? "flex justify-end" : "hidden") : "flex justify-end"}`}>
            <button
              className="buttonAdd  mr-2"
              onClick={() => {
                if (user?.role === "1") {
                  history.push("/MainRegister/FormRegister");
                } else {
                  setOpen(true);
                }
              }}
            >
              <SVGAdd width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> แจ้งความประสงค์
            </button>

            {user?.role === "1" && (
              <button
                className="buttonPrint mr-2"
                onClick={() => {
                  handlePrint();
                }}
              >
                <SVGPrint width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> หนังสือขอความอนุเคราะห์
              </button>
            )}
          </div>
        )}
      </div>
      <CardBody>
        {loading ? (
          <div className="flex justify-center bg-transparent mt-52">
            <LoadingData />
          </div>
        ) : (
          <div className="overflow-auto">
            <DataRegister
              user={user}
              regis={regis}
              pagin={pagin}
              retrunDelete={(code) => {
                DELETE(code);
              }}
              chkRegis={props.chkRegis}
              loadData={loadData}
            />
          </div>
        )}
      </CardBody>
      <CardFooter>
        <Pagination
          totalPage={pagin.pageCount}
          onChange={async (page) => {
            loadData(page, pagin.pageSize, keyword);
          }}
          currentPages={pagin.currentPage}
          totalRow={pagin.rowCount}
        />
      </CardFooter>
      <Modal
        width="max-w-4xl"
        isOpen={open}
        title="ลงทะเบียน"
        onClose={() => {
          setOpen(false);
        }}
      >
        <div className="py-2">
          <FormRegister role={user?.role} />
        </div>
      </Modal>
      {/* </div> */}
    </Fragment>
  );
}
