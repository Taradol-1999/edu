import { Form, Formik } from "formik";
import React, { useState, useEffect, Fragment } from "react";
import { TextField } from "../../../components/TextField";
import { TextSelect } from "../../../components/TextSelect";
import SVGLoading from "../../../SVGS/SVGLoading";
import SVGReset from "../../../SVGS/SVGReset";
import SVGSave from "../../../SVGS/SVGSave";
import { GetDropdown } from "../../../services/Dropdown.services";
import { DElALERT, MESSAGEERROR, MESSAGESUCCESS, STATUSERROR } from "../../../components/alert";
import { AppointMento, DeleteMentor, LoadMentor, LoadMentorById, RegisAppiontMentor, UpdateMentor } from "../../../services/Mentor.services";
import Modal from "../../../components/Modal";
import { validateMentor } from "./Validate";
import SVGEdit from "../../../SVGS/SVGEdit";
import SVGSquareCheck from "../../../SVGS/SVGSquareCheck";
import SVGUnCheck from "../../../SVGS/SVGUnCheck";
import { TextSearch } from "../../../components/TextSearch";
import { SelectSearch } from "../../../components/SelectSearch";
import NotData from "../../../components/NotData";
import LoadingData from "../../../components/LoadingData";
import SVGAdd from "../../../SVGS/SVGAdd";
import Pagination from "../../../components/Pagination";
import SVGDelete from "../../../SVGS/SVGDelete";
import Swal from "sweetalert2";
import SVGClose from "../../../SVGS/SVGClose";
import { TextFieldPassword } from "../../../components/TextFieldPassword";

export default function FormAppointMentor({ open, onOpen, data, loadData }) {
  const [loading, setLoading] = useState(false);
  const [title, setPrefix] = useState([]);
  const [grouplearninh, setGrouplearninh] = useState([]);
  const [mentor, setMentor] = useState([]);
  const [keyword, setKeyword] = useState("");
  const [group, setGgroup] = useState(0);
  const [loadingsearch, setLoadingSearch] = useState(false);
  const [openNew, setOpenNew] = useState({
    status: false,
    name: "",
  });
  const [mentorDetail, setMentorDetail] = useState(false);
  const [pagin, setPagin] = useState({
    currentPage: 1,
    pageSize: 10,
    totalRows: 0,
    totalPages: 0,
  });

  useEffect(() => {
    loadDropdown();
  }, []);

  async function loadDropdown() {
    let result = await GetDropdown();
    if (result) {
      setPrefix(result.title);
      setGrouplearninh(result.grouplearninh);
    }
  }

  const SAVE = async (values) => {
    setLoading(true);
    let res = values.mentorId !== 0 ? await UpdateMentor(values) : await RegisAppiontMentor(values);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        MESSAGESUCCESS(res.message);
        getMentor(1, 4, data.schoolId, open, "", 0);
        setOpenNew({ status: false, name: "" });
      } else {
        MESSAGEERROR(res.message);
      }
    }
    setLoading(false);
  };

  const Appoint = async (values) => {
    setLoading(true);
    let res = await AppointMento(values);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        MESSAGESUCCESS(res.message);
        getMentor(1, 4, data.schoolId, open, "", 0);
      } else {
        MESSAGEERROR(res.message);
      }
    }
    setLoading(false);
  };

  async function getMentor(currentPage, pageSize, id, reId, search, groupId) {
    setLoadingSearch(true);
    let res = await LoadMentor(currentPage, pageSize, id, reId, search, groupId);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        setMentor(res.data);
        setPagin(res.pagin);
      }
    }
    setLoadingSearch(false);
  }

  function DELETE(code) {
    Swal.fire(DElALERT).then(async (result) => {
      if (result.isConfirmed) {
        let res = await DeleteMentor(code);
        if (res) {
          if (res.taskStatus && res.statusCode === 200) {
            MESSAGESUCCESS(res.message);
            getMentor(1, 4, data.schoolId, open, "", 0);
          } else {
            STATUSERROR();
          }
        }
      }
    });
  }

  async function loadMentorById(id) {
    let res = await LoadMentorById(id);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        setMentorDetail(res.data);
        setOpenNew({ status: true, name: res.data.fullName });
      }
    }
  }

  useEffect(() => {
    if (data.schoolId && open) {
      getMentor(1, 4, data.schoolId, open, "", 0);
    }
  }, [data.schoolId, open]);

  return (
    <Modal
      width="max-w-5xl"
      isOpen={open ? true : false}
      title="แต่งตั้งครูพี่เลี้ยง"
      onClose={() => {
        onOpen(false);
        setOpenNew({ status: false, name: "" });
        loadData();
      }}
    >
      <Formik
        initialValues={{
          appMentor: mentor,
        }}
        enableReinitialize={true}
        onSubmit={(values) => {
          Appoint(values.appMentor);
        }}
      >
        {({ values, setFieldValue }) => (
          <Form>
            <p className="text-xl text-center text-gray-500 dark:text-gray-300 my-2">รายชื่อครูในภายในโรงเรียน</p>
            <h1 className=" text-3xl font-semibold text-center text-gray-800 capitalize lg:text-4xl dark:text-white">{data.schoolName}</h1>
            <p className="text-lg">
              แต่งตั้งให้กับ : <span className="font-bold">{data.fullName}</span>
            </p>
            <div className="flex gap-2">
              <div className="w-6/12">
                <TextSearch
                  placeholder="ค้นหา_ชื่อ-นามสกุล_กลุ่มสาระการเรียนรู้"
                  onChange={(e) => {
                    setKeyword(e.target.value.trim());
                  }}
                  value={keyword}
                />
              </div>
              <div className="w-4/12">
                <SelectSearch
                  placeholder="กลุ่มสาระการเรียนรู้"
                  options={grouplearninh}
                  value={grouplearninh.filter((x) => x.groupId === group)}
                  getOptionLabel={(x) => x.groupName}
                  getOptionValue={(x) => x.groupId}
                  onChange={(e) => {
                    setGgroup(e.groupId);
                  }}
                />
              </div>
              <div className="flex justify-end w-2/12">
                <button
                  className="buttonSearch"
                  type="button"
                  onClick={() => {
                    getMentor(1, 4, data.schoolId, open, keyword, group);
                  }}
                >
                  ค้นหา
                </button>
                <button
                  className="buttonReset"
                  type="button"
                  onClick={() => {
                    setGgroup(0);
                    setKeyword("");
                    getMentor(1, 4, data.schoolId, open, "", 0);
                  }}
                >
                  ล้างค่า
                </button>
              </div>
            </div>
            <div className="flex justify-end w-full mt-2">
              <button
                onClick={() => {
                  setOpenNew({ status: true, name: "" });
                }}
                className="p-2 bg-green-600 text-white rounded-lg hover:bg-green-700 focus:outline-none flex items-center w-[9.6rem]"
                type="button"
              >
                <SVGAdd width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> เพิ่มรายชื่อใหม่
              </button>
            </div>

            <div className={`h-[15rem] overflow-auto ${values.appMentor.length <= 0 && "flex justify-center items-center"}`}>
              {loadingsearch ? (
                <div className="flex justify-center items-center h-full">
                  <LoadingData />
                </div>
              ) : values.appMentor.length <= 0 ? (
                <NotData />
              ) : (
                values.appMentor.map((item, index) => (
                  <div key={index} className={`flex items-center justify-between max-w-5xl px-4 py-2 my-2 mx-auto border-[3px] rounded-md ${item.regisId ? "border-blue-500" : "border-gray-500"}`}>
                    <div
                      onClick={() => {
                        if (!openNew.status) {
                          if (open) {
                            if (item.regisId) {
                              setFieldValue(`appMentor.${index}.regisId`, "");
                            } else {
                              setFieldValue(`appMentor.${index}.regisId`, open);
                            }
                          }
                        }
                      }}
                      className={`flex items-center w-1/2 ${openNew.status ? "cursor-not-allowed	" : "cursor-pointer"}`}
                    >
                      <h2 className={`${item.regisId ? "text-blue-700" : "text-gray-700"} w-5 text-lg`}>{(pagin.currentPage - 1) * pagin.pageSize + (index + 1)}. </h2>

                      {item.regisId ? <SVGSquareCheck width="26" height="26" color="#3b82f6" strokeWidth="2" /> : <SVGUnCheck width="26" height="26" color="#6b7280" strokeWidth="2" />}
                      <div className="flex flex-col items-center mx-5 space-y-1">
                        <h2 className="text-lg font-medium text-gray-700 sm:text-2xl dark:text-gray-200">{item.fullName}</h2>
                      </div>
                    </div>
                    <div className="w-1/2 flex">
                      <h2
                        onClick={() => {
                          if (!openNew.status) {
                            if (open) {
                              if (item.regisId) {
                                setFieldValue(`appMentor.${index}.regisId`, "");
                              } else {
                                setFieldValue(`appMentor.${index}.regisId`, open);
                              }
                            }
                          }
                        }}
                        className={`${item.regisId ? "text-blue-500" : "text-gray-500"} text-base font-semibold  w-10/12 line-clamp-1 ${openNew.status ? "cursor-not-allowed	" : "cursor-pointer"}`}
                      >
                        กลุ่มสาระการเรียนรู้ : <span className={`text-lg font-medium ${item.regisId ? "text-blue-500" : "text-gray-500"}`}>{item.groupName}</span>
                      </h2>
                      <button
                        type="button"
                        className="flex items-end z-10 w-2/12 border-l-2 border-l-gray-300 justify-center focus:outline-none text-black hover:text-black/80"
                        onClick={() => {
                          loadMentorById(item.mentorId);
                        }}
                      >
                        <SVGEdit width="28" height="28" color="orange" strokeWidth="1.5" className="mr-2" /> แก้ไข
                      </button>
                      {item.chkDel && (
                        <button
                          type="button"
                          className="flex items-end w-2/12 justify-center focus:outline-none text-black hover:text-black/80"
                          onClick={() => {
                            DELETE(item.mentorId);
                          }}
                        >
                          <SVGDelete width="28" height="28" color="red" strokeWidth="1.5" className="mr-2" /> ลบ
                        </button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
            <Pagination
              totalPage={pagin.pageCount}
              onChange={async (page) => {
                getMentor(page, pagin.pageSize, data.schoolId, open, keyword, group);
              }}
              currentPages={pagin.currentPage}
              totalRow={pagin.rowCount}
            />

            {values.appMentor.length > 0
              ? !openNew.status && (
                  <div className="w-full px-2">
                    <div className="flex gap-3 justify-center my-5">
                      <button className={loading ? "buttonSave_disabled cursor-no-drop" : "buttonSave"} type="submit" disabled={loading ? true : false}>
                        {loading ? (
                          <div className="flex items-center justify-center text-center">
                            <SVGLoading width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" />
                            บันทึก
                          </div>
                        ) : (
                          <div className="flex items-center justify-center text-center">
                            <SVGSave width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> บันทึก
                          </div>
                        )}
                      </button>
                      <button className="buttonResetV1" type="reset">
                        <SVGReset width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> ล้างค่า
                      </button>
                    </div>
                  </div>
                )
              : ""}
          </Form>
        )}
      </Formik>

      {openNew.status && (
        <Fragment>
          <p className="text-gray-700 text-lg">
            <span className="font-bold text-xl">{openNew.name ? `แก้ไข` : "เพิ่ม"}</span> {openNew.name ? `${openNew.name}` : "รายชื่อครูในภายในโรงเรียน"}
          </p>
          <hr />
          <Formik
            validationSchema={validateMentor}
            initialValues={{
              mentorId: openNew.name ? mentorDetail.mentorId : 0,
              preFix: openNew.name ? mentorDetail.preFix : "",
              firstName: openNew.name ? mentorDetail.firstName : "",
              lastName: openNew.name ? mentorDetail.lastName : "",
              phone: openNew.name ? mentorDetail.phone : "",
              passWord: openNew.name ? mentorDetail.password : "",
              groupId: openNew.name ? mentorDetail.groupId : "",
              schoolId: data.schoolId,
            }}
            enableReinitialize={true}
            onSubmit={async (values) => {
              await SAVE(values);
            }}
          >
            {({ values, setFieldValue, handleChange }) => (
              <Form>
                <div className="flex flex-wrap my-2">
                  <div className="md:w-2/12">
                    <TextSelect
                      title="คำนำหน้าชื่อ"
                      options={title}
                      name="preFix"
                      value={title.filter((x) => x.titleId === values.preFix)}
                      placeholder="คำนำหน้าชื่อ"
                      getOptionLabel={(x) => x.titleName}
                      getOptionValue={(x) => x.titleId}
                      onChange={(e) => {
                        setFieldValue("preFix", e.titleId);
                      }}
                    />
                  </div>
                  <div className="md:w-5/12">
                    <TextField name="firstName" value={values.firstName} title="ชื่อ" placeholder="ชื่อ" onChange={handleChange} type="text" />
                  </div>
                  <div className="md:w-5/12">
                    <TextField name="lastName" value={values.lastName} title="นามสกุล" placeholder="นามสกุล" onChange={handleChange} type="text" />
                  </div>
                  <div className="md:w-2/12">
                    <TextField name="phone" value={values.phone} title="เบอร์โทรศัพท์มือถือ" placeholder="เบอร์โทรศัพท์มือถือ" onChange={handleChange} type="text" />
                  </div>
                  <div className="md:w-5/12">
                    <TextFieldPassword
                      name="passWord"
                      value={values.passWord}
                      title="รหัสผ่าน"
                      placeholder="รหัสผ่าน"
                      onChange={(e) => {
                        setFieldValue("passWord", e.target.value);
                      }}
                      type="text"
                    />
                  </div>
                  <div className="md:w-5/12">
                    <TextSelect
                      title="กลุ่มสาระการเรียนรู้"
                      options={grouplearninh}
                      name="groupId"
                      value={grouplearninh.filter((x) => x.groupId === values.groupId)}
                      placeholder="กลุ่มสาระการเรียนรู้"
                      getOptionLabel={(x) => x.groupName}
                      getOptionValue={(x) => x.groupId}
                      onChange={(e) => {
                        setFieldValue("groupId", e.groupId);
                      }}
                    />
                  </div>
                </div>
                <div className="w-full px-2">
                  <div className="flex gap-3 justify-center my-5">
                    <button className={loading ? "buttonSave_disabled cursor-no-drop" : "buttonSave"} type="submit" disabled={loading ? true : false}>
                      {loading ? (
                        <div className="flex items-center justify-center text-center">
                          <SVGLoading width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" />
                          บันทึก
                        </div>
                      ) : (
                        <div className="flex items-center justify-center text-center">
                          <SVGSave width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> บันทึก
                        </div>
                      )}
                    </button>
                    <button className="buttonResetV1" type="reset">
                      <SVGReset width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> ล้างค่า
                    </button>
                    <button className="buttonBack" type="reset" onClick={() => setOpenNew({ status: false, name: "" })}>
                      <SVGClose width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> ยกเลิก
                    </button>
                  </div>
                </div>
              </Form>
            )}
          </Formik>
        </Fragment>
      )}
    </Modal>
  );
}
