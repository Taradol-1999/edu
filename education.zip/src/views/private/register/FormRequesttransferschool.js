import React, { useEffect, useState } from "react";
import Modal from "../../../components/Modal";
import { TextSelect } from "../../../components/TextSelect";
import { Form, Formik } from "formik";
import { GetDropdown } from "../../../services/Dropdown.services";
import SVGLoading from "../../../SVGS/SVGLoading";
import SVGSave from "../../../SVGS/SVGSave";
import SVGReset from "../../../SVGS/SVGReset";
import { TextFieldArea } from "../../../components/TextFieldArea";
import { object, string } from "yup";
import { MESSAGEERROR, MESSAGESUCCESS } from "../../../components/alert";
import { CreateRequesttransferschool } from "../../../services/Register.services";

export default function FormRequesttransferschool({ open, setReq, loadData }) {
  const user = JSON.parse(localStorage.getItem("users"));
  const [school, setSchool] = useState([]);
  const [group, setGroup] = useState([]);
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    dropdown();
  }, []);

  async function dropdown() {
    let res = await GetDropdown();
    if (res) {
      setSchool(res.school);
      setGroup(res.grouplearninh);
    }
  }

  const validateRegister = object({
    schoolId: string().required("กรุณาเลือก โรงเรียน"),
    groupLearning: string().required("กรุณาเลือก กลุ่มสาระการเรียนรู้"),
    reason: string().required("กรุณากรอก เหตุผลการย้าย"),
  });

  const SAVE = async (values) => {
    setLoading(true);
    let res = await CreateRequesttransferschool(values);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        MESSAGESUCCESS(res.message);
        loadData();
      } else MESSAGEERROR(res.message);
    }
    setLoading(false);
  };

  return (
    <Modal
      width="max-w-5xl"
      isOpen={open ? true : false}
      title={`คำขอย้ายโรงเรียน `}
      subTitle={` ภาคการศึกษา ${open.semester} ปีการศึกษา ${open.year}`}
      onClose={() => {
        setReq(false);
      }}
    >
      <Formik
        initialValues={{
          reId: 0,
          regisIdold: open.regisId,
          studId: user?.userId,
          schoolId: "",
          semester: open.semester,
          year: open.year,
          groupLearning: "",
          reason: "",
        }}
        validationSchema={validateRegister}
        enableReinitialize={true}
        onSubmit={async (values) => {
          SAVE(values);
        }}
      >
        {({ values, setFieldValue, handleChange }) => (
          <Form>
            <div className="grid md:grid-cols-12 mt-5">
              <div className="md:col-span-6">
                <TextSelect
                  title="โรงเรียน"
                  options={school}
                  name="schoolId"
                  value={school.filter((x) => x.schoolId === values.schoolId)}
                  placeholder="โรงเรียน"
                  getOptionLabel={(x) => "โรงเรียน " + x.schoolName}
                  getOptionValue={(x) => x.schoolId}
                  onChange={(e) => {
                    setFieldValue("schoolId", e.schoolId);
                  }}
                />
              </div>
              <div className="md:col-span-6">
                <TextSelect
                  title="กลุ่มสาระการเรียนรู้ที่สอน"
                  options={group}
                  name="groupLearning"
                  value={group.filter((x) => x.groupId === values.groupLearning)}
                  placeholder="กลุ่มสาระการเรียนรู้ที่สอน"
                  getOptionLabel={(x) => x.groupName}
                  getOptionValue={(x) => x.groupId}
                  onChange={(e) => {
                    setFieldValue("groupLearning", e.groupId);
                  }}
                />
              </div>
              <div className="col-span-12">
                <TextFieldArea
                  name="reason"
                  value={values.reason}
                  title="เหตุผลการย้าย"
                  placeholder="เหตุผลการย้าย"
                  onChange={(e) => {
                    setFieldValue("reason", e.target.value);
                  }}
                />
              </div>
            </div>
            <div className="w-full px-2">
              <div className="flex gap-3 justify-center my-5">
                <button className={loading ? "buttonSave cursor-no-drop" : "buttonSave"} type="submit" disabled={loading}>
                  {loading ? (
                    <div className="flex items-center justify-center text-center">
                      <SVGLoading width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" />
                      บันทึก
                    </div>
                  ) : (
                    <div className="flex items-center justify-center text-center">
                      <SVGSave width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> บันทึก
                    </div>
                  )}
                </button>
                <button className="buttonResetV1" type="reset">
                  <SVGReset width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> ล้างค่า
                </button>
              </div>
            </div>
          </Form>
        )}
      </Formik>
    </Modal>
  );
}
