import { array, number, object, ref, string } from "yup";
export const validateRegister = object({
  studId: string().required("กรุณากรอก รหัสนักศึกษา"),
  schoolId: string().required("กรุณาเลือก โรงเรียน"),
  semester: string().required("กรุณาเลือก ปีการศึกษา"),
  year: string().required("กรุณาเลือก เทอม"),
  groupLearning: string().required("กรุณาเลือก กลุ่มสาระการเรียนรู้"),
});

export const validateMentor = object({
  preFix: string().required("กรุณาเลือก คำนำหน้าชื่อ"),
  firstName: string().required("กรุณากรอก ชื่อ"),
  lastName: string().required("กรุณากรอก นามสกุล"),
  phone: string().required("กรุณากรอก เบอร์โทรศัพท์"),
  groupId: string().required("กรุณาเลือก กลุ่มสาระการเรียนรู้"),
});

export const validateScroe = object({
  attachEvidence: array().min(1, "กรุณาแนบ หลักฐาน").max(50, "Too Long!"),
  fullScore: number().min(ref("scroe"), "คะแนนที่ได้ ต้องไม่มากกว่า คะแนนเต็ม").required("กรุณากรอก คะแนนเต็ม"),
  scroe: number().required("กรุณากรอก คะแนนที่ได้"),
});
