import { object, string, array } from "yup";
export const validateAppoint = object({
  appointArray: array().of(
    object().shape({
      instructorMajor: string().required("กรุณาเลือก อาจารย์นิเทศก์เอก"),
      instructorProfession: string().required("กรุณาเลือก อาจารย์นิเทศก์วิชาชีพครู"),
    })
  ),
});
