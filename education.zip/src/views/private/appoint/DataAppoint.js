import React, { Fragment, useState } from "react";
import ButtonDropdown from "../../../components/ButtonDropdown";
import NotData from "../../../components/NotData";
import UpdateAppoint from "./UpdateAppoint";
import { LoadDetailById } from "../../../services/Appoint.services";
import Modal from "../../../components/Modal";
export default function DataAppoint({ retrunDelete, appiont, pagin, reset }) {
  const [detailById, setDetailById] = useState({});
  let [isOpen, setIsOpen] = useState({
    open: false,
    appoint: "",
  });

  async function LoadDetail(id) {
    let res = await LoadDetailById(id);
    if (res) {
      setDetailById(res.data);
    }
  }
  return (
    <Fragment>
      <table className="w-full bg-transparent">
        <thead>
          <tr>
            <th className="thead-th rounded-tl-lg">#</th>
            <th className="thead-th">รหัสนักศึกษา</th>
            <th className="thead-th">ชื่อ-นามสกุล</th>
            <th className="thead-th">คณะ/สาขา</th>
            <th className="thead-th">อาจารย์นิเทศก์เอก</th>
            <th className="thead-th">อาจารย์นิเทศก์วิชาชีพครู</th>
            <th className="thead-th">เทอม/ปีการศึกษา</th>
            <th className="thead-th">โรงเรียน</th>
            <th className="thead-th rounded-tr-lg">จัดการข้อมูล</th>
          </tr>
        </thead>
        <tbody>
          {appiont.length === 0 ? (
            <NotData />
          ) : (
            appiont.map((item, index) => (
              <tr key={index}>
                <th className="tbody-th">{(pagin.currentPage - 1) * pagin.pageSize + (index + 1)}</th>
                <th className="tbody-th">{item.studId}</th>
                <th className="tbody-th">{item.fullNameStud}</th>
                <th className="tbody-th">{item.facultyName + "/" + item.majorName}</th>
                <th className="tbody-th">{item.fullNameInstructorMajor}</th>
                <th className="tbody-th">{item.fullNameInstructorProfession}</th>
                <th className="tbody-th">{item.semester + "/" + item.year}</th>
                <th className="tbody-th">{"โรงเรียน " + item.schoolName}</th>
                <th className="tbody-th">
                  <ButtonDropdown
                    onClickEdit={() => {
                      setIsOpen({ open: true, appoint: item.appointId });
                      LoadDetail(item.appointId);
                    }}
                    info={false}
                    onClickDelete={() => {
                      retrunDelete(item.appointId);
                    }}
                  />
                </th>
              </tr>
            ))
          )}
        </tbody>
      </table>
      <Modal
        width="max-w-2xl"
        isOpen={isOpen.open}
        title="แก้ไข แต่งตั้งอาจารย์นิเทศก์"
        onClose={() => {
          setIsOpen({ open: false });
        }}
      >
        <UpdateAppoint setIsOpen={setIsOpen} detailById={detailById} reset={reset} />
      </Modal>
    </Fragment>
  );
}
