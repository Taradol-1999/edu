import React, { Fragment } from "react";
import DateTH from "../../../../components/Date/DateTH";
import LOGOKRUT from "../../../../components/PrintPDF/img/3CM.PNG";
import Moment from "moment";

export default function AppointmentOrder({ data }) {
  let datas = data.dataAll;
  // schoolName
  let namesArr = {};
  const rowSpan = datas.reduce((result, item, key) => {
    if (namesArr[item.schoolName] === undefined) {
      namesArr[item.schoolName] = key;
      result[key] = 1;
    } else {
      const firstIndex = namesArr[item.schoolName];
      if (firstIndex === key - 1 || (item.schoolName === datas[key - 1].schoolName && result[key - 1] === 0)) {
        result[firstIndex]++;
        result[key] = 0;
      } else {
        result[key] = 1;
        namesArr[item.schoolName] = key;
      }
    }
    return result;
  }, []);
  // fullNameInstructorMajor
  let Arr1 = {};
  const rowSpanfullNameInstructorMajor = datas.reduce((result, item, key) => {
    if (Arr1[item.fullNameInstructorMajor] === undefined) {
      Arr1[item.fullNameInstructorMajor] = key;
      result[key] = 1;
    } else {
      const firstIndex1 = Arr1[item.fullNameInstructorMajor];
      if (firstIndex1 === key - 1 || (item.fullNameInstructorMajor === datas[key - 1].fullNameInstructorMajor && result[key - 1] === 0)) {
        result[firstIndex1]++;
        result[key] = 0;
      } else {
        result[key] = 1;
        Arr1[item.fullNameInstructorMajor] = key;
      }
    }
    return result;
  }, []);
  // fullNameInstructorProfession
  let Arr2 = {};
  const rowSpanfullNameInstructorProfession = datas.reduce((result, item, key) => {
    if (Arr2[item.fullNameInstructorProfession] === undefined) {
      Arr2[item.fullNameInstructorProfession] = key;
      result[key] = 1;
    } else {
      const firstIndex2 = Arr2[item.fullNameInstructorProfession];
      if (firstIndex2 === key - 1 || (item.fullNameInstructorProfession === datas[key - 1].fullNameInstructorProfession && result[key - 1] === 0)) {
        result[firstIndex2]++;
        result[key] = 0;
      } else {
        result[key] = 1;
        Arr2[item.fullNameInstructorProfession] = key;
      }
    }
    return result;
  }, []);

  return (
    <div className="font-THSarabun-Psk text-[18pt]">
      <Fragment>
        <div className="px-[2cm]">
          <div className="flex justify-center  w-full">
            <img className="h-[3cm] w-[2.5cm] mb-[6pt]" src={LOGOKRUT} alt="" />
          </div>
          <div>
            <p className="text-center">คำสั่งมหาวิทยาลัยราชภัฏกาญจนบุรี</p>
            <p className="text-center">ที่ 0556 / {data?.data.year}</p>
            <p className="text-center">เรื่อง แต่งตั้งอาจารย์นิเทศก์นักศึกษาฝึกปฏิบัติการสอนในสถานศึกษา 1</p>
            <p className="text-center">.................................................................................</p>
          </div>
          <div>
            <p className="text-justify indent-[2.5cm]">
              ด้วยภาคเรียนที่ {data?.data.semester}/{data?.data.year} คณะครุศาสตร์ ได้ส่งนักศึกษาชั้นปีที่ 5 สาขาวิชาการศึกษา จำนวน 10 สาขาวิชา ออกฝึกปฏิบัติการสอนในสถานศึกษา 1 เป็นเวลา 1 ภาคเรียน
              ดังนั้นเพื่อให้การฝึก ปฏิบัติการวิชาชีพครูของนักศึกษาตังกล่าวเป็นไปอย่างมีประสิทธิภาพ มหาวิทยาลัยฯ จึงแต่งตั้งบุคคลดังมี รายชื่อต่อไปนี้เป็นอาจารย์นิเทศก์ ทำหน้าที่ดูแลให้คำแนะนำ
              และประเมินผลการฝึกปฏิบัติการสอนใน สถานศึกษา แก่นักศึกษาที่ปฏิบัติการสอนในโรงเรียนตามตารางที่แนบท้ายคำสั่งนี้
            </p>
            <div className="flex justify-center mt-5">
              <div>
                {data.instructor.map((item, index) => (
                  <p key={index}>
                    {index + 1}. {item}
                  </p>
                ))}
              </div>
            </div>

            <p className="text-center mt-[6pt]">
              สั่ง ณ วันที่ <DateTH date={Moment().format()} type="date" />
            </p>
            <br />
            <br />
            <br />
            <br />
            <div className="flex justify-end mr-[2.5cm] mt-[6pt]">
              <p className="text-center">
                (ผู้ช่วยศาสตราจารย์ ดร.พจนีย์ สุขชาวนา) <br />
                รองอธิการบตี ปฏิบัติราชการแทนอธิการบดี <br />
                มหาวิทยาลัยราชภัฏกาญจนบุรี
              </p>
            </div>
          </div>
        </div>
      </Fragment>
      <Fragment>
        <div className="page-break px-[1cm]">
          <p className="text-center">
            <span>เอกสารแนบท้ายคำสั่งที่ 0556/{data?.data.year}</span> <br />
            <span>เรื่อง แต่งตั้งอาจารย์นิเทศก์นักศึกษาฝึกปฏิบัติการสอนในสถานศึกษา 1</span> <br />
            <span>ภาคเรียนที่ {data?.data.semester} ปีการศึกษา {data?.data.year} </span>
          </p>
          <div>
            <table className="w-full text-[12pt]">
              <thead className="border-collapse border border-gray-400">
                <tr>
                  <th className="border border-gray-500 px-2 w-[15%] text-left">โรงเรียน/หน่วยฝึก</th>
                  <th className="border border-gray-500 px-2 w-[20%] text-left">ชื่อนักศึกษา</th>
                  <th className="border border-gray-500 px-2 w-[10%] text-left">เบอร์โทรศัพท์นักศึกษา</th>
                  <th className="border border-gray-500 px-2 w-[15%] text-left">สาขาวิชา</th>
                  <th className="border border-gray-500 px-2 w-[20%] text-left">อาจารย์นิเทศก์เอก</th>
                  <th className="border border-gray-500 px-2 w-[20%] text-left">อาจารย์นิเทศก์วิชาชีพครู</th>
                </tr>
              </thead>
              <tbody>
                {datas.map((item, index) => (
                  <tr className="align-top" key={index}>
                    {rowSpan[index] > 0 && (
                      <td rowSpan={rowSpan[index]} className="border border-gray-500 px-2 w-[20%]">
                        {item.schoolName}
                      </td>
                    )}
                    <td className="border border-gray-500 px-2 w-[20%]">{item.fullNameStud}</td>
                    <td className="border border-gray-500 px-2 w-[10%]">{item.phone}</td>
                    <td className="border border-gray-500 px-2 w-[15%]">{item.facultyName}</td>
                    {rowSpanfullNameInstructorMajor[index] > 0 && (
                      <td rowSpan={rowSpanfullNameInstructorMajor[index]} className="border border-gray-500 px-2 w-[20%]">
                        {item.fullNameInstructorMajor}
                      </td>
                    )}
                    {rowSpanfullNameInstructorProfession[index] > 0 && (
                      <td rowSpan={rowSpanfullNameInstructorProfession[index]} className="border border-gray-500 px-2 w-[20%]">
                        {item.fullNameInstructorProfession}
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </Fragment>
    </div>
  );
}
