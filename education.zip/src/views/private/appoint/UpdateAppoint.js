import React, { Fragment, useState, useEffect } from "react";
import { Form, Formik } from "formik";
import SVGSave from "../../../SVGS/SVGSave";
import SVGLoading from "../../../SVGS/SVGLoading";
import SVGReset from "../../../SVGS/SVGReset";
import { TextSelect } from "../../../components/TextSelect";
import { GetDropdown } from "../../../services/Dropdown.services";
import { UpdateAppiont } from "../../../services/Appoint.services";
import { MESSAGEERROR, MESSAGESUCCESS } from "../../../components/alert";
export default function UpdateAppoint({ setIsOpen, detailById, reset }) {
  const [instructor, setInstructor] = useState([]);
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    dropdown();
  }, []);
  async function dropdown() {
    let result = await GetDropdown();
    setInstructor(result.instructor);
  }
  const SAVE = async (data) => {
    setLoading(true);
    let res = await UpdateAppiont(data);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        MESSAGESUCCESS(res.message);
        setIsOpen({ open: false });
        reset();
      } else {
        MESSAGEERROR(res.message);
      }
    }
    setLoading(false);
  };
  return (
    <Fragment>
      <Formik
        initialValues={{
          appointId: detailById.appointId,
          instructorMajor: detailById.instructorMajor,
          instructorProfession: detailById.instructorProfession,
        }}
        enableReinitialize={true}
        onSubmit={(value) => {
          SAVE(value);
        }}
      >
        {({ values, setFieldValue }) => (
          <Form>
            <div className="">
              <div className="flex items-center mt-4 text-gray-700 justify-center gap-2 text-md">
                <h1 className="w-5/12 text-right">รหัสนักศึกษา</h1>
                <h1 className="w-1/12 text-center">:</h1>
                <h1 className="w-5/12 text-left">{detailById.studentId}</h1>
              </div>
              <div className="flex items-center mt-4 text-gray-700 justify-center gap-2 text-md">
                <h1 className="w-5/12 text-right">ชื่อนักศึกษา</h1>
                <h1 className="w-1/12 text-center">:</h1>
                <h1 className="w-5/12 text-left">{detailById.fullNameStud}</h1>
              </div>
              <div className="flex items-center mt-4 text-gray-700 justify-center gap-2 text-md">
                <h1 className="w-5/12 text-right">คณะ</h1>
                <h1 className="w-1/12 text-center">:</h1>
                <h1 className="w-5/12 text-left">{detailById.facultyName}</h1>
              </div>
              <div className="flex items-center mt-4 text-gray-700 justify-center gap-2 text-md">
                <h1 className="w-5/12 text-right">สาขา</h1>
                <h1 className="w-1/12 text-center">:</h1>
                <h1 className="w-5/12 text-left">{detailById.majorName}</h1>
              </div>
              <div className="flex items-center mt-4 text-gray-700 justify-center gap-2 text-md">
                <h1 className="w-5/12 text-right">ปีการศึกษา/เทอม</h1>
                <h1 className="w-1/12 text-center">:</h1>
                <h1 className="w-5/12 text-left">{detailById.year + "/" + detailById.semester}</h1>
              </div>
              <div className="flex items-center mt-4 text-gray-700 justify-center gap-2 text-md">
                <h1 className="w-5/12 text-right">ชื่อโรงเรียน</h1>
                <h1 className="w-1/12 text-center">:</h1>
                <h1 className="w-5/12 text-left">{detailById.schoolName}</h1>
              </div>
            </div>
            <div className="border-b-2 my-5" />
            <div className=" ">
              <div className="items-center -mx-2 md:flex">
                <div className="w-full mx-2">
                  <TextSelect
                    title="อาจารย์นิเทศก์เอก"
                    options={instructor}
                    name="instructorMajor"
                    value={instructor.filter((x) => x.userId === values.instructorMajor)}
                    placeholder="อาจารย์นิเทศก์เอก"
                    getOptionLabel={(x) => x.fullName}
                    getOptionValue={(x) => x.userId}
                    onChange={(e) => {
                      setFieldValue("instructorMajor", e.userId);
                    }}
                  />
                </div>
                <div className="w-full mx-2 mt-4 md:mt-0">
                  <TextSelect
                    title="อาจารย์นิเทศก์วิชาชีพครู"
                    options={instructor}
                    name="instructorProfession"
                    value={instructor.filter((x) => x.userId === values.instructorProfession)}
                    placeholder="อาจารย์นิเทศก์วิชาชีพครู"
                    getOptionLabel={(x) => x.fullName}
                    getOptionValue={(x) => x.userId}
                    onChange={(e) => {
                      setFieldValue("instructorProfession", e.userId);
                    }}
                  />
                </div>
              </div>
              <div className="w-full px-2">
                <div className="flex gap-3 justify-center my-5">
                  <button className={loading ? "buttonSave_disabled cursor-no-drop" : "buttonSave"} type="submit" disabled={loading ? true : false}>
                    {loading ? (
                      <div className="flex items-center justify-center text-center">
                        <SVGLoading width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" />
                        บันทึก
                      </div>
                    ) : (
                      <div className="flex items-center justify-center text-center">
                        <SVGSave width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> บันทึก
                      </div>
                    )}
                  </button>
                  <button className="buttonResetV1" type="reset">
                    <SVGReset width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> ล้างค่า
                  </button>
                </div>
              </div>
            </div>
          </Form>
        )}
      </Formik>
    </Fragment>
  );
}
