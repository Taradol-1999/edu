import React, { Fragment, useState, useEffect } from "react";
import CardBody from "@material-tailwind/react/CardBody";
import CardFooter from "@material-tailwind/react/CardFooter";
import DataAppoint from "./DataAppoint";
import SVGAdd from "../../../SVGS/SVGAdd";
import Pagination from "../../../components/Pagination";
import { TextSearch } from "../../../components/TextSearch";
import { SelectSearch } from "../../../components/SelectSearch";
import { SelectPageSize } from "../../../components/SelectPageSize";
import { useHistory } from "react-router-dom";
import { DelAppiont, LoadAppiont } from "../../../services/Appoint.services";
import LoadingData from "../../../components/LoadingData";
import { pageSize } from "../../../helper/data";
import Swal from "sweetalert2";
import { DElALERT, MESSAGESUCCESS, STATUSERROR } from "../../../components/alert";
import { GetDropdown } from "../../../services/Dropdown.services";
import MainPrint from "./MainPrint";
import SVGPrint from "../../../SVGS/SVGPrint";

export default function MainAppoint() {
  let history = useHistory();
  const [appiont, setAppiont] = useState([]);
  const [loading, setLoading] = useState(false);
  const [keyword, setKeyword] = useState("");
  const [year, setYear] = useState("");
  const [selectSemester, setSemester] = useState("");
  const [facId, setFacId] = useState(0);
  const [maId, setMaId] = useState(0);
  const [major, setMajor] = useState([]);
  const [faculty, setFaculty] = useState([]);
  const [openPrint, setOpenPrint] = useState(false);
  const [semesterSearch, setSemesterSearch] = useState([]);
  const [yearSearch, setYearSearch] = useState([]);
  const [pagin, setPagin] = useState({
    currentPage: 1,
    pageSize: 10,
    totalRows: 0,
    totalPages: 0,
  });

  useEffect(() => {
    LoadDataAppiont();
    loadDropdown();
  }, []);

  async function LoadDataAppiont(currentPage = 1, pageSize = 10, search = "", Year = "", Semester = "", FacId = 0, MaId = 0) {
    setLoading(true);
    let res = await LoadAppiont(currentPage, pageSize, search, Year, Semester, FacId, MaId);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        setPagin(res.pagin);
        setAppiont(res.data);
        setKeyword(search);
        setYear(Year);
        setMaId(MaId);
        setFacId(FacId);
        setSemester(Semester);
        setLoading(false);
      }
    }
  }

  function reset() {
    LoadDataAppiont(1, 10, "", "", "", 0, 0);
  }

  async function loadDropdown() {
    let result = await GetDropdown();
    setMajor(result.majors);
    setFaculty(result.faculty);
    setSemesterSearch(result.settingRegis.semester);
    setYearSearch(result.settingRegis.year);
  }

  function DELETE(code) {
    Swal.fire(DElALERT).then(async (result) => {
      if (result.isConfirmed) {
        let res = await DelAppiont(code);
        if (res) {
          if (res.taskStatus && res.statusCode === 200) {
            MESSAGESUCCESS(res.message);
            LoadDataAppiont();
          } else {
            STATUSERROR();
          }
        }
      }
    });
  }

  return (
    <Fragment>
      <MainPrint open={openPrint} setOpen={setOpenPrint} />
      <form onSubmit={(e) => e.preventDefault()}>
        <p className="text-blue-800 underline">แต่งตั้งอาจารย์นิเทศ</p>
        <div className="items-center mt-5 p-2 bg-white rounded hover:shadow-lg duration-300">
          <div className="grid lg:grid-cols-12 md:grid-cols-6 sm:grid-cols-4 grid-cols-4 md:gap-0 gap-2">
            <div className="lg:col-span-4 md:col-span-4 sm:col-span-4 col-span-4">
              <TextSearch
                placeholder="ค้นหา_รหัสนักศึกษา_ชื่อนักศึกษา_ชื่ออาจารย์นิเทศก์_โรงเรียน"
                onChange={(e) => {
                  setKeyword(e.target.value.trim());
                }}
                value={keyword}
              />
            </div>
            <div className="lg:col-span-1 md:col-span-2 sm:col-span-1 col-span-2">
              <SelectSearch
                placeholder="ปีการศึกษา"
                title="ปีการศึกษา"
                options={yearSearch}
                name="year"
                value={yearSearch.filter((x) => x.year === year)}
                getOptionLabel={(x) => x.year}
                getOptionValue={(x) => x.year}
                onChange={(e) => {
                  setYear(e.year);
                }}
              />
            </div>
            <div className="lg:col-span-1 md:col-span-2 sm:col-span-1 col-span-2">
              <SelectSearch
                options={semesterSearch}
                value={semesterSearch.filter((x) => x.semester === selectSemester)}
                placeholder="ภาคการศึกษา"
                getOptionLabel={(x) => x.semester}
                getOptionValue={(x) => x.semester}
                onChange={(e) => {
                  setSemester(e.semester);
                }}
              />
            </div>
            <div className="lg:col-span-2 md:col-span-2 sm:col-span-1 col-span-4">
              <SelectSearch
                placeholder="ค้นหา_คณะ"
                options={faculty}
                value={faculty.filter((x) => x.facultyId === facId)}
                getOptionLabel={(x) => x.facultyName}
                getOptionValue={(x) => x.facultyId}
                onChange={(e) => {
                  setFacId(e.facultyId);
                  setMaId(0);
                }}
              />
            </div>
            <div className="lg:col-span-2 md:col-span-2 sm:col-span-1 col-span-4">
              <SelectSearch
                placeholder="ค้นหา_สาขา"
                options={major.filter((x) => x.facultyId === facId)}
                value={major.filter((x) => x.majorId === maId)}
                getOptionLabel={(x) => x.majorName}
                getOptionValue={(x) => x.majorId}
                onChange={(e) => {
                  setMaId(e.majorId);
                }}
              />
            </div>
            <div className="lg:col-span-2 flex">
              <button
                className="buttonSearch"
                onClick={() => {
                  LoadDataAppiont(1, pagin.pageSize, keyword, year, selectSemester, facId, maId);
                }}
              >
                <span>ค้นหา</span>
              </button>
              <button type="reset" className="buttonReset" onClick={() => reset()}>
                <span>ล้างค่า</span>
              </button>
            </div>
          </div>
        </div>
      </form>
      <div className="flex justify-between mt-5">
        <SelectPageSize
          options={pageSize}
          getOptionLabel={(x) => x.name}
          getOptionValue={(x) => x.id}
          value={pageSize.filter((a) => a.id === pagin.pageSize)}
          onChange={(e) => {
            LoadDataAppiont(1, e.id, keyword, year, selectSemester, facId, maId);
          }}
        />
        <div className="flex justify-end">
          <button
            className="buttonAdd mr-2"
            onClick={() => {
              history.push("/MainAppoint/FormAppoint");
            }}
          >
            <SVGAdd width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> แต่งตั้งอาจารย์นิเทศก์
          </button>
          <button
            className="buttonPrint mr-2"
            onClick={() => {
              // handlePrint();
              setOpenPrint(true);
            }}
          >
            <SVGPrint width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> ปริ้นคำสั่งแต่งตั้ง
          </button>
        </div>
      </div>
      <CardBody>
        {loading ? (
          <div className="flex justify-center bg-transparent mt-52">
            <LoadingData />
          </div>
        ) : (
          <div className="overflow-auto">
            <DataAppoint
              appiont={appiont}
              pagin={pagin}
              retrunDelete={(code) => {
                DELETE(code);
              }}
              reset={reset}
            />
          </div>
        )}
      </CardBody>
      <CardFooter>
        <Pagination
          totalPage={pagin.pageCount}
          onChange={async (page) => {
            LoadDataAppiont(page, pagin.pageSize, keyword, year, selectSemester, facId, maId);
          }}
          currentPages={pagin.currentPage}
          totalRow={pagin.rowCount}
        />
      </CardFooter>
    </Fragment>
  );
}
