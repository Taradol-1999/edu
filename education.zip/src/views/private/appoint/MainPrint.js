import { Form, Formik } from "formik";
import React, { useEffect, useRef, useState } from "react";
import Modal from "../../../components/Modal";
import { PrintAppoint } from "../../../services/Appoint.services";
import { object, string } from "yup";
import { TextSelect } from "../../../components/TextSelect";
import { GetDropdown } from "../../../services/Dropdown.services";
import AppointmentOrder from "./pdf-apponint/AppointmentOrder";
import { useReactToPrint } from "react-to-print";
import { STATUSWARNING } from "../../../components/alert";

export default function MainPrint({ open, setOpen }) {
  const [print, setPrint] = useState(false);
  const [school, setSchool] = useState([]);
  const componentRef = useRef();
  const [semesterSearch, setSemesterSearch] = useState([]);
  const [yearSearch, setYearSearch] = useState([]);

  useEffect(() => {
    dropdown();
  }, []);

  async function dropdown() {
    let res = await GetDropdown();
    if (res) {
      setSchool(res.school);
      setSemesterSearch(res.settingRegis.semester);
      setYearSearch(res.settingRegis.year);
    }
  }

  async function PrintAppoints(Year, Semester, School) {
    let res = await PrintAppoint(Year, Semester, School);
    if (res.statusCode === 200 && res.taskStatus) {
      if (res.data.dataAll.length > 0) {
        setPrint(res.data);
        handlePrint();
      } else {
        STATUSWARNING();
      }
    }
  }

  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
    onAfterPrint: () => setPrint(false),
  });

  const validate = object({
    year: string().required("กรุณาเลือก ปีการศึกษา"),
    semester: string().required("กรุณาเลือก เทอม"),
  });

  return (
    <Modal
      width="max-w-4xl"
      isOpen={open}
      title="คำสั่งแต่งตั้งอาจารย์นิเทศก์"
      onClose={() => {
        setOpen(false);
      }}
    >
      <Formik
        validationSchema={validate}
        initialValues={{
          year: "",
          semester: "",
          schoolId: "",
        }}
        enableReinitialize={true}
        onSubmit={async (values) => {
          await PrintAppoints(values.year, values.semester, values.schoolId);
        }}
      >
        {({ values, setFieldValue }) => (
          <Form>
            <div className="flex flex-wrap py-2 ">
              <div className="w-1/3">
                <TextSelect
                  title="ปีการศึกษา"
                  placeholder="ปีการศึกษา"
                  options={yearSearch}
                  name="year"
                  value={yearSearch.filter((x) => x.year === values.year)}
                  getOptionLabel={(x) => x.year}
                  getOptionValue={(x) => x.year}
                  onChange={(e) => {
                    setFieldValue("year", e.year);
                  }}
                />
              </div>
              <div className="w-1/3 px-2">
                <TextSelect
                  title="ภาคการศึกษา"
                  options={semesterSearch}
                  name="semester"
                  value={semesterSearch.filter((x) => x.semester === values.semester)}
                  placeholder="ภาคการศึกษา"
                  getOptionLabel={(x) => x.semester}
                  getOptionValue={(x) => x.semester}
                  onChange={(e) => {
                    setFieldValue("semester", e.semester);
                  }}
                />
              </div>
              <div className="w-1/3">
                <TextSelect
                  title="โรงเรียน"
                  options={school}
                  name="schoolId"
                  value={school.filter((x) => x.schoolId === values.schoolId)}
                  placeholder="โรงเรียน"
                  getOptionLabel={(x) => "โรงเรียน " + x.schoolName}
                  getOptionValue={(x) => x.schoolId}
                  onChange={(e) => {
                    setFieldValue("schoolId", e.schoolId);
                  }}
                />
              </div>
            </div>
            <div className="flex justify-center">
              <button type="submit" className="buttonSearch">
                ปริ้น
              </button>
              <button type="reset" className="buttonReset">
                ล้างค่า
              </button>
            </div>
          </Form>
        )}
      </Formik>

      {print && (
        <div className="hidden">
          <div ref={componentRef}>
            <AppointmentOrder data={print} />
          </div>
        </div>
      )}
    </Modal>
  );
}
