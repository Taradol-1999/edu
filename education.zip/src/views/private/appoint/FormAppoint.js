import React, { Fragment, useState, useEffect } from "react";
import SVGSave from "../../../SVGS/SVGSave";
import SVGReset from "../../../SVGS/SVGReset";
import { useHistory } from "react-router-dom";
import { TextField } from "../../../components/TextField";
import { TextSelect } from "../../../components/TextSelect";
import SVGLoading from "../../../SVGS/SVGLoading";
import { GetDropdown, GetDropdownSchoolByYear } from "../../../services/Dropdown.services";
import notFound from "../../../assets/img/image-not-found.jpg";
import { Formik, Form, FieldArray } from "formik";
import { RegisAppiont, SearchRegister } from "../../../services/Appoint.services";
import { MESSAGEERROR, MESSAGESUCCESS } from "../../../components/alert";
import LoadingData from "../../../components/LoadingData";
import { validateAppoint } from "./Validate";
import BtnGoBack from "../../../components/BtnGoBack";

export default function FormAppoint() {
  let history = useHistory();
  const [school, setSchool] = useState([]);
  const [instructor, setInstructor] = useState([]);
  const [searchRegis, setSearchRegister] = useState([]);
  const [searchYear, setYear] = useState("");
  const [searchSemester, setSemester] = useState("");
  const [searchSchool, setSchoolId] = useState("");
  const [logoUrl, setLogoUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [loadingSearch, setLoadingSearch] = useState(false);
  const [semesterSearch, setSemesterSearch] = useState([]);
  const [yearSearch, setYearSearch] = useState([]);

  useEffect(() => {
    dropdown();
  }, []);
  async function dropdown() {
    let result = await GetDropdown();
    setSchool(result.school);
    setInstructor(result.instructor);

    setSemesterSearch(result.settingRegis.semester);
    setYearSearch(result.settingRegis.year);
  }

  async function GetDropdownSchool(year = "", semester = "") {
    let res = await GetDropdownSchoolByYear(year, semester);
    setSchool(res);
  }

  async function SearchRegis(Year = "", Semester = "", School = "") {
    setLoadingSearch(true);
    let res = await SearchRegister(Year, Semester, School);
    if (res) {
      setSearchRegister(res.data);
      setYear(Year);
      setSemester(Semester);
      setSchoolId(School);
      setLoadingSearch(false);
    }
  }
  const SAVE = async (data) => {
    setLoading(true);
    let res = await RegisAppiont(data);
    if (res) {
      if (res.statusCode === 200 && res.taskStatus) {
        MESSAGESUCCESS(res.message);
        SearchRegis("", "", "");
        setLogoUrl("");
      } else {
        MESSAGEERROR(res.message);
      }
    }
    setLoading(false);
  };
  return (
    <Fragment>
      <Formik
        validationSchema={validateAppoint}
        initialValues={{
          appointArray: searchRegis ? searchRegis : [],
        }}
        enableReinitialize={true}
        onSubmit={async (values) => {
          await SAVE(values);
        }}
      >
        {({ values, setFieldValue }) => (
          <Form>
            <div className="flex flex-wrap mx-auto ">
              <div className="w-full flex justify-between items-end">
                <p className="text-blue-900 text-lg">แต่งตั้งอาจารย์</p>
                <BtnGoBack onClick={() => history.goBack()} />
              </div>
            </div>
            <div className="mt-2 border-b border-gray-400" />
            <div className="flex flex-wrap mt-5">
              <div className="p-1 xl:w-1/4 lg:w-1/3 md:w-1/2">
                <div className="h-full p-6 rounded-lg border-2 border-blue-600 flex flex-col relative">
                  <span className="bg-blue-600 text-white px-3 py-1 tracking-widest text-sm absolute right-0 top-0 rounded-bl">ค้นหา</span>
                  <div className="flex items-center justify-center">
                    <div className="w-32 h-32 my-2">
                      <img src={logoUrl ? logoUrl : notFound} alt="" className="w-full h-full bg-transparent" />
                    </div>
                  </div>
                  <TextSelect
                    placeholder="ปีการศึกษา"
                    title="ปีการศึกษา"
                    options={yearSearch}
                    name="year"
                    value={yearSearch.filter((x) => x.year === searchYear)}
                    getOptionLabel={(x) => x.year}
                    getOptionValue={(x) => x.year}
                    onChange={(e) => {
                      setYear(e.year);
                      GetDropdownSchool(e.year, searchSemester);
                    }}
                    reset="show"
                    onClickReset={() => setYear("")}
                  />
                  <TextSelect
                    options={semesterSearch}
                    title="เทอม"
                    name="semester"
                    value={semesterSearch.filter((x) => x.semester === searchSemester)}
                    placeholder="เทอม"
                    getOptionLabel={(x) => x.semester}
                    getOptionValue={(x) => x.semester}
                    onChange={(e) => {
                      setSemester(e.semester);
                      GetDropdownSchool(searchYear, e.semester);
                    }}
                    reset="show"
                    onClickReset={() => setSemester("")}
                  />
                  <TextSelect
                    options={school}
                    name="schoolId"
                    title="โรงเรียน"
                    value={school.filter((x) => x.schoolId === searchSchool)}
                    placeholder="โรงเรียน"
                    getOptionLabel={(x) => "โรงเรียน " + x.schoolName}
                    getOptionValue={(x) => x.schoolId}
                    onChange={(e) => {
                      setSchoolId(e.schoolId);
                      setLogoUrl(e.logoUrl);
                    }}
                    reset="show"
                    onClickReset={() => setSchoolId("")}
                  />
                  <p className="text-xs text-red-500 mt-3">! โปรดเลือก (ถ้ายังไม่มีการเลือกระบบจะแสดงข้อมูลการลงทะเบียนทั้งหมดที่ยังไม่มีการแต่งตั้ง)</p>
                  <button
                    type="button"
                    onClick={() => {
                      SearchRegis(searchYear, searchSemester, searchSchool);
                    }}
                    className={`flex items-center mt-auto text-white focus:outline-none  border-0 py-2 px-4 w-full rounded hover:bg-blue-500 bg-blue-400`}
                  >
                    ค้นหา
                  </button>
                </div>
              </div>
              <div className="p-1 xl:w-3/4 lg:w-2/3 md:w-1/2">
                <div className="h-full p-6 rounded-lg border-2 border-blue-600 flex flex-col relative">
                  <span className="bg-blue-600 text-white px-3 py-1 tracking-widest text-sm absolute right-0 top-0 rounded-bl">แต่งตั้ง</span>
                  {loadingSearch ? (
                    <div className="flex justify-center items-center h-full">
                      <LoadingData />
                    </div>
                  ) : searchRegis.length > 0 ? (
                    <div>
                      <div className="flex flex-wrap ml-1">
                        <div className="xl:w-1/3">
                          <p>นักศึกษา</p>
                        </div>
                        <div className="xl:w-1/3">
                          <p>อาจารย์นิเทศก์เอก</p>
                        </div>
                        <div className="xl:w-1/3">
                          <p>อาจารย์นิเทศก์วิชาชีพครู</p>
                        </div>
                      </div>
                      <FieldArray name="appointArray">
                        {({ insert, remove, push }) => (
                          <div>
                            {values.appointArray.map((item, index) => (
                              <div key={index} className="flex flex-wrap">
                                <div className="xl:w-1/3">
                                  <TextField
                                    name={`appointArray.${index}.student`}
                                    value={item.fullName + " สาขา " + item.majorName}
                                    placeholder="นักศึกษา"
                                    disabled
                                    onChange={(e) => {
                                      setFieldValue(`appointArray.${index}.student`, e.schoolId);
                                    }}
                                  />
                                </div>
                                <div className="xl:w-1/3">
                                  <TextSelect
                                    options={instructor}
                                    name={`appointArray.${index}.instructorMajor`}
                                    value={instructor.filter((x) => x.userId === values.appointArray[index].instructorMajor)}
                                    placeholder="อาจารย์นิเทศก์เอก"
                                    getOptionLabel={(x) => (
                                      <p>
                                        <span>{x.fullName}</span>
                                        <span>{" คณะ " + x.facultyName}</span>
                                        <span>{" สาขา " + x.majorName}</span>
                                      </p>
                                    )}
                                    getOptionValue={(x) => x.userId}
                                    onChange={(e) => {
                                      setFieldValue(`appointArray.${index}.instructorMajor`, e.userId);
                                    }}
                                  />
                                </div>
                                <div className="xl:w-1/3">
                                  <TextSelect
                                    options={instructor}
                                    name={`appointArray.${index}.instructorProfession`}
                                    value={instructor.filter((x) => x.userId === values.appointArray[index].instructorProfession)}
                                    placeholder="อาจารย์นิเทศก์วิชาชีพครู"
                                    getOptionLabel={(x) => (
                                      <p>
                                        <span>{x.fullName}</span>
                                        <span>{" คณะ " + x.facultyName}</span>
                                        <span>{" สาขา " + x.majorName}</span>
                                      </p>
                                    )}
                                    getOptionValue={(x) => x.userId}
                                    onChange={(e) => {
                                      setFieldValue(`appointArray.${index}.instructorProfession`, e.userId);
                                    }}
                                  />
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </FieldArray>
                      {/* <p className="text-xs text-gray-500 mt-3">Literally you probably haven't heard of them jean shorts.</p> */}
                    </div>
                  ) : (
                    <div className="flex justify-center items-center h-full">
                      <p className="text-red-600 text-3xl items-center">"โปรดเลือก เทอม/ปีการศึกษา"</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
            <div className="w-full px-2">
              <div className="flex gap-3 justify-center my-5">
                <button
                  className={loading === true || values.appointArray.length === 0 ? "buttonSave_disabled cursor-no-drop" : "buttonSave"}
                  type="submit"
                  disabled={loading === true || values.appointArray.length === 0 ? true : false}
                >
                  {loading ? (
                    <div className="flex items-center justify-center text-center">
                      <SVGLoading width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" />
                      บันทึก
                    </div>
                  ) : (
                    <div className="flex items-center justify-center text-center">
                      <SVGSave width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> บันทึก
                    </div>
                  )}
                </button>
                <button
                  className="buttonResetV1"
                  type="reset"
                  onClick={() => {
                    setLoading(false);
                    SearchRegis("", "", "");
                    setLogoUrl("");
                  }}
                >
                  <SVGReset width="24" height="24" color="#FFFFFF" strokeWidth="2" className="mr-2" /> ล้างค่า
                </button>
              </div>
            </div>
          </Form>
        )}
      </Formik>
    </Fragment>
  );
}
