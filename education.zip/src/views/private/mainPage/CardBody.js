import React, { Fragment } from "react";
import ReactApexChart from "react-apexcharts";
import Chart from "react-apexcharts";
import { BackYears } from "../../../components/BackYears";
export default function CardBody({ major, loading, term, year, back5Years, countRegisterByMajor }) {
  var regisText = "จำนวนลงทะเบียน " + (term ? (year ? year : "") : year ? "ปี " + year : "") + (year && term ? "/" : "") + (year ? (term ? +term : "") : term ? "เทอม " + term : "");
  var countByMajor = countRegisterByMajor.split(",").map((x) => (x ? parseInt(x) : 0));
  var back5 = back5Years.split(",").map((x) => (x ? parseInt(x) : 0));

  const dataRegis = {
    options: {
      chart: {
        id: "basic-bar",
        fontFamily: "Kanit",
        toolbar: {
          show: true,
          offsetX: 0,
          offsetY: 0,
          export: {
            csv: {
              filename: regisText + "-csv",
              columnDelimiter: ",",
              headerCategory: "category",
              headerValue: "value",
              dateFormatter(timestamp) {
                return new Date(timestamp).toDateString();
              },
            },
            svg: {
              filename: regisText + "-svg",
            },
            png: {
              filename: regisText + "-png",
            },
          },
          autoSelected: "zoom",
        },
      },
      xaxis: {
        categories: major.map((x) => x.majorName),
      },
      title: {
        text: "จำนวนลงทะเบียน " + (term ? (year ? year : "") : year ? "ปี " + year : "") + (year && term ? "/" : "") + (year ? (term ? +term : "") : term ? "เทอม " + term : ""),
        align: "left",
        margin: 10,
        offsetX: 0,
        offsetY: 0,
        floating: false,
        style: {
          fontSize: "20px",
          fontWeight: "bold",
        },
      },
    },
    series: [
      {
        name: "จำนวน",
        data: countByMajor,
      },
    ],
  };
  const dataBack5 = {
    series: back5,
    options: {
      chart: {
        type: "pie",
        fontFamily: "Kanit",
        toolbar: {
          show: true,
          offsetX: 0,
          offsetY: 0,
          export: {
            csv: {
              filename: "5 ปีล่าสุด-csv",
              columnDelimiter: ",",
              headerCategory: "category",
              headerValue: "value",
              dateFormatter(timestamp) {
                return new Date(timestamp).toDateString();
              },
            },
            svg: {
              filename: "5 ปีล่าสุด-svg",
            },
            png: {
              filename: "5 ปีล่าสุด-png",
            },
          },
          autoSelected: "zoom",
        },
      },
      fill: {
        type: "gradient",
      },
      title: {
        text: "จำนวนการลงทะเบียน 5 ปีล่าสุด",
        align: "left",
        margin: 10,
        offsetX: 0,
        offsetY: 0,
        floating: false,
        style: {
          fontSize: "20px",
          fontWeight: "bold",
        },
      },
      labels: BackYears(5).map((x) => "ปี : " + x.YearTH),
    },
  };

  return (
    <Fragment>
      {loading ? (
        <div className="py-4 mx-auto animate-pulse">
          <div className="flex flex-wrap">
            <div className="lg:w-3/5 mb-10 pr-2">
              <div className="rounded bg-gray-100 h-9" />
              <div className="flex mx-auto my-4 text-white bg-gray-100 rounded h-[30rem] w-full" />
            </div>
            <div className="lg:w-2/5 mb-10 pl-2">
              <div className="rounded bg-gray-100 h-9" />
              <div className="flex mx-auto my-4 text-white bg-gray-100 rounded-full h-[30rem] w-[30rem]" />
            </div>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-y-10 gap-x-6 sm:grid-cols-1 lg:grid-cols-2 mt-5 gap-4 ">
          <div className="overflow-auto">
            <div className="flex text-blue-900 rounded h-128 w-full ">
              <Chart options={dataRegis.options} series={dataRegis.series} type="bar" width="790" />
            </div>
          </div>
          <div className="overflow-auto">
            <div className="flex mx-auto my-4 text-blue-700 rounded-full h-128 w-128 ">
              <ReactApexChart options={dataBack5.options} series={dataBack5.series} type="pie" width={600} />
            </div>
          </div>
        </div>
      )}
    </Fragment>
  );
}
