/* eslint-disable react-hooks/exhaustive-deps */
import React, { Fragment, useState, useEffect } from "react";
import { BackYears } from "../../../components/BackYears";
import { SelectSearch } from "../../../components/SelectSearch";
import { DataDashboard } from "../../../services/Dashboard.services";
import CardBody from "./CardBody";
import CardHeader from "./CardHeader";
import { GetDropdown } from "../../../services/Dropdown.services";

export default function MainPage() {
  const [major, setMajor] = useState([]);
  const [student, setStudent] = useState([]);
  const [regis, setRegis] = useState([]);
  const [school, setSchool] = useState([]);
  const [instructor, setInstructor] = useState([]);
  const [loading, setLoading] = useState(false);
  const [year, setYear] = useState("");
  const [term, setSemester] = useState("");
  const [FacId, setFacId] = useState(0);
  const [countRegisterByMajor, setCountRegisterByMajor] = useState("");

  const [semesterSearch, setSemesterSearch] = useState([]);
  const [yearSearch, setYearSearch] = useState([]);

  const [back5Years, setBack5Years] = useState("");
  const back5 = BackYears(5)
    .map((x) => x.YearTH)
    .toString();

  useEffect(() => {
    loadData();
    loadDropdown();
  }, []);

  async function loadData(Year = "", Semester = "") {
    setLoading(true);
    let res = await DataDashboard(Year, Semester, back5);
    if (res) {
      if (res.taskStatus && res.statusCode === 200) {
        setMajor(res.data.major);
        setStudent(res.data.student);
        setRegis(res.data.regis);
        setSchool(res.data.school);
        setInstructor(res.data.instructor);
        setCountRegisterByMajor(res.data.countRegisterByMajor);
        setBack5Years(res.data.back5Years);
        setYear(Year);
        setSemester(Semester);
        setLoading(false);
        setFacId(FacId);
      }
    }
  }
  async function loadDropdown() {
    let result = await GetDropdown();
    if (result) {
      setSemesterSearch(result.settingRegis.semester);
      setYearSearch(result.settingRegis.year);
    }
  }

  return (
    <Fragment>
      <p className="text-blue-800 underline">แดชบอร์ด</p>
      <div className="grid grid-cols-6 gap-4">
        <div className="col-start-4 col-end-6 grid grid-cols-2 gap-4">
          <SelectSearch
            placeholder="ปีการศึกษา"
            title="ปีการศึกษา"
            options={yearSearch}
            name="year"
            value={yearSearch.filter((x) => x.year === year)}
            getOptionLabel={(x) => x.year}
            getOptionValue={(x) => x.year}
            onChange={(e) => {
              loadData(e.year, term);
            }}
          />
          <SelectSearch
            options={semesterSearch}
            value={semesterSearch.filter((x) => x.semester === term)}
            placeholder="ภาคการศึกษา"
            getOptionLabel={(x) => x.semester}
            getOptionValue={(x) => x.semester}
            onChange={(e) => {
              loadData(year, e.semester);
            }}
          />
        </div>
        <button
          type="reset"
          className="buttonReset w-full"
          onClick={() => {
            loadData("", "");
          }}
        >
          <span>ล้างค่า</span>
        </button>
      </div>
      <div className="border-b border-l border-r border-blue-400 my-4" />
      <CardHeader loading={loading} student={student} regis={regis} term={term} year={year} school={school} instructor={instructor} />
      <CardBody major={major} loading={loading} regis={regis} term={term} year={year} back5Years={back5Years} countRegisterByMajor={countRegisterByMajor} />
    </Fragment>
  );
}
