import React, { Fragment } from "react";

export default function CardHeader({ loading, student, regis, term, year, school, instructor }) {
  const data = [
    {
      id: 1,
      name: "จำนวนนักศึกษา",
      length: student.length,
    },
    {
      id: 2,
      name: "จำนวนอาจารย์",
      length: instructor.length,
    },
    {
      id: 3,
      name: "จำนวนโรงเรียน",
      length: school.length,
    },
    {
      id: 4,
      name: "จำนวนลงทะเบียน " + (term ? (year ? year : "") : year ? "ปี " + year : "") + (year && term ? "/" : "") + (year ? (term ? +term : "") : term ? "เทอม " + term : ""),
      length: regis.length,
    },
  ];
  return (
    <Fragment>
      {loading ? (
        <div className="mt-6 grid grid-cols-1 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-4 xl:gap-x-8">
          {data.map((item) => (
            <div key={item.id}>
              <div className="bg-gray-100 rounded h-32" />
            </div>
          ))}
        </div>
      ) : (
        <div className="mt-6 grid grid-cols-1 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-4 xl:gap-x-8">
          {data.map((item) => (
            <div key={item.id}>
              <div className="group shadow-lg hover:shadow-xl hover:scale-105 duration-200 delay-75  bg-white rounded-sm py-6 pr-6 pl-9 border-l-8 border-blue-600 hover:border-red-600">
                <p className="text-2xl font-bold text-gray-700 group-hover:text-gray-700"> {item.name} </p>
                <p className="text-4xl font-semibold text-gray-700 group-hover:text-gray-700 mt-2 leading-6">{item.length}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </Fragment>
  );
}
