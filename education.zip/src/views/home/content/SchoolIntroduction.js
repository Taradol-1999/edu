import React, { Fragment, useEffect, useState } from "react";
import { TopSchool } from "../../../services/School.services";
import SVGArrowRight from "../../../SVGS/SVGArrowRight";
export default function SchoolIntroduction() {
  const [top10, setTop10] = useState([]);

  useEffect(() => {
    loadData(10);
  }, []);

  async function loadData(num) {
    let result = await TopSchool(num);
    if (result) {
      setTop10(result.data);
      // setTop4t010(result.data.filter((value, index) => index > 2));
    }
  }
  const color = [
    { id: 1, fill: "fill-yellow-800", bgcolor: "bg-yellow-200", hover: "to-yellow-600", text: "text-yellow-900", text2: "text-yellow-800" },
    { id: 2, fill: "fill-amber-800", bgcolor: "bg-amber-200", hover: "to-amber-600", text: "text-amber-900", text2: "text-amber-800" },
    { id: 3, fill: "fill-orange-800", bgcolor: "bg-orange-200", hover: "to-orange-600", text: "text-orange-900", text2: "text-orange-800" },
    { id: 4, fill: "fill-red-800", bgcolor: "bg-red-200", hover: "to-red-600", text: "text-red-900", text2: "text-red-800" },
    { id: 5, fill: "fill-rose-800", bgcolor: "bg-rose-200", hover: "to-rose-600", text: "text-rose-900", text2: "text-rose-800" },
    { id: 6, fill: "fill-fuchsia-800", bgcolor: "bg-fuchsia-200", hover: "to-fuchsia-600", text: "text-fuchsia-900", text2: "text-fuchsia-800" },
    { id: 7, fill: "fill-blue-800", bgcolor: "bg-blue-200", hover: "to-blue-600", text: "text-blue-900", text2: "text-blue-800" },
    { id: 8, fill: "fill-green-800", bgcolor: "bg-green-200", hover: "to-green-600", text: "text-green-900", text2: "text-green-800" },
    { id: 9, fill: "fill-lime-800", bgcolor: "bg-lime-200", hover: "to-lime-600", text: "text-lime-900", text2: "text-lime-800" },
    { id: 10, fill: "fill-gray-800", bgcolor: "bg-gray-200", hover: "to-gray-600", text: "text-gray-900", text2: "text-gray-800" },
  ];

  const resColor = [];
  for (var j = 0; j < top10.length; j++) {
    let res = { ...top10[j], fill: color[j].fill, bgcolor: color[j].bgcolor, hover: color[j].hover, text: color[j].text, text2: color[j].text2 };
    resColor.push(res);
  }

  return (
    <Fragment>
      <div className="mb-5">
        <h3 className="text-center font-bold title">10 อันดับโรงเรียนที่มีนักศึกษาฝึกประสบการณ์มากที่สุด</h3>
      </div>
      <div className="px-20 space-y-5">
        {resColor.map((item, index) => (
          <div key={index} className={`relative flex flex-col justify-end rounded-b-xl ${index === 0 ? "scale-110" : index === 1 ? "scale-105" : index === 2 ? "scale-100" : "scale-95"}`}>
            <div
              className={`${item.bgcolor} before:${item.hover} group relative  flex cursor-pointer justify-between rounded-xl before:absolute before:inset-y-0 before:right-0 before:w-1/2 before:rounded-r-xl before:bg-gradient-to-r before:from-transparent before:opacity-0 before:transition before:duration-500 hover:before:opacity-100`}
            >
              <div className="relative space-y-1 p-4 flex items-center ">
                <p className={`text-lg font-bold px-5 ${item.text}`}>อันดับที่ {index + 1}</p>
                <div>
                  <h4 className={`text-lg ${item.text}`}>{item.schoolName}</h4>
                  <div className={`relative h-6 ${item.text2} text-sm`}>
                    <span className="transition duration-500 group-hover:invisible group-hover:opacity-0">ที่อยู่ : {item.address}</span>
                    <a href="/" className="flex items-center invisible absolute left-0 top-0 translate-y-3 transition duration-500 group-hover:visible group-hover:translate-y-0 ">
                      <span className="underline">รายละเอียด</span>
                      <SVGArrowRight width="24" height="24" strokeWidth="2" className={`${item.fill}`} />
                    </a>
                  </div>
                </div>
              </div>
              <img className="absolute bottom-0 right-6 w-[6rem] transition duration-500 group-hover:scale-[1.4]" src={item.image} alt={item.schoolName} />
            </div>
          </div>
        ))}
      </div>
    </Fragment>
  );
}
