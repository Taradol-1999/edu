import React, { Fragment, useEffect, useState } from "react";
import { TopSchool } from "../../../services/School.services";
import SVGArrowRight from "../../../SVGS/SVGArrowRight";
export default function SchoolIntroduction() {
  const [top3, setTop3] = useState([]);
  const [top4t010, setTop4t010] = useState([]);

  useEffect(() => {
    loadData(10);
  }, []);
  async function loadData(num) {
    let result = await TopSchool(num);
    if (result) {
      setTop3(result.data.filter((value, index) => index <= 2));
      setTop4t010(result.data.filter((value, index) => index > 2));
    }
  }
  const color = [
    { id: 1, fill: "fill-amber-200", bgcolor: "bg-amber-200", hover: "to-amber-600", text: "text-amber-900", text2: "text-amber-800" },
    { id: 2, fill: "fill-amber-200", bgcolor: "bg-orange-200", hover: "to-orange-600", text: "text-orange-900", text2: "text-orange-800" },
    { id: 3, fill: "fill-amber-200", bgcolor: "bg-rose-200", hover: "to-rose-600", text: "text-rose-900", text2: "text-rose-800" },
    { id: 4, fill: "fill-amber-200", bgcolor: "bg-fuchsia-200", hover: "to-fuchsia-600", text: "text-fuchsia-900", text2: "text-fuchsia-800" },
    { id: 5, fill: "fill-amber-200", bgcolor: "bg-blue-200", hover: "to-blue-600", text: "text-blue-900", text2: "text-blue-800" },
    { id: 6, fill: "fill-amber-200", bgcolor: "bg-green-200", hover: "to-green-600", text: "text-green-900", text2: "text-green-800" },
    { id: 7, fill: "fill-amber-200", bgcolor: "bg-yellow-200", hover: "to-yellow-600", text: "text-yellow-900", text2: "text-yellow-800" },
  ];

  const resColor = [];
  for (var j = 0; j < top4t010.length; j++) {
    let res = { ...top4t010[j], bgcolor: color[j].bgcolor, hover: color[j].hover, text: color[j].text, text2: color[j].text2 };
    resColor.push(res);
  }

  const ranking = [];
  for (var i = 0; i < top3.length; i++) {
    if (i === 0) {
      ranking.push(top3[1]);
    } else if (i === 1) {
      ranking.push(top3[0]);
    } else if (i === 2) {
      ranking.push(top3[2]);
    }
  }
  return (
    <Fragment>
      <div className="mb-5">
        <h3 className="text-center font-bold title">10 อันดับโรงเรียนที่มีนักศึกษาฝึกประสบการณ์มากที่สุด</h3>
      </div>
      <div className="grid grid-cols-3 gap-x-4">
        {ranking.map((item, index) => (
          <div key={index} className={`responsive-ranking relative group overflow-hidden bg-white m-auto drop-shadow-3xl rounded-xl ${index !== 1 ? "mt-[5rem]" : "mt-0"}`}>
            <img className="object-contain w-full h-full transform duration-700 backdrop-opacity-100" src={item.image} alt={item.schoolName} />
            <div className="absolute w-full h-full shadow-2xl opacity-20 transform duration-500 inset-y-full group-hover:-inset-y-0" />
            <div className="absolute bg-gradient-to-t from-black to-transparent w-full h-full transform duration-500 inset-y-2/4 group-hover:-inset-y-0">
              <p className="drop-shadow-black-2 capitalize font-bold title-card text-center text-white lg:mt-10 mt-5 group-hover:underline">อันดับที่ {index === 0 ? 2 : index === 1 ? 1 : 3}</p>
              <div className="absolute w-full flex place-content-center">
                <p className="drop-shadow-black-2 capitalize font-bold title-card text-center text-white lg:mt-10 mt-5">{item.schoolName}</p>
              </div>
              <div className="absolute w-full flex place-content-center mt-[6rem]">
                <p className="text-center w-4/5 text-white mt-5">
                  <span className="font-bold"> ที่อยู่</span>
                  <br /> {item.address}
                </p>
              </div>
              <div className="flex justify-center">
                <button className="absolute bottom-4  text-white font-bold rounded-lg h-10 w-32 bg-blue-600 hover:bg-blue-800">รายละเอียด</button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="px-20">
        {resColor.map((item, index) => (
          <div key={index} className="relative flex flex-col justify-end overflow-hidden rounded-b-xl pt-6">
            <div
              className={`${item.bgcolor} before:${item.hover} group relative flex cursor-pointer justify-between rounded-xl before:absolute before:inset-y-0 before:right-0 before:w-1/2 before:rounded-r-xl before:bg-gradient-to-r before:from-transparent before:opacity-0 before:transition before:duration-500 hover:before:opacity-100`}
            >
              <div className="relative space-y-1 p-4 flex items-center ">
                <p className={`text-lg font-bold px-5 ${item.text}`}>อันดับที่ {index + 4}</p>
                <div>
                  <h4 className={`text-lg ${item.text}`}>{item.schoolName}</h4>
                  <div className={`relative h-6 ${item.text2} text-sm`}>
                    <span className="transition duration-500 group-hover:invisible group-hover:opacity-0">ที่อยู่ : {item.address}</span>
                    <a href className="flex items-center invisible absolute left-0 top-0 translate-y-3 transition duration-500 group-hover:visible group-hover:translate-y-0 ">
                      <span className="underline">รายละเอียด</span>
                      <SVGArrowRight width="24" height="24" strokeWidth="2" className="fill-amber-800" />
                    </a>
                  </div>
                </div>
              </div>
              <img className="absolute bottom-0 right-6 w-[6rem] transition duration-500 group-hover:scale-[1.4] hover:z-10" src={item.image} alt={item.schoolName} />
            </div>
          </div>
        ))}
      </div>

      {/* <div className="mt-4">
        <div className="relative flex flex-col justify-end overflow-hidden rounded-b-xl pt-6">
          <div className="group relative flex cursor-pointer justify-between rounded-xl bg-amber-200 before:absolute before:inset-y-0 before:right-0 before:w-1/2 before:rounded-r-xl before:bg-gradient-to-r before:from-transparent before:to-amber-600 before:opacity-0 before:transition before:duration-500 hover:before:opacity-100">
            <div className="relative  space-y-1 p-4">
              <h4 className="text-lg text-amber-900">Smooth Criminal</h4>
              <div className="relative h-6 text-amber-800 text-sm">
                <span className="transition duration-300 group-hover:invisible group-hover:opacity-0">Michael Jackson</span>
                <a
                  href
                  className="flex items-center gap-3 invisible absolute left-0 top-0 translate-y-3 transition duration-300 group-hover:visible group-hover:translate-y-0"
                >
                  <span>Listen now </span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-4 w-4 -translate-x-4 transition duration-300 group-hover:translate-x-0"
                    viewBox="0 0 20 20"
                    fill="currentColor"
                  >
                    <path
                      fillRule="evenodd"
                      d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z"
                      clipRule="evenodd"
                    />
                  </svg>
                </a>
              </div>
            </div>
            <img
              className="absolute bottom-0 right-6 w-[6rem] transition duration-300 group-hover:scale-[1.4]"
              src="https://raw.githubusercontent.com/Meschacirung/Tailus-website/main/public/images/singers/Michael-Jackson.png"
              alt
            />
          </div>
        </div>
        <div className="relative -mr-6 flex flex-col justify-end overflow-hidden rounded-b-xl pt-6 pr-6">
          <div className="group relative flex cursor-pointer justify-between rounded-xl bg-orange-200 before:absolute before:inset-y-0 before:right-0 before:w-1/2 before:rounded-r-xl before:bg-gradient-to-r before:from-transparent before:to-orange-600 before:opacity-0 before:transition before:duration-500 hover:before:opacity-100">
            <div className="relative space-y-1 p-4">
              <h4 className="text-lg text-orange-900">Ice Cream</h4>
              <div className="relative h-6 text-orange-800 text-sm">
                <span className="transition duration-300 group-hover:invisible group-hover:opacity-0">Selena Gomez</span>
                <a
                  href
                  className="w-max flex items-center gap-3 invisible absolute left-0 top-0 translate-y-3 transition duration-300 group-hover:visible group-hover:translate-y-0"
                >
                  <span>Listen now </span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-4 w-4 -translate-x-4 transition duration-300 group-hover:translate-x-0"
                    viewBox="0 0 20 20"
                    fill="currentColor"
                  >
                    <path
                      fillRule="evenodd"
                      d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z"
                      clipRule="evenodd"
                    />
                  </svg>
                </a>
              </div>
            </div>
            <img
              className="absolute -bottom-1 right-0 w-[6rem] transition duration-300 group-hover:scale-[1.4]"
              src="https://raw.githubusercontent.com/Meschacirung/Tailus-website/main/public/images/singers/Selena-Gomez.png"
              alt
            />
          </div>
        </div>
        <div className="relative flex flex-col justify-end overflow-hidden rounded-b-xl pt-6">
          <div className="group relative flex cursor-pointer justify-between rounded-xl bg-rose-200 before:absolute before:inset-y-0 before:right-0 before:w-1/2 before:rounded-r-xl before:bg-gradient-to-r before:from-transparent before:to-rose-600 before:opacity-0 before:transition before:duration-500 hover:before:opacity-100">
            <div className="relative space-y-1 p-4">
              <h4 className="text-lg text-rose-900">Love yourself</h4>
              <div className="relative h-6 text-rose-800 text-sm">
                <span className="transition duration-300 group-hover:invisible group-hover:opacity-0">Justin Bieber</span>
                <a
                  href
                  className="w-max flex items-center gap-3 invisible absolute left-0 top-0 translate-y-3 transition duration-300 group-hover:visible group-hover:translate-y-0"
                >
                  <span>Listen now </span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-4 w-4 -translate-x-4 transition duration-300 group-hover:translate-x-0"
                    viewBox="0 0 20 20"
                    fill="currentColor"
                  >
                    <path
                      fillRule="evenodd"
                      d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z"
                      clipRule="evenodd"
                    />
                  </svg>
                </a>
              </div>
            </div>
            <img
              className="absolute bottom-0 right-6 w-[6rem] transition duration-300 group-hover:scale-[1.4]"
              src="https://raw.githubusercontent.com/Meschacirung/Tailus-website/main/public/images/singers/Justin-Bieber.png"
              alt
            />
          </div>
        </div>
        <div className="relative -mr-6 flex flex-col justify-end overflow-hidden rounded-b-xl pt-6 pr-6">
          <div className="group relative flex cursor-pointer justify-between rounded-xl bg-fuchsia-200 before:absolute before:inset-y-0 before:right-0 before:w-1/2 before:rounded-r-xl before:bg-gradient-to-r before:from-transparent before:to-fuchsia-600 before:opacity-0 before:transition before:duration-500 hover:before:opacity-100">
            <div className="relative w-7/12 space-y-1 p-4">
              <h4 className="text-lg text-fuchsia-900">7 Rings</h4>
              <div className="relative h-6 text-fuchsia-800 text-sm">
                <span className="transition duration-300 group-hover:invisible group-hover:opacity-0">Ariana Grande</span>
                <a
                  href
                  className="w-max flex items-center gap-3 invisible absolute left-0 top-0 translate-y-3 transition duration-300 group-hover:visible group-hover:translate-y-0"
                >
                  <span>Listen now </span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-4 w-4 -translate-x-4 transition duration-300 group-hover:translate-x-0"
                    viewBox="0 0 20 20"
                    fill="currentColor"
                  >
                    <path
                      fillRule="evenodd"
                      d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z"
                      clipRule="evenodd"
                    />
                  </svg>
                </a>
              </div>
            </div>
            <img
              className="absolute -bottom-1 right-0 w-[6rem] transition duration-300 group-hover:scale-[1.4]"
              src="https://raw.githubusercontent.com/Meschacirung/Tailus-website/main/public/images/singers/Ariana-Grande.png"
              alt
            />
          </div>
        </div>
        <div className="relative flex flex-col justify-end overflow-hidden rounded-b-xl pt-6">
          <div className="group relative flex cursor-pointer justify-between rounded-xl bg-blue-200 before:absolute before:inset-y-0 before:right-0 before:w-1/2 before:rounded-r-xl before:bg-gradient-to-r before:from-transparent before:to-blue-600 before:opacity-0 before:transition before:duration-500 hover:before:opacity-100">
            <div className="relative space-y-1 p-4">
              <h4 className="text-xl text-blue-900">Diamond</h4>
              <div className="relative h-6 text-blue-800 text-sm">
                <span className="transition duration-300 group-hover:invisible group-hover:opacity-0">Rihanna</span>
                <a
                  href
                  className="w-max flex items-center gap-3 invisible absolute left-0 top-0 translate-y-3 transition duration-300 group-hover:visible group-hover:translate-y-0"
                >
                  <span>Listen now </span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-4 w-4 -translate-x-4 transition duration-300 group-hover:translate-x-0"
                    viewBox="0 0 20 20"
                    fill="currentColor"
                  >
                    <path
                      fillRule="evenodd"
                      d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z"
                      clipRule="evenodd"
                    />
                  </svg>
                </a>
              </div>
            </div>
            <img
              className="absolute bottom-0 right-6 w-[6rem] transition duration-300 group-hover:scale-[1.4]"
              src="https://raw.githubusercontent.com/Meschacirung/Tailus-website/main/public/images/singers/Rihanna.png"
              alt
            />
          </div>
        </div>
      </div> */}
    </Fragment>
  );
}
