import { object, string } from "yup";

const phone = /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/;
export const validate = object({
  preFix: string().required("กรุณาเลือก คำนำหน้าชื่อ"),
  firstName: string().required("กรุณากรอก ชื่อ"),
  lastName: string().required("กรุณากรอก นามสกุล"),
  phone: string().matches(phone, "กรุณากรอก เบอร์โทร").required("กรุณากรอก เบอร์โทร").max(10, "กรุณาตรวจสอบ เบอร์โทร"),
  userName: string()
    .required("กรุณากรอก รหัสนักศึกษา")
    .matches(/^(0|[1-9]\d*)$/, "กรุณากรอก รหัสนักศึกษา"),

  passWord: string().required("กรุณากรอก รหัสผ่าน").min(6, "รหัสผ่านต้องมากกว่า 6 อักษร").max(50, "รหัสผ่านต้องไม่มากกว่า 50 อักษร"),
  facultyId: string().required("กรุณาเลือก คณะ"),
  majorId: string().required("กรุณาเลือก สาขา"),
});
