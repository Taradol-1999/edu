import React from "react";
// import SwiperCreative from "../../components/swiper/SwiperCreative";
import SchoolIntroduction from "./content/SchoolIntroduction";
export default function Content() {
  // const img = ["https://swiperjs.com/demos/images/nature-1.jpg", "https://swiperjs.com/demos/images/nature-2.jpg", "https://swiperjs.com/demos/images/nature-3.jpg", "https://swiperjs.com/demos/images/nature-4.jpg"];

  return (
    <div className="p-5">
      <div className="my-20 ">
        <SchoolIntroduction />
      </div>
      {/* <SwiperCreative image={img} className="w-[100%] h-[600px]" /> */}
    </div>
  );
}
