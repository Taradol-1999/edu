import React, { Fragment } from "react";
import { nanoid } from "nanoid";
import { useHistory } from "react-router-dom";
import { TextSearch } from "../../../components/TextSearch";
import SVGPublish from "../../../SVGS/SVGPublish";

export default function News({ news, LoadData, loading }) {
  let history = useHistory();
  function CutReplace(data) {
    let value = data.replace(/<[^>]*>?/gm, "");
    let v = value.split("&nbsp;");
    return v;
  }
  return (
    <Fragment>
      <div className="w-full px-6 md:px-6 lg:px-14">
        <p className="text-lg mt-5 my-2 flex">
          <SVGPublish width="28" height="28" color="#2563eb" strokeWidth="1.5" className="mr-2 animate-bounce" />
          ประชาสัมพันธ์ ข่าวและกิจกรรม
        </p>
        <div className="mb-1">
          <TextSearch
            placeholder="ค้นหา..."
            onKeyUp={(e) => {
              LoadData(e.target.value.trim());
            }}
          />
        </div>

        <div className="overflow-auto h-[37rem]">
          {loading ? (
            Array.from(Array(4), () => {
              return (
                <div key={nanoid()}>
                  <div className="bg-blue-100 my-2 flex h-8 w-full animate-pulse rounded  opacity-20" />
                  <div className="bg-blue-100 my-2 flex h-24 w-full animate-pulse rounded opacity-20" />
                </div>
              );
            })
          ) : news.length > 0 ? (
            news.map((item) => (
              <div
                key={item.activityId}
                className="sm:flex p-1 hover:border-l-2 sm:hover:border-blue-700 cursor-pointer hover:bg-blue-50 hover:rounded shadow rounded mt-1"
                onClick={() => {
                  history.push("/DetailNews?id=" + item.activityId, news);
                }}
              >
                <img src={item.imageUrl[0]} alt="" className={item.imageUrl ? "sm:w-36 w-full h-40 lg:hidden rounded" : "hidden"} />
                <div className="flex w-full">
                  <div className="flex-shrink-0 flex flex-col text-center leading-none mx-3 mt-1">
                    <span className="text-gray-800 pb-2 mb-2 border-b-2 border-gray-400">{item.publishMonth}</span>
                    <span className="font-medium text-lg text-gray-800 title-font leading-none">{item.publishDay}</span>
                  </div>
                  <div className="w-5/6">
                    <div className="flex justify-between">
                      <h2 className="text-lg title-font font-medium text-indigo-500 line-clamp-1">{item.activityTitle}</h2>
                      <p className="text-sm text-right text-red-700">{item.activityType === "1" ? "กิจกรรม" : "ข่าว"}</p>
                    </div>
                    <p className="text-sm mb-5 line-clamp-3">{CutReplace(item.activityDetail)}</p>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <p className="text-center text-red-600 font-bold mt-5">ไม่พบข้อมูล !</p>
          )}
        </div>
      </div>
    </Fragment>
  );
}
