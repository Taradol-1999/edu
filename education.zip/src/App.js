import React, { useEffect, useState } from "react";
import { BrowserRouter, Switch, useLocation } from "react-router-dom";
import Routes from "./routes/Routes";
import SwitchRoute from "./layouts/SwitchLayout";
import { nanoid } from "nanoid";
import "./styles/tailwind.css";
import "@material-tailwind/react/tailwind.css";
import { connect } from "react-redux";
import { GetRequestsStatus } from "./services/Request.services";
//lazy-load-image
import "react-lazy-load-image-component/src/effects/blur.css";
// Import Swiper styles
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import "swiper/css/scrollbar";
import "swiper/css/effect-coverflow";
import "swiper/css/effect-fade";
import "swiper/css/autoplay";
import "swiper/css/lazy";
import "swiper/css/free-mode";
import "swiper/css/thumbs";

function App(props) {
  const user = JSON.parse(props.auth.users);
  const [chkReq, setChk] = useState(false);
  const [chkRegis, setChkRegis] = useState(false);
  const [path, setPath] = useState([]);

  async function Chk() {
    let res = await GetRequestsStatus(1);
    if (res) {
      setChk(res.data);
    }
    let resRegis = await GetRequestsStatus(3);
    if (resRegis) {
      setChkRegis(resRegis.data);
    }
  }
  useEffect(() => {
    Chk();
  }, []);

  useEffect(() => {
    if (props.auth.role !== "1" && props.auth.role) {
      setPath(Routes.filter((c) => c.role === 0 || c.role === 3));
    } else if (props.auth.role === "1") {
      setPath(Routes.filter((c) => c.role === parseInt(props.auth.role)));
    } else {
      setPath(Routes.filter((c) => c.role === 0));
    }
  }, [props.auth]);

  return (
    <BrowserRouter basename="/cs61/61123250113/web-education-kru">
      <ScrollToTops />
      <Switch>
        {path
          .filter((c) => (chkReq ? c.path : c.path !== "/FormPasswordRequest") && (user ? (user.role !== "1" ? (chkRegis ? c.path : c.path !== "/MainRegister/FormRegister") : c.path) : c.path))
          .map((prop) => {
            return <SwitchRoute exact path={prop.path} component={prop.component} layout={prop.layout} key={nanoid()} {...props} pathNameTH={prop.name} chkRegis={chkRegis} chkReq={chkReq} />;
          })}
      </Switch>
    </BrowserRouter>
  );
}
const mapStateToProps = (state) => ({
  auth: state.Authentication,
});

export default connect(mapStateToProps)(App);

export function ScrollToTops() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [pathname]);

  return null;
}
